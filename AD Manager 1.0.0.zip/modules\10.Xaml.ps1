﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 10.Xaml.ps1

# ── XAML ──────────────────────────────────────────────────────────────────────
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="AD Manager - Administrador de Active Directory | Develop by Matias Vaccari"
        Width="1220" Height="820" MinWidth="980" MinHeight="700"
        WindowStartupLocation="CenterScreen"
        WindowStyle="None" ResizeMode="CanResize"
        Background="#1e1e2e" Foreground="#cdd6f4"
        FontFamily="Segoe UI">
  <Window.Resources>
    <Style x:Key="PanelCard" TargetType="Border">
      <Setter Property="Background" Value="{DynamicResource ThemePanelBg}"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemePanelBorder}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="CornerRadius" Value="8"/>
      <Setter Property="Padding" Value="14,12"/>
    </Style>
    <Style TargetType="TextBox">
      <Setter Property="Background" Value="{DynamicResource ThemeInputBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeInputFg}"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeBorder}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="10,7"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="MinHeight" Value="34"/>
      <Setter Property="Margin" Value="0,2,0,2"/>
    </Style>
    <Style TargetType="PasswordBox">
      <Setter Property="Background" Value="{DynamicResource ThemeInputBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeInputFg}"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeBorder}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="10,7"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="MinHeight" Value="34"/>
      <Setter Property="Margin" Value="0,2,0,2"/>
    </Style>
    <Style x:Key="ComboBoxToggleButton" TargetType="ToggleButton">
      <Setter Property="Focusable" Value="False"/>
      <Setter Property="Background" Value="{DynamicResource ThemeInputBg}"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeBorder}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeInputFg}"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="ToggleButton">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8">
              <Grid>
                <Grid.ColumnDefinitions>
                  <ColumnDefinition Width="*"/>
                  <ColumnDefinition Width="36"/>
                </Grid.ColumnDefinitions>
                <Border Grid.Column="1" Background="{DynamicResource ThemeComboArrowBg}" CornerRadius="0,8,8,0">
                  <Path HorizontalAlignment="Center" VerticalAlignment="Center" Fill="{DynamicResource ThemeComboArrowFg}" Data="M 0 0 L 4 4 L 8 0 Z"/>
                </Border>
              </Grid>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeComboHoverBg}"/>
              </Trigger>
              <Trigger Property="IsChecked" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeComboPopupBg}"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="ThemedComboBoxItem" TargetType="ComboBoxItem">
      <Setter Property="Background" Value="{DynamicResource ThemeComboPopupBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeComboPopupFg}"/>
      <Setter Property="Padding" Value="10,6"/>
      <Setter Property="HorizontalContentAlignment" Value="Stretch"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="ComboBoxItem">
            <Border x:Name="ItemBorder" Background="{TemplateBinding Background}" CornerRadius="6" SnapsToDevicePixels="True">
              <ContentPresenter Margin="{TemplateBinding Padding}" HorizontalAlignment="{TemplateBinding HorizontalContentAlignment}" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsHighlighted" Value="True">
                <Setter TargetName="ItemBorder" Property="Background" Value="{DynamicResource ThemeComboItemHoverBg}"/>
                <Setter Property="Foreground" Value="{DynamicResource ThemeComboItemHoverFg}"/>
              </Trigger>
              <Trigger Property="IsSelected" Value="True">
                <Setter TargetName="ItemBorder" Property="Background" Value="{DynamicResource ThemeSelectionBg}"/>
                <Setter Property="Foreground" Value="{DynamicResource ThemeSelectionFg}"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style TargetType="ComboBox">
      <Setter Property="Background" Value="{DynamicResource ThemeInputBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeInputFg}"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeBorder}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="10,6"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="MinHeight" Value="34"/>
      <Setter Property="Margin" Value="0,2,0,2"/>
      <Setter Property="ItemContainerStyle" Value="{StaticResource ThemedComboBoxItem}"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="ComboBox">
            <Grid>
              <ToggleButton x:Name="ToggleButton"
                            Background="{TemplateBinding Background}"
                            BorderBrush="{TemplateBinding BorderBrush}"
                            BorderThickness="{TemplateBinding BorderThickness}"
                            IsChecked="{Binding IsDropDownOpen, Mode=TwoWay, RelativeSource={RelativeSource TemplatedParent}}"
                            ClickMode="Press"
                            Style="{StaticResource ComboBoxToggleButton}"/>
              <ContentPresenter x:Name="ContentSite"
                                Margin="12,0,40,0"
                                VerticalAlignment="Center"
                                HorizontalAlignment="Left"
                                Content="{TemplateBinding SelectionBoxItem}"
                                ContentTemplate="{TemplateBinding SelectionBoxItemTemplate}"
                                ContentTemplateSelector="{TemplateBinding ItemTemplateSelector}"
                                IsHitTestVisible="False"/>
              <TextBox x:Name="PART_EditableTextBox"
                       Margin="12,0,40,0"
                       VerticalContentAlignment="Center"
                       Background="Transparent"
                       BorderThickness="0"
                       Foreground="{TemplateBinding Foreground}"
                       Visibility="Hidden"
                       IsReadOnly="{TemplateBinding IsReadOnly}"/>
              <Popup x:Name="Popup"
                     Placement="Bottom"
                     AllowsTransparency="True"
                     Focusable="False"
                     IsOpen="{TemplateBinding IsDropDownOpen}"
                     PopupAnimation="Slide">
                <Border Margin="0,6,0,0"
                        Background="{DynamicResource ThemeComboPopupBg}"
                        BorderBrush="{DynamicResource ThemePanelBorder}"
                        BorderThickness="1"
                        CornerRadius="10"
                        MinWidth="{Binding ActualWidth, RelativeSource={RelativeSource TemplatedParent}}">
                  <ScrollViewer Margin="6" SnapsToDevicePixels="True">
                    <StackPanel IsItemsHost="True" KeyboardNavigation.DirectionalNavigation="Contained"/>
                  </ScrollViewer>
                </Border>
              </Popup>
            </Grid>
            <ControlTemplate.Triggers>
              <Trigger Property="IsEditable" Value="True">
                <Setter TargetName="PART_EditableTextBox" Property="Visibility" Value="Visible"/>
                <Setter TargetName="ContentSite" Property="Visibility" Value="Hidden"/>
              </Trigger>
              <Trigger Property="HasItems" Value="False">
                <Setter TargetName="Popup" Property="MinHeight" Value="34"/>
              </Trigger>
              <Trigger Property="IsEnabled" Value="False">
                <Setter Property="Opacity" Value="0.7"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="BtnPrimary" TargetType="Button">
      <Setter Property="Background" Value="{DynamicResource ThemeBtnPrimaryBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeBtnPrimaryFg}"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Padding" Value="16,9"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeBtnPrimaryBorder}"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="MinHeight" Value="36"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeBtnPrimaryHoverBg}"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeBtnPrimaryPressedBg}"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="BtnDanger" TargetType="Button">
      <Setter Property="Background" Value="{DynamicResource ThemeBtnDangerBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeBtnDangerFg}"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Padding" Value="16,9"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeBtnDangerBorder}"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="MinHeight" Value="36"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeBtnDangerHoverBg}"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeBtnDangerPressedBg}"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="BtnSuccess" TargetType="Button">
      <Setter Property="Background" Value="{DynamicResource ThemeBtnSuccessBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeBtnSuccessFg}"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Padding" Value="16,9"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeBtnSuccessBorder}"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="MinHeight" Value="36"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeBtnSuccessHoverBg}"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeBtnSuccessPressedBg}"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="BtnWarn" TargetType="Button">
      <Setter Property="Background" Value="{DynamicResource ThemeBtnWarnBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeBtnWarnFg}"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Padding" Value="16,9"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeBtnWarnBorder}"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="MinHeight" Value="36"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeBtnWarnHoverBg}"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True">
                <Setter Property="Background" Value="{DynamicResource ThemeBtnWarnPressedBg}"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="WindowControlButton" TargetType="Button" BasedOn="{StaticResource BtnPrimary}">
      <Setter Property="FontSize" Value="12"/>
      <Setter Property="Padding" Value="12,6"/>
      <Setter Property="MinWidth" Value="92"/>
    </Style>
    <Style TargetType="Label">
      <Setter Property="Foreground" Value="{DynamicResource ThemeLabelFg}"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Padding" Value="0,4,0,2"/>
    </Style>
    <Style TargetType="DataGrid">
      <Setter Property="Background" Value="{DynamicResource ThemeGridBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeGridFg}"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeGridBorder}"/>
      <Setter Property="RowBackground" Value="{DynamicResource ThemeGridRowBg}"/>
      <Setter Property="AlternatingRowBackground" Value="{DynamicResource ThemeGridRowAltBg}"/>
      <Setter Property="GridLinesVisibility" Value="Horizontal"/>
      <Setter Property="HorizontalGridLinesBrush" Value="{DynamicResource ThemeGridLine}"/>
      <Setter Property="HeadersVisibility" Value="Column"/>
      <Setter Property="FontSize" Value="12"/>
      <Setter Property="SelectionMode" Value="Single"/>
      <Setter Property="IsReadOnly" Value="True"/>
      <Setter Property="AutoGenerateColumns" Value="False"/>
      <Setter Property="CanUserAddRows" Value="False"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="RowHeaderWidth" Value="0"/>
      <Setter Property="Margin" Value="0,4,0,0"/>
    </Style>
    <Style TargetType="DataGridColumnHeader">
      <Setter Property="Background" Value="{DynamicResource ThemeGridHeaderBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeGridHeaderFg}"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Padding" Value="8,6"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeGridBorder}"/>
      <Setter Property="BorderThickness" Value="0,0,1,1"/>
    </Style>
    <Style TargetType="DataGridRow">
      <Setter Property="MinHeight" Value="32"/>
      <Style.Triggers>
        <Trigger Property="IsSelected" Value="True">
          <Setter Property="Background" Value="{DynamicResource ThemeSelectionBg}"/>
          <Setter Property="Foreground" Value="{DynamicResource ThemeSelectionFg}"/>
        </Trigger>
      </Style.Triggers>
    </Style>
    <Style TargetType="DataGridCell">
      <Setter Property="Padding" Value="8,6"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Style.Triggers>
        <Trigger Property="IsSelected" Value="True">
          <Setter Property="Background" Value="{DynamicResource ThemeSelectionBg}"/>
          <Setter Property="Foreground" Value="{DynamicResource ThemeSelectionFg}"/>
        </Trigger>
      </Style.Triggers>
    </Style>
    <Style TargetType="TabControl">
      <Setter Property="Background" Value="{DynamicResource ThemeWindowBg}"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemePanelBorder}"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Padding" Value="0"/>
    </Style>
    <Style TargetType="TabItem">
      <Setter Property="Foreground" Value="{DynamicResource ThemeTabFg}"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="Padding" Value="18,10"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="TabItem">
            <Grid Margin="3,0,3,0">
              <Border x:Name="Bd" Background="{DynamicResource ThemeTabBg}" BorderBrush="{DynamicResource ThemePanelBorder}" BorderThickness="1" CornerRadius="8,8,0,0" Padding="{TemplateBinding Padding}">
                <ContentPresenter ContentSource="Header" HorizontalAlignment="Center"/>
              </Border>
              <Border x:Name="AccentBar" Height="3" Background="{DynamicResource ThemeAccent}" VerticalAlignment="Bottom" Margin="14,0,14,0" Opacity="0"/>
            </Grid>
            <ControlTemplate.Triggers>
              <Trigger Property="IsSelected" Value="True">
                <Setter TargetName="Bd" Property="Background" Value="{DynamicResource ThemeTabSelectedBg}"/>
                <Setter Property="Foreground" Value="{DynamicResource ThemeTabSelectedFg}"/>
                <Setter Property="FontWeight" Value="Bold"/>
                <Setter TargetName="AccentBar" Property="Opacity" Value="1"/>
              </Trigger>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="Bd" Property="Background" Value="{DynamicResource ThemeTabHoverBg}"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style TargetType="CheckBox">
      <Setter Property="Foreground" Value="{DynamicResource ThemeCheckFg}"/>
      <Setter Property="FontSize" Value="13"/>
    </Style>
    <Style TargetType="TreeView">
      <Setter Property="Background" Value="{DynamicResource ThemeTreeBg}"/>
      <Setter Property="Foreground" Value="{DynamicResource ThemeTreeFg}"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemeTreeBorder}"/>
    </Style>
    <Style TargetType="TreeViewItem">
      <Setter Property="Foreground" Value="{DynamicResource ThemeTreeItemFg}"/>
    </Style>
    <Style TargetType="GroupBox">
      <Setter Property="Foreground" Value="{DynamicResource ThemeGroupBoxFg}"/>
      <Setter Property="BorderBrush" Value="{DynamicResource ThemePanelBorder}"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="GroupBox">
            <Grid Margin="0,8,0,0" SnapsToDevicePixels="True">
              <Border Margin="0,10,0,0"
                      BorderBrush="{TemplateBinding BorderBrush}"
                      BorderThickness="1"
                      CornerRadius="8"
                      Background="{DynamicResource ThemePanelBg}"/>
              <Border Background="{DynamicResource ThemePanelBg}"
                      HorizontalAlignment="Left"
                      Margin="14,0,0,0"
                      Padding="10,0">
                <ContentPresenter ContentSource="Header"
                                  RecognizesAccessKey="True"
                                  TextElement.Foreground="{TemplateBinding Foreground}"/>
              </Border>
              <ContentPresenter Margin="12,22,12,12"/>
            </Grid>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
  </Window.Resources>

  <Grid Margin="14">
    <DockPanel>
    <Border x:Name="borderHeader" DockPanel.Dock="Top" Background="#181825" Padding="20,16" CornerRadius="12" BorderBrush="{DynamicResource ThemePanelBorder}" BorderThickness="1">
      <DockPanel>
        <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Center">
          <Border Background="{DynamicResource ThemePanelBg}" BorderBrush="{DynamicResource ThemePanelBorder}" BorderThickness="1" CornerRadius="9" Padding="6" Margin="0,0,12,0" VerticalAlignment="Center">
            <StackPanel Orientation="Horizontal">
              <Button x:Name="btnMinimizeApp" Content="Minimizar" Style="{StaticResource WindowControlButton}" ToolTip="Minimizar ventana" Margin="0,0,6,0" VerticalAlignment="Center"/>
              <Button x:Name="btnMaximizeApp" Content="Maximizar" Style="{StaticResource WindowControlButton}" ToolTip="Maximizar ventana" VerticalAlignment="Center"/>
            </StackPanel>
          </Border>
          <Button x:Name="btnThemeToggle" Content="Modo claro" Style="{StaticResource BtnPrimary}" FontSize="12" Padding="12,6" Margin="0,0,10,0" VerticalAlignment="Center"/>
          <Button x:Name="btnCloseApp" Content="Cerrar" Style="{StaticResource BtnDanger}" FontSize="12" Padding="12,6" VerticalAlignment="Center"/>
        </StackPanel>
        <StackPanel x:Name="headerDragZone" VerticalAlignment="Center">
          <TextBlock x:Name="txtTitle" Text="AD Manager" FontSize="24" FontWeight="Bold" Foreground="#89b4fa" FontFamily="Bahnschrift SemiBold"/>
          <TextBlock x:Name="txtSubtitle" Text="Administracion diaria de usuarios, grupos y estructura de Active Directory" FontSize="12" Foreground="#6c7086" Margin="0,3,0,0"/>
        </StackPanel>
      </DockPanel>
    </Border>

    <Border x:Name="borderDomainBar" DockPanel.Dock="Top" Background="#232336" Padding="16,12" CornerRadius="10" BorderBrush="{DynamicResource ThemePanelBorder}" BorderThickness="1" Margin="0,12,0,0">
      <Grid>
        <Grid.ColumnDefinitions>
          <ColumnDefinition Width="2*"/>
          <ColumnDefinition Width="Auto"/>
          <ColumnDefinition Width="Auto"/>
        </Grid.ColumnDefinitions>
        <StackPanel Grid.Column="0" VerticalAlignment="Center" Margin="0,0,16,0">
          <TextBlock x:Name="txtDomainLabel" Text="Contexto de dominio" Foreground="#bac2de" FontSize="11" FontWeight="SemiBold"/>
          <TextBlock x:Name="txtDomainInfo" Text="" Foreground="#6c7086" FontSize="12" Margin="0,4,0,0"/>
        </StackPanel>
        <ComboBox x:Name="cbDomainSelect" Grid.Column="1" Width="280" FontSize="12" VerticalAlignment="Center" Margin="0,0,12,0"/>
        <StackPanel Grid.Column="2" Orientation="Horizontal" VerticalAlignment="Center">
          <Button x:Name="btnDomainConnect" Content="Conectar" Style="{StaticResource BtnSuccess}" FontSize="11" Padding="10,4"/>
          <Button x:Name="btnDomainDisconnect" Content="Desconectar" Style="{StaticResource BtnDanger}" FontSize="11" Padding="10,4" Margin="6,0,0,0"/>
          <CheckBox x:Name="chkSimulationMode" Content="Simulacion" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="12"/>
        </StackPanel>
      </Grid>
    </Border>

    <Border DockPanel.Dock="Bottom" Background="#181825" Padding="14,10" CornerRadius="10" BorderBrush="{DynamicResource ThemePanelBorder}" BorderThickness="1" Margin="0,12,0,0">
      <TextBlock x:Name="txtStatus" Text="Listo." Foreground="#a6adc8" FontSize="12"/>
    </Border>

    <TabControl x:Name="mainTabControl" Background="#1e1e2e" BorderBrush="#45475a" Margin="0,14,0,0" Padding="0,8">

      <TabItem Header="Usuarios">
        <Grid Margin="10">
          <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
          </Grid.RowDefinitions>

          <Border x:Name="borderUserSearchPanel" Grid.Row="0" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="12,8" Margin="0,0,0,8">
            <StackPanel Orientation="Horizontal">
              <TextBlock Text="🔍" FontSize="16" VerticalAlignment="Center" Margin="0,0,6,0"/>
              <TextBox x:Name="txtUserSearch" Width="300" ToolTip="Buscar por nombre, SAM o email"/>
              <Button x:Name="btnUserSearch" Content="Buscar" Style="{StaticResource BtnPrimary}" Margin="8,0,0,0"/>
              <Button x:Name="btnUserRefresh" Content="🔄" Style="{StaticResource BtnPrimary}" Margin="4,0,0,0" ToolTip="Actualizar"/>
            </StackPanel>
          </Border>

          <DataGrid x:Name="dgUsers" Grid.Row="1">
            <DataGrid.Columns>
              <DataGridTextColumn Header="SAMAccountName" Binding="{Binding SamAccountName}" Width="130"/>
              <DataGridTextColumn Header="Nombre" Binding="{Binding Name}" Width="180"/>
              <DataGridTextColumn Header="Email" Binding="{Binding EmailAddress}" Width="200"/>
              <DataGridTextColumn Header="Habilitado" Binding="{Binding Enabled}" Width="80"/>
              <DataGridTextColumn Header="Bloqueado" Binding="{Binding LockedOut}" Width="80"/>
              <DataGridTextColumn Header="OU" Binding="{Binding OUPath}" Width="*"/>
            </DataGrid.Columns>
          </DataGrid>

          <Border x:Name="borderUserActionsPanel" Grid.Row="2" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="10,8" Margin="0,8,0,0">
            <WrapPanel>
              <Button x:Name="btnUserNew" Content="➕ Crear Usuario" Style="{StaticResource BtnSuccess}" Margin="0,0,6,4"/>
              <Button x:Name="btnUserCopyProfile" Content="📄 Copiar Perfil" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnUserEdit" Content="✏️ Modificar" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnUserResetPwd" Content="🔑 Resetear Contraseña" Style="{StaticResource BtnWarn}" Margin="0,0,6,4"/>
              <Button x:Name="btnUserDisable" Content="🚫 Deshabilitar" Style="{StaticResource BtnWarn}" Margin="0,0,6,4"/>
              <Button x:Name="btnUserEnable" Content="✅ Habilitar" Style="{StaticResource BtnSuccess}" Margin="0,0,6,4"/>
              <Button x:Name="btnUserUnlock" Content="🔓 Desbloquear" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnUserDelete" Content="🗑️ Eliminar" Style="{StaticResource BtnDanger}" Margin="0,0,6,4"/>
            </WrapPanel>
          </Border>
        </Grid>
      </TabItem>
      <TabItem Header="Grupos">
        <Grid Margin="10">
          <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
          </Grid.RowDefinitions>

          <Border x:Name="borderGroupSearchPanel" Grid.Row="0" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="12,8" Margin="0,0,0,8">
            <StackPanel Orientation="Horizontal">
              <TextBlock Text="🔍" FontSize="16" VerticalAlignment="Center" Margin="0,0,6,0"/>
              <TextBox x:Name="txtGroupSearch" Width="300" ToolTip="Buscar por nombre de grupo"/>
              <Button x:Name="btnGroupSearch" Content="Buscar" Style="{StaticResource BtnPrimary}" Margin="8,0,0,0"/>
            </StackPanel>
          </Border>

          <DataGrid x:Name="dgGroups" Grid.Row="1">
            <DataGrid.Columns>
              <DataGridTextColumn Header="Nombre" Binding="{Binding Name}" Width="200"/>
              <DataGridTextColumn Header="SAM" Binding="{Binding SamAccountName}" Width="150"/>
              <DataGridTextColumn Header="Categoría" Binding="{Binding GroupCategory}" Width="100"/>
              <DataGridTextColumn Header="Ámbito" Binding="{Binding GroupScope}" Width="100"/>
              <DataGridTextColumn Header="Descripción" Binding="{Binding Description}" Width="*"/>
            </DataGrid.Columns>
          </DataGrid>

          <Border x:Name="borderGroupActionsPanel" Grid.Row="2" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="10,8" Margin="0,8,0,0">
            <WrapPanel>
              <Button x:Name="btnGroupNew" Content="➕ Crear Grupo" Style="{StaticResource BtnSuccess}" Margin="0,0,6,4"/>
              <Button x:Name="btnGroupAddMember" Content="👤+ Agregar Miembro" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnGroupRemoveMember" Content="👤- Quitar Miembro" Style="{StaticResource BtnWarn}" Margin="0,0,6,4"/>
              <Button x:Name="btnGroupMembers" Content="📋 Ver Miembros" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnGroupDelete" Content="🗑️ Eliminar Grupo" Style="{StaticResource BtnDanger}" Margin="0,0,6,4"/>
            </WrapPanel>
          </Border>
        </Grid>
      </TabItem>
      <TabItem Header="Computadoras">
        <Grid Margin="10">
          <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
          </Grid.RowDefinitions>

          <Border x:Name="borderComputerSearchPanel" Grid.Row="0" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="12,8" Margin="0,0,0,8">
            <StackPanel Orientation="Horizontal">
              <TextBox x:Name="txtComputerSearch" Width="340" ToolTip="Buscar por nombre, SAM o DNS"/>
              <Button x:Name="btnComputerSearch" Content="Buscar" Style="{StaticResource BtnPrimary}" Margin="8,0,0,0"/>
              <Button x:Name="btnComputerRefresh" Content="Actualizar" Style="{StaticResource BtnPrimary}" Margin="4,0,0,0" ToolTip="Volver a ejecutar la busqueda"/>
            </StackPanel>
          </Border>

          <DataGrid x:Name="dgComputers" Grid.Row="1">
            <DataGrid.Columns>
              <DataGridTextColumn Header="Nombre" Binding="{Binding Name}" Width="170"/>
              <DataGridTextColumn Header="DNS" Binding="{Binding DNSHostName}" Width="220"/>
              <DataGridTextColumn Header="Sistema operativo" Binding="{Binding OperatingSystem}" Width="180"/>
              <DataGridTextColumn Header="Habilitado" Binding="{Binding Enabled}" Width="90"/>
              <DataGridTextColumn Header="OU" Binding="{Binding OUPath}" Width="*"/>
            </DataGrid.Columns>
          </DataGrid>

          <Border x:Name="borderComputerActionsPanel" Grid.Row="2" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="10,8" Margin="0,8,0,0">
            <WrapPanel>
              <Button x:Name="btnComputerDelete" Content="Borrar equipo" Style="{StaticResource BtnDanger}" Margin="0,0,6,4"/>
              <Button x:Name="btnComputerMove" Content="Mover a OU" Style="{StaticResource BtnWarn}" Margin="0,0,6,4"/>
              <Button x:Name="btnComputerAddToGroup" Content="Agregar a Grupo" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
            </WrapPanel>
          </Border>
        </Grid>
      </TabItem>
      <TabItem Header="Mover">
        <Grid Margin="10" Background="{DynamicResource ThemeSurfaceBg}">
          <Grid.ColumnDefinitions>
            <ColumnDefinition Width="*"/>
            <ColumnDefinition Width="Auto"/>
            <ColumnDefinition Width="*"/>
          </Grid.ColumnDefinitions>

          <Border Grid.Column="0" Background="{DynamicResource ThemePanelBg}" BorderBrush="{DynamicResource ThemePanelBorder}" BorderThickness="1" CornerRadius="10" Margin="0,0,6,0" Padding="8">
            <GroupBox Header="OU Origen y Objetos" Margin="0">
              <StackPanel Margin="8">
                <Label Content="Seleccionar OU origen:"/>
                <Button x:Name="btnMoveRefreshSourceOU" Content="🔄 Recargar OUs origen" Style="{StaticResource BtnPrimary}" Margin="0,0,0,6" HorizontalAlignment="Left"/>
                <TreeView x:Name="tvMoveSourceOUs" Height="170"/>
                <Button x:Name="btnMoveLoadFromSource" Content="📥 Cargar objetos de OU origen" Style="{StaticResource BtnPrimary}" Margin="0,8,0,6" HorizontalAlignment="Left"/>

                <DataGrid x:Name="dgMoveObjects" Height="180" Margin="0,4,0,0" SelectionMode="Extended">
                  <DataGrid.Columns>
                    <DataGridTextColumn Header="Nombre" Binding="{Binding Name}" Width="160"/>
                    <DataGridTextColumn Header="Tipo" Binding="{Binding ObjectClass}" Width="110"/>
                    <DataGridTextColumn Header="OU Actual" Binding="{Binding OUPath}" Width="*"/>
                  </DataGrid.Columns>
                </DataGrid>
              </StackPanel>
            </GroupBox>
          </Border>

          <Border Grid.Column="1" Background="{DynamicResource ThemeSurfaceBg}" Margin="8,0" Padding="10,0">
            <StackPanel VerticalAlignment="Center">
              <Button x:Name="btnMoveExecute" Content="➡️ Mover" Style="{StaticResource BtnWarn}" FontSize="15" Padding="20,12"/>
            </StackPanel>
          </Border>

          <Border Grid.Column="2" Background="{DynamicResource ThemePanelBg}" BorderBrush="{DynamicResource ThemePanelBorder}" BorderThickness="1" CornerRadius="10" Margin="6,0,0,0" Padding="8">
            <GroupBox Header="OU Destino" Margin="0">
              <StackPanel Margin="8">
                <Label Content="Seleccionar OU destino:"/>
                <Button x:Name="btnMoveRefreshTargetOU" Content="🔄 Recargar OUs destino" Style="{StaticResource BtnPrimary}" Margin="0,0,0,6" HorizontalAlignment="Stretch"/>
                <Grid Margin="0,0,0,6">
                  <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="*"/>
                  </Grid.ColumnDefinitions>
                  <Button x:Name="btnMoveNewOU" Grid.Column="0" Content="➕ Crear OU" Style="{StaticResource BtnSuccess}" Margin="0,0,4,0"/>
                  <Button x:Name="btnMoveDeleteOU" Grid.Column="1" Content="🗑️ Eliminar OU" Style="{StaticResource BtnDanger}" Margin="4,0,0,0"/>
                </Grid>
                <TreeView x:Name="tvMoveTargetOUs" Height="180"/>
                <Button x:Name="btnMoveLoadFromTarget" Content="📥 Cargar objetos de OU destino" Style="{StaticResource BtnPrimary}" Margin="0,8,0,6" HorizontalAlignment="Left"/>
                <DataGrid x:Name="dgMoveTargetObjects" Height="180" Margin="0,4,0,0">
                  <DataGrid.Columns>
                    <DataGridTextColumn Header="Nombre" Binding="{Binding Name}" Width="160"/>
                    <DataGridTextColumn Header="Tipo" Binding="{Binding ObjectClass}" Width="110"/>
                    <DataGridTextColumn Header="OU Actual" Binding="{Binding OUPath}" Width="*"/>
                  </DataGrid.Columns>
                </DataGrid>
              </StackPanel>
            </GroupBox>
          </Border>
        </Grid>
      </TabItem>

      <TabItem Header="Lote CSV">
        <Grid Margin="10">
          <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
          </Grid.RowDefinitions>

          <Border Grid.Row="0" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="12,8" Margin="0,0,0,8">
            <StackPanel>
              <StackPanel Orientation="Horizontal">
                <TextBlock Text="📄" FontSize="16" VerticalAlignment="Center" Margin="0,0,6,0"/>
                <TextBox x:Name="txtBatchCsvPath" Width="560" ToolTip="Ruta al archivo CSV"/>
                <Button x:Name="btnBatchBrowseCsv" Content="Examinar" Style="{StaticResource BtnPrimary}" Margin="8,0,0,0"/>
              </StackPanel>
              <TextBlock Text="Acciones soportadas: Alta, Modificar, Baja, Mover (columna requerida: Action)." Foreground="#6c7086" FontSize="11" Margin="0,6,0,0"/>
            </StackPanel>
          </Border>

          <Border Grid.Row="1" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="10,8" Margin="0,0,0,8">
            <WrapPanel>
              <Button x:Name="btnBatchTemplate" Content="🧾 Plantilla CSV" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnBatchTemplateEmpty" Content="📄 Plantilla Vacía" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnBatchPreview" Content="👁️ Preview" Style="{StaticResource BtnWarn}" Margin="0,0,6,4"/>
              <Button x:Name="btnBatchExecute" Content="▶️ Ejecutar Lote" Style="{StaticResource BtnSuccess}" Margin="0,0,6,4"/>
              <Button x:Name="btnBatchExportReport" Content="💾 Exportar Reporte" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
            </WrapPanel>
          </Border>

          <DataGrid x:Name="dgBatchResults" Grid.Row="2">
            <DataGrid.Columns>
              <DataGridTextColumn Header="#" Binding="{Binding Row}" Width="60"/>
              <DataGridTextColumn Header="Acción" Binding="{Binding Action}" Width="90"/>
              <DataGridTextColumn Header="Identidad" Binding="{Binding Identity}" Width="180"/>
              <DataGridTextColumn Header="Estado" Binding="{Binding Status}" Width="90"/>
              <DataGridTextColumn Header="Detalle" Binding="{Binding Message}" Width="*"/>
            </DataGrid.Columns>
          </DataGrid>
        </Grid>
      </TabItem>

      <TabItem Header="Atributos">
        <Grid Margin="10">
          <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
          </Grid.RowDefinitions>

          <Border x:Name="borderAttrSearchPanel" Grid.Row="0" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="12,8" Margin="0,0,0,8">
            <StackPanel Orientation="Horizontal">
              <TextBlock Text="🔍" FontSize="16" VerticalAlignment="Center" Margin="0,0,6,0"/>
              <TextBox x:Name="txtAttrSearch" Width="250" ToolTip="Nombre de usuario o grupo"/>
              <Button x:Name="btnAttrSearch" Content="Cargar Atributos" Style="{StaticResource BtnPrimary}" Margin="8,0,0,0"/>
              <Button x:Name="btnAttrClear" Content="Limpiar" Style="{StaticResource BtnWarn}" Margin="6,0,0,0" Padding="10,5" FontSize="11"/>
              <TextBlock x:Name="txtAttrDN" Text="" Foreground="#6c7086" VerticalAlignment="Center" Margin="12,0,0,0" FontSize="11" TextTrimming="CharacterEllipsis" MaxWidth="350"/>
            </StackPanel>
          </Border>

          <DataGrid x:Name="dgAttributes" Grid.Row="1" CanUserSortColumns="True">
            <DataGrid.Columns>
              <DataGridTextColumn Header="Atributo" Binding="{Binding Attribute}" Width="220" IsReadOnly="True"/>
              <DataGridTextColumn Header="Valor" Binding="{Binding Value}" Width="*"/>
            </DataGrid.Columns>
          </DataGrid>
          <Border x:Name="borderAttrActionsPanel" Grid.Row="2" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="10,8" Margin="0,8,0,0">
            <StackPanel Orientation="Horizontal">
              <Button x:Name="btnAttrSave" Content="💾 Guardar Cambios" Style="{StaticResource BtnSuccess}" Margin="0,0,6,0"/>
              <TextBlock Text="Seleccioná un atributo en la grilla, editá el valor y presioná Guardar." Foreground="#6c7086" VerticalAlignment="Center" FontSize="12"/>
            </StackPanel>
          </Border>
        </Grid>
      </TabItem>

      <TabItem Header="Configuracion">
        <Grid Margin="10">
          <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
          </Grid.RowDefinitions>

          <Border x:Name="borderConfigHeaderPanel" Grid.Row="0" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="12,10" Margin="0,0,0,8">
            <StackPanel>
              <TextBlock Text="Configuración de Auditoría Central" FontSize="15" FontWeight="SemiBold" Foreground="#89b4fa"/>
              <TextBlock Text="Definí destino central para logs compartidos entre equipos." Foreground="#6c7086" FontSize="12" Margin="0,4,0,0"/>
            </StackPanel>
          </Border>

          <Border x:Name="borderConfigBodyPanel" Grid.Row="1" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="12,10">
            <ScrollViewer VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled" CanContentScroll="True">
              <StackPanel>
                <CheckBox x:Name="chkAuditEnableCentral" Content="Habilitar auditoría centralizada" Margin="0,0,0,8"/>

                <Label Content="Modo de destino:"/>
                <ComboBox x:Name="cbAuditMode" Width="180" HorizontalAlignment="Left"/>

                <Label Content="Ruta central (FileShare):"/>
                <StackPanel Orientation="Horizontal">
                  <TextBox x:Name="txtAuditCentralFilePath" Width="760" ToolTip="Ejemplo: \\SERVIDOR\AD-Audit\AD_Audit_Central.csv"/>
                  <Button x:Name="btnAuditBrowseCentralFile" Content="Examinar" Style="{StaticResource BtnPrimary}" Margin="8,0,0,0" Padding="10,4"/>
                </StackPanel>

                <Label Content="Connection String (SqlServer):"/>
                <TextBox x:Name="txtAuditSqlConnection" ToolTip="Ejemplo: Server=SQL01;Database=AdminAD;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;"/>

                <Label Content="Tabla SQL (SqlServer):"/>
                <TextBox x:Name="txtAuditSqlTable" Width="300" HorizontalAlignment="Left"/>

                <Label Content="Diagnóstico:" Margin="0,8,0,0"/>
                <TextBox x:Name="txtAuditDiagnostics"
                         IsReadOnly="True"
                         AcceptsReturn="True"
                         TextWrapping="Wrap"
                         VerticalScrollBarVisibility="Auto"
                         HorizontalScrollBarVisibility="Auto"
                         MinHeight="150"
                         FontFamily="Consolas"/>
                <Button x:Name="btnAuditDiagScrollDown"
                        Content="Bajar Diagnóstico"
                        Style="{StaticResource BtnPrimary}"
                        Margin="0,6,0,0"
                        HorizontalAlignment="Right"/>
              </StackPanel>
            </ScrollViewer>
          </Border>

          <Border x:Name="borderConfigActionsPanel" Grid.Row="2" Background="{DynamicResource ThemeSurfaceBg}" CornerRadius="6" Padding="10,8" Margin="0,8,0,0">
            <WrapPanel>
              <Button x:Name="btnAuditApplyConfig" Content="Aplicar Configuración" Style="{StaticResource BtnSuccess}" Margin="0,0,6,4"/>
              <Button x:Name="btnAuditSaveConfig" Content="Guardar Configuración" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnAuditLoadConfig" Content="Cargar Configuración" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnAuditDiagnoseConfig" Content="Diagnosticar" Style="{StaticResource BtnPrimary}" Margin="0,0,6,4"/>
              <Button x:Name="btnAuditTestConfig" Content="Probar Destino Central" Style="{StaticResource BtnWarn}" Margin="0,0,6,4"/>
            </WrapPanel>
          </Border>
        </Grid>
      </TabItem>

    </TabControl>
  </DockPanel>
  </Grid>
</Window>
"@
