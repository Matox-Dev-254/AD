﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 90.Launch.ps1

# ── MOSTRAR ──────────────────────────────────────────────────────────────────
Invoke-StartupInitializationWithSplash {
  param($splashUi)

  Step-StartupSplashProgress -splashUi $splashUi -targetPercent 10 -message 'Inicializando componentes...'
  Step-StartupSplashProgress -splashUi $splashUi -targetPercent 22 -message 'Cargando configuracion de auditoria...'
  try { [void](Load-AuditSettingsFromFile) } catch {}
  Update-AuditGuiFromSettings
  Update-AuditModeUiState
  $diagInit = Get-AuditValidationResult
  Show-AuditDiagnostics -lines $diagInit.Lines

  Step-StartupSplashProgress -splashUi $splashUi -targetPercent 36 -message 'Aplicando tema visual...'
  Apply-Theme

  if (-not $script:ADModuleAvailable) {
    Complete-StartupSplash -splashUi $splashUi -message 'Finalizando...'
    Set-Status "⚠️ Módulo ActiveDirectory no disponible. Instalá RSAT para usar las funciones AD." '#fab387'
  }
  else {
    Step-StartupSplashProgress -splashUi $splashUi -targetPercent 58 -message 'Preparando interfaz principal...'
    Refresh-DomainCombo
    if (($cbDomainSelect.SelectedIndex -lt 0) -and ($cbDomainSelect.Items.Count -gt 0)) { $cbDomainSelect.SelectedIndex = 0 }
    Step-StartupSplashProgress -splashUi $splashUi -targetPercent 78 -message 'Preparando sesion de Active Directory...'
    Start-ADSessionWarmup
    $domainLabel = if ($global:activeDomain) { [string]$global:activeDomain } else { [string]$script:LocalDomainDns }
    $remoteCount = Get-DeferredRemoteDomainCount
    if ($remoteCount -gt 0) {
      Set-Status "App lista. Dominio local: $domainLabel. Los dominios y la vista Mover se validan al usarlos." '#a6e3a1'
    }
    else {
      Set-Status "App lista. Dominio local: $domainLabel. La conectividad AD se valida al usar cada funcion." '#a6e3a1'
    }
    Complete-StartupSplash -splashUi $splashUi -message 'Listo.'
  }
}

if ($btnCloseApp) {
  $btnCloseApp.Add_Click({
      $window.Close()
    })
}

$window.ShowDialog() | Out-Null
