﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 80.AttributesStartup.ps1

# ── ATRIBUTOS ────────────────────────────────────────────────────────────────
$script:currentAttrDN = $null

function Clear-AttributeResults([switch]$ClearSearchText) {
  $script:currentAttrDN = $null
  $txtAttrDN.Text = ''
  $dgAttributes.ItemsSource = @()
  if ($ClearSearchText) { $txtAttrSearch.Text = '' }
}

$btnAttrSearch.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $search = Get-NormalizedText $txtAttrSearch.Text
    if ([string]::IsNullOrWhiteSpace($search)) {
      Clear-AttributeResults
      Set-Status "ℹ️ Resultados de atributos limpiados." '#89b4fa'
      return
    }

    try {
      [System.Windows.Input.Mouse]::OverrideCursor = [System.Windows.Input.Cursors]::Wait
      Set-Status "Cargando atributos..." '#89b4fa'
      $adp = Get-ADParams

      $obj = $null
      try { $obj = Get-ADUser @adp -Identity $search -Properties * } catch {}
      if (-not $obj) { try { $obj = Get-ADGroup @adp -Identity $search -Properties * } catch {} }
      if (-not $obj) {
        Clear-AttributeResults
        Show-Error "No se encontró '$search' como usuario ni como grupo."
        return
      }

      $script:currentAttrDN = $obj.DistinguishedName
      $txtAttrDN.Text = "DN: $($obj.DistinguishedName)"

      $editableAttrs = @(
        'GivenName', 'Surname', 'DisplayName', 'Description', 'EmailAddress', 'Title',
        'Department', 'Company', 'Manager', 'OfficePhone', 'MobilePhone', 'StreetAddress',
        'City', 'State', 'PostalCode', 'Country', 'Office', 'HomePage', 'EmployeeID', 'EmployeeNumber',
        'Info', 'Division', 'wWWHomePage'
      )

      $attrList = foreach ($attr in $editableAttrs) {
        $val = $obj.$attr
        if ($val -is [Microsoft.ActiveDirectory.Management.ADPropertyValueCollection]) { $val = ($val -join '; ') }

        [PSCustomObject]@{ Attribute = $attr; Value = [string]$val }
      }

      $dgAttributes.IsReadOnly = $false
      $dgAttributes.ItemsSource = @($attrList)
      Set-Status "✅ Atributos cargados para '$search'." '#a6e3a1'
    }
    catch { Show-Exception "Error cargando atributos:" $_ }
    finally { [System.Windows.Input.Mouse]::OverrideCursor = $null }
  })
Bind-EnterKeyToButton -textBox $txtAttrSearch -button $btnAttrSearch

$btnAttrClear.Add_Click({
    Clear-AttributeResults -ClearSearchText
    Set-Status "ℹ️ Búsqueda y resultados de atributos limpiados." '#89b4fa'
  })

$btnAttrSave.Add_Click({
    if (-not (Assert-ADModule)) { return }
    if (-not (Test-Guard (-not [string]::IsNullOrWhiteSpace($script:currentAttrDN)) "Primero cargá un objeto.")) { return }

    try {
      $adp = Get-ADParams
      $items = $dgAttributes.ItemsSource
      $savedReal = Invoke-AdWriteOperation `
        -Action {
          foreach ($item in $items) {
            $attrName = $item.Attribute
            $attrVal = $item.Value
            if ([string]::IsNullOrEmpty($attrVal)) {
              Set-ADObject @adp -Identity $script:currentAttrDN -Clear $attrName -ErrorAction SilentlyContinue
            }
            else {
              Set-ADObject @adp -Identity $script:currentAttrDN -Replace @{ $attrName = $attrVal } -ErrorAction SilentlyContinue
            }
          }
        } `
        -AuditAction 'Guardar Atributos' `
        -AuditObject ([string]$script:currentAttrDN) `
        -SuccessStatus "✅ Atributos guardados." `
        -SimulatedStatus "[SIMULATION] Cambios de atributos validados para '$($script:currentAttrDN)'."
      if ($savedReal) {
        [System.Windows.MessageBox]::Show("Atributos guardados correctamente.", "Éxito", "OK", "Information") | Out-Null
        }
    }
    catch { Show-Exception "Error guardando atributos:" $_ }
  })

function New-StartupSplash {
  $isDark = [bool]$script:isDarkMode

  $splashBorder = if ($isDark) { '#3b4261' } else { '#b4bdd0' }
  $splashShadow = if ($isDark) { '#000000' } else { '#7d869a' }
  $gradStart = if ($isDark) { '#1f2538' } else { '#f7f9ff' }
  $gradEnd = if ($isDark) { '#14192a' } else { '#e7ecf7' }
  $brandColor = if ($isDark) { '#a9c8ff' } else { '#2d4ea3' }
  $subtitleColor = if ($isDark) { '#d2daf0' } else { '#4a5878' }
  $statusColor = if ($isDark) { '#8ea2c9' } else { '#3f4f72' }
  $progressFg = if ($isDark) { '#6aa9ff' } else { '#4f8eea' }
  $progressBg = if ($isDark) { '#2c334a' } else { '#d5deef' }
  $hintColor = if ($isDark) { '#667391' } else { '#596887' }

  $splash = New-Object System.Windows.Window
  $splash.WindowStyle = 'None'
  $splash.ResizeMode = 'NoResize'
  $splash.AllowsTransparency = $true
  $splash.Background = ConvertTo-Brush '#00000000'
  $splash.ShowInTaskbar = $false
  $splash.Topmost = $true
  $splash.SizeToContent = 'WidthAndHeight'
  $splash.WindowStartupLocation = 'CenterScreen'

  $outer = New-Object System.Windows.Controls.Border
  $outer.CornerRadius = '14'
  $outer.BorderBrush = ConvertTo-Brush $splashBorder
  $outer.BorderThickness = '1'
  $outer.Padding = '26'
  $outer.Effect = New-Object System.Windows.Media.Effects.DropShadowEffect -Property @{
    BlurRadius   = 22
    ShadowDepth  = 0
    Opacity      = 0.35
    Color        = ([System.Windows.Media.ColorConverter]::ConvertFromString($splashShadow))
  }
  $outer.Background = New-Object System.Windows.Media.LinearGradientBrush -Property @{
    StartPoint = '0,0'
    EndPoint   = '1,1'
  }
  $outer.Background.GradientStops.Add((New-Object System.Windows.Media.GradientStop -Property @{ Color = ([System.Windows.Media.ColorConverter]::ConvertFromString($gradStart)); Offset = 0 }))
  $outer.Background.GradientStops.Add((New-Object System.Windows.Media.GradientStop -Property @{ Color = ([System.Windows.Media.ColorConverter]::ConvertFromString($gradEnd)); Offset = 1 }))

  $root = New-Object System.Windows.Controls.Grid
  $root.Width = 560
  $root.Height = 280

  $stack = New-Object System.Windows.Controls.StackPanel
  $stack.VerticalAlignment = 'Center'

  $txtBrand = New-Object System.Windows.Controls.TextBlock
  $txtBrand.Text = 'AD Manager'
  $txtBrand.FontSize = 34
  $txtBrand.FontWeight = 'Bold'
  $txtBrand.Foreground = ConvertTo-Brush $brandColor
  $txtBrand.HorizontalAlignment = 'Center'
  $stack.Children.Add($txtBrand) | Out-Null

  $txtSub = New-Object System.Windows.Controls.TextBlock
  $txtSub.Text = 'Administrador de Active Directory'
  $txtSub.FontSize = 14
  $txtSub.Margin = '0,8,0,18'
  $txtSub.Foreground = ConvertTo-Brush $subtitleColor
  $txtSub.HorizontalAlignment = 'Center'
  $stack.Children.Add($txtSub) | Out-Null

  $txtDev = New-Object System.Windows.Controls.TextBlock
  $txtDev.Text = 'Develop by Matias Vaccari'
  $txtDev.FontSize = 11
  $txtDev.Margin = '0,-10,0,14'
  $txtDev.Foreground = ConvertTo-Brush $hintColor
  $txtDev.HorizontalAlignment = 'Center'
  $stack.Children.Add($txtDev) | Out-Null

  $statusText = New-Object System.Windows.Controls.TextBlock
  $statusText.Text = 'Inicializando...'
  $statusText.FontSize = 13
  $statusText.Foreground = ConvertTo-Brush $statusColor
  $statusText.HorizontalAlignment = 'Center'
  $statusText.Margin = '0,0,0,10'
  $stack.Children.Add($statusText) | Out-Null

  $pb = New-Object System.Windows.Controls.ProgressBar
  $pb.Width = 420
  $pb.Height = 10
  $pb.IsIndeterminate = $false
  $pb.Minimum = 0
  $pb.Maximum = 100
  $pb.Value = 0
  $pb.Foreground = ConvertTo-Brush $progressFg
  $pb.Background = ConvertTo-Brush $progressBg
  $pb.BorderBrush = ConvertTo-Brush $splashBorder
  $pb.BorderThickness = '1'
  $stack.Children.Add($pb) | Out-Null

  $txtHint = New-Object System.Windows.Controls.TextBlock
  $txtHint.Text = 'Preparando interfaz y servicios de Active Directory'
  $txtHint.FontSize = 11
  $txtHint.Margin = '0,10,0,0'
  $txtHint.Foreground = ConvertTo-Brush $hintColor
  $txtHint.HorizontalAlignment = 'Center'
  $stack.Children.Add($txtHint) | Out-Null

  $root.Children.Add($stack) | Out-Null
  $outer.Child = $root
  $splash.Content = $outer

  return [PSCustomObject]@{
    Window = $splash
    Status = $statusText
    Progress = $pb
  }
}

function Set-StartupSplashProgress([object]$splashUi, [int]$percent, [string]$message = '') {
  if ($null -eq $splashUi) { return }
  if ($splashUi.Status -and (-not [string]::IsNullOrWhiteSpace($message))) {
    $splashUi.Status.Text = $message
  }
  if ($splashUi.Progress) {
    $clamped = [Math]::Max(0, [Math]::Min(100, $percent))
    $splashUi.Progress.Value = $clamped
  }
  [System.Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action] {}, [System.Windows.Threading.DispatcherPriority]::Render)
}

function Step-StartupSplashProgress([object]$splashUi, [int]$targetPercent, [string]$message = '') {
  if ($null -eq $splashUi -or $null -eq $splashUi.Progress) { return }
  $target = [Math]::Max(0, [Math]::Min(100, $targetPercent))
  $current = [int][Math]::Floor($splashUi.Progress.Value)
  if ($current -ge $target) {
    Set-StartupSplashProgress -splashUi $splashUi -percent $current -message $message
    return
  }
  for ($i = ($current + 1); $i -le $target; $i++) {
    Set-StartupSplashProgress -splashUi $splashUi -percent $i -message $message
    Start-Sleep -Milliseconds 9
  }
}

function Update-StartupSplashStatus([object]$splashUi, [string]$message) {
  if ($null -eq $splashUi -or $null -eq $splashUi.Status) { return }
  Set-StartupSplashProgress -splashUi $splashUi -percent ([int][Math]::Floor($splashUi.Progress.Value)) -message $message
}

function Complete-StartupSplash([object]$splashUi, [string]$message = 'Listo.') {
  if ($null -eq $splashUi) { return }
  Step-StartupSplashProgress -splashUi $splashUi -targetPercent 100 -message $message
  [System.Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action] {}, [System.Windows.Threading.DispatcherPriority]::Render)
  Start-Sleep -Milliseconds 350
}

function Invoke-StartupInitializationWithSplash([scriptblock]$StartupAction) {
  $minimumVisibleMs = 1400
  $splashUi = New-StartupSplash
  $startupTick = [Environment]::TickCount
  try {
    $splashUi.Window.Show()
    [System.Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action] {}, [System.Windows.Threading.DispatcherPriority]::Render)
    & $StartupAction $splashUi

    if ($splashUi -and $splashUi.Progress) {
      $finalMessage = if ($splashUi.Status -and (-not [string]::IsNullOrWhiteSpace([string]$splashUi.Status.Text))) {
        [string]$splashUi.Status.Text
      }
      else {
        'Listo.'
      }
      Step-StartupSplashProgress -splashUi $splashUi -targetPercent 100 -message $finalMessage
    }

    $elapsed = [Math]::Abs([Environment]::TickCount - $startupTick)
    if ($elapsed -lt $minimumVisibleMs) {
      Start-Sleep -Milliseconds ($minimumVisibleMs - $elapsed)
    }
  }
  finally {
    if ($splashUi -and $splashUi.Window -and $splashUi.Window.IsVisible) {
      $splashUi.Window.Close()
    }
  }
}
