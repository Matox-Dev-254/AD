@{
  ProductName = 'AD Manager'
  Publisher = 'Matias Vaccari'
  Version = '1.0.0'
  InstallDirName = 'AD Manager'
  ProgramDataDirName = 'ADManager'
  StartMenuFolder = 'AD Manager'
  MainScript = 'Uchatgpt.ps1'
  UninstallKey = 'ADManager'
  ShortcutName = 'AD Manager.lnk'
}
