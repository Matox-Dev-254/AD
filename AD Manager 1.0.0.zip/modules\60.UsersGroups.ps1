﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 60.UsersGroups.ps1

# ── FIX CORE: resolver host y testear RootDSE ────────────────────────────────
function Resolve-ServerForAD([string]$server) {
  $s = $server.Trim()
  if ($s -match '^\d{1,3}(\.\d{1,3}){3}$') {
    try {
      $entry = [System.Net.Dns]::GetHostEntry($s)
      if ($entry -and $entry.HostName) { return $entry.HostName }
    }
    catch { }
  }
  return $s
}

function Test-ADConnection([string]$server, [System.Management.Automation.PSCredential]$cred) {
  $srv = Resolve-ServerForAD $server
  $p = @{ Server = $srv }
  if ($cred) { $p.Credential = $cred }

  # RootDSE es el test más neutro (no depende de "Administrator" ni de OU)
  Get-ADRootDSE @p -ErrorAction Stop | Out-Null

  return $srv
}

# ── DOMAIN CONNECT / DISCONNECT ───────────────────────────────────────────────
$btnDomainConnect.Add_Click({
    if (-not (Assert-ADModule)) { return }

    $dlg = New-DialogWindow "Conectar a Dominio" 440 350
    $sp = New-Object System.Windows.Controls.StackPanel; $sp.Margin = '16'

    $sp.Children.Add((New-DlgLabel "Servidor / Controlador de Dominio:"))
    $sp.Children.Add((New-DlgLabel "(ej: dc01.empresa.com o empresa.com)"))
    $tbServer = New-DlgTextBox; $sp.Children.Add($tbServer)

    $sp.Children.Add((New-DlgLabel "Usuario (DOMINIO\usuario o user@dominio):"))
    $tbUser = New-DlgTextBox; $sp.Children.Add($tbUser)

    $sp.Children.Add((New-DlgLabel "Contraseña:"))
    $tbPwd = New-DlgPasswordBox; $sp.Children.Add($tbPwd)

    $cbNoCred = New-Object System.Windows.Controls.CheckBox
    $cbNoCred.Content = "Usar credenciales actuales (sin usuario/contraseña)"
    $cbNoCred.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
    $cbNoCred.Margin = '0,8,0,0'
    $cbNoCred.IsThreeState = $false
    $cbNoCred.IsChecked = $true
    $sp.Children.Add($cbNoCred)

    $btnConn = New-DlgButton "Conectar" 'Success'; $sp.Children.Add($btnConn)
    $scroll = New-Object System.Windows.Controls.ScrollViewer; $scroll.Content = $sp
    $dlg.Content = $scroll

    $btnConn.Add_Click({
        try {
          $serverInput = Get-RequiredTrimmedText $tbServer.Text "Ingresá un servidor."
          if ($null -eq $serverInput) { return }

          $useCurrentCred = Get-Checked $cbNoCred
          $cred = $null

          if (-not $useCurrentCred) {
            $u = Get-RequiredTrimmedText $tbUser.Text "Ingresá usuario y contraseña, o marcá 'Usar credenciales actuales'."
            if ($null -eq $u -or [string]::IsNullOrWhiteSpace($tbPwd.Password)) {
              Show-Error "Ingresá usuario y contraseña, o marcá 'Usar credenciales actuales'."
              return
            }
            $secPwd = ConvertTo-SecureString $tbPwd.Password -AsPlainText -Force
            $cred = New-Object System.Management.Automation.PSCredential($u, $secPwd)
          }

          Set-Status "Probando conexión..." '#89b4fa'

          $resolvedServer = Test-ADConnection -server $serverInput -cred $cred
          $domainParams = @{ Server = $resolvedServer }
          if ($cred) { $domainParams.Credential = $cred }
          $connectedDomain = ''
          try { $connectedDomain = [string](Get-ADDomain @domainParams -ErrorAction Stop).DNSRoot } catch {}
          if ([string]::IsNullOrWhiteSpace($connectedDomain)) { $connectedDomain = $resolvedServer }

          $label = if ($cred) { "$connectedDomain [$resolvedServer] ($($cred.UserName))" } else { "$connectedDomain [$resolvedServer]" }

          $global:domainConnections[$label] = @{
            Server            = $resolvedServer
            Credential        = $cred
            Domain            = $connectedDomain
            Persistable       = $true
            AuthMode          = if ($cred) { 'PromptCredentials' } else { 'CurrentCredentials' }
            UserName          = if ($cred) { [string]$cred.UserName } else { '' }
            RequiresReconnect = $false
          }

          Clear-ADDomainCache
          Refresh-DomainCombo
          $cbDomainSelect.SelectedItem = $label
          Save-DomainConnectionsToFile

          Set-Status "✅ Conectado a '$connectedDomain' ($resolvedServer)." '#a6e3a1'
          Write-AuditLog -Action 'Conectar Dominio' -Result 'OK' -Object "$connectedDomain ($resolvedServer)"
          [System.Windows.MessageBox]::Show("Conexión exitosa a '$connectedDomain' usando '$resolvedServer'.", "Conectado", "OK", "Information") | Out-Null
          $dlg.Close()
        }
        catch {
          Show-Exception "Error al conectar a '$($tbServer.Text.Trim())':" $_
        }
      }.GetNewClosure())

    $dlg.ShowDialog() | Out-Null
  })

$btnDomainDisconnect.Add_Click({
    $selected = $cbDomainSelect.SelectedItem
    if ($selected -eq $script:LocalDomainLabel) {
      [System.Windows.MessageBox]::Show("No se puede desconectar el dominio local.", "Info", "OK", "Information") | Out-Null
      return
    }
    if ($selected -and $global:domainConnections.ContainsKey($selected)) {
      $global:domainConnections.Remove($selected)
      Clear-ADDomainCache
      Refresh-DomainCombo
      Save-DomainConnectionsToFile
      Set-Status "✅ Desconectado de '$selected'." '#a6e3a1'
      Write-AuditLog -Action 'Desconectar Dominio' -Result 'OK' -Object ([string]$selected)
    }
  })

# ── USUARIOS ─────────────────────────────────────────────────────────────────
$btnUserSearch.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $filter = Get-NormalizedText $txtUserSearch.Text
    $maxResults = 500

    try {
      [System.Windows.Input.Mouse]::OverrideCursor = [System.Windows.Input.Cursors]::Wait
      Set-Status "Buscando usuarios..." '#89b4fa'
      $adp = Get-ADParams

      if ([string]::IsNullOrWhiteSpace($filter)) {
        $users = Get-ADUser @adp `
          -Filter * `
          -ResultSetSize ($maxResults + 1) `
          -Properties SamAccountName, Name, EmailAddress, Enabled, LockedOut, DistinguishedName |
        Select-Object SamAccountName, Name, EmailAddress, Enabled, LockedOut,
        @{N = 'OUPath'; E = { Get-OUFromDN $_.DistinguishedName } },
        DistinguishedName
      }
      else {
        # Escapar comillas simples para que el filtro AD no falle (ej: O'Connor)
        $safeFilter = Escape-ADFilterLiteral $filter
        $users = Get-ADUser @adp `
          -Filter "Name -like '*$safeFilter*' -or SamAccountName -like '*$safeFilter*' -or EmailAddress -like '*$safeFilter*'" `
          -ResultSetSize ($maxResults + 1) `
          -Properties SamAccountName, Name, EmailAddress, Enabled, LockedOut, DistinguishedName |
        Select-Object SamAccountName, Name, EmailAddress, Enabled, LockedOut,
        @{N = 'OUPath'; E = { Get-OUFromDN $_.DistinguishedName } },
        DistinguishedName
      }

      $totalFound = @($users).Count
      if ($totalFound -gt $maxResults) {
        $users = @($users | Select-Object -First $maxResults)
      }

      $dgUsers.ItemsSource = @($users)
      if ($totalFound -gt $maxResults) {
        Set-Status "⚠️ Se muestran los primeros $maxResults usuarios. Refiná la búsqueda para acotar resultados." '#fab387'
      }
      else {
        Set-Status "✅ Se encontraron $($users.Count) usuario(s)." '#a6e3a1'
      }
    }
    catch [Microsoft.ActiveDirectory.Management.ADException] {
      Show-Error "No se pudo interpretar el filtro de búsqueda. Probá con texto simple (nombre, usuario o email)."
    }
    catch { Show-Exception "Error buscando usuarios:" $_ }
    finally { [System.Windows.Input.Mouse]::OverrideCursor = $null }
  })
Bind-EnterKeyToButton -textBox $txtUserSearch -button $btnUserSearch
$btnUserRefresh.Add_Click({ Raise-ButtonClick $btnUserSearch })

$dgUsers.Add_MouseDoubleClick({
    if ($dgUsers.SelectedItem) {
      $btnUserEdit.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
  })

# Crear usuario
$btnUserNew.Add_Click({
    if (-not (Assert-ADModule)) { return }
    if (-not (Assert-UserAdminPermission -Operation 'Create')) { return }

    $dlg = New-DialogWindow "Crear Nuevo Usuario" 620 780
    $sp = New-Object System.Windows.Controls.StackPanel; $sp.Margin = '16'

    $lblFirstName = New-DlgLabel "Nombre:"; $sp.Children.Add($lblFirstName)
    $tbFirstName = New-DlgTextBox; $sp.Children.Add($tbFirstName)
    $lblInitials = New-DlgLabel "Iniciales:"; $sp.Children.Add($lblInitials)
    $tbInitials = New-DlgTextBox; $sp.Children.Add($tbInitials)
    $lblLastName = New-DlgLabel "Apellido:"; $sp.Children.Add($lblLastName)
    $tbLastName = New-DlgTextBox; $sp.Children.Add($tbLastName)
    $lblFullName = New-DlgLabel "Nombre completo (CN):"; $sp.Children.Add($lblFullName)
    $tbFullName = New-DlgTextBox; $sp.Children.Add($tbFullName)
    $lblDisplayName = New-DlgLabel "Nombre para mostrar:"; $sp.Children.Add($lblDisplayName)
    $tbDisplayName = New-DlgTextBox; $sp.Children.Add($tbDisplayName)
    $lblDescription = New-DlgLabel "Descripción:"; $sp.Children.Add($lblDescription)
    $tbDescription = New-DlgTextBox; $sp.Children.Add($tbDescription)
    $lblOffice = New-DlgLabel "Oficina:"; $sp.Children.Add($lblOffice)
    $tbOffice = New-DlgTextBox; $sp.Children.Add($tbOffice)
    $lblOfficePhone = New-DlgLabel "Teléfono:"; $sp.Children.Add($lblOfficePhone)
    $tbOfficePhone = New-DlgTextBox; $sp.Children.Add($tbOfficePhone)
    $lblEmail = New-DlgLabel "Email:"; $sp.Children.Add($lblEmail)
    $tbEmail = New-DlgTextBox; $sp.Children.Add($tbEmail)
    $lblWebPage = New-DlgLabel "Página Web:"; $sp.Children.Add($lblWebPage)
    $tbWebPage = New-DlgTextBox; $sp.Children.Add($tbWebPage)

    $lblStreetAddress = New-DlgLabel "Calle:"; $sp.Children.Add($lblStreetAddress)
    $tbStreetAddress = New-DlgTextBox
    $tbStreetAddress.AcceptsReturn = $true
    $tbStreetAddress.Height = 60
    $tbStreetAddress.TextWrapping = 'Wrap'
    $tbStreetAddress.VerticalScrollBarVisibility = 'Auto'
    $sp.Children.Add($tbStreetAddress)
    $lblPOBox = New-DlgLabel "Casilla Postal:"; $sp.Children.Add($lblPOBox)
    $tbPOBox = New-DlgTextBox; $sp.Children.Add($tbPOBox)
    $lblCity = New-DlgLabel "Ciudad:"; $sp.Children.Add($lblCity)
    $tbCity = New-DlgTextBox; $sp.Children.Add($tbCity)
    $lblState = New-DlgLabel "Provincia/Estado:"; $sp.Children.Add($lblState)
    $tbState = New-DlgTextBox; $sp.Children.Add($tbState)
    $lblPostalCode = New-DlgLabel "Código Postal:"; $sp.Children.Add($lblPostalCode)
    $tbPostalCode = New-DlgTextBox; $sp.Children.Add($tbPostalCode)
    $lblCountry = New-DlgLabel "País/Región:"; $sp.Children.Add($lblCountry)
    $tbCountry = New-DlgTextBox; $sp.Children.Add($tbCountry)

    $lblUpn = New-DlgLabel "Nombre de inicio de sesión (UPN):"; $sp.Children.Add($lblUpn)
    $upnGrid = New-Object System.Windows.Controls.Grid
    $upnGrid.ColumnDefinitions.Add((New-Object System.Windows.Controls.ColumnDefinition -Property @{ Width = '*' }))
    $upnGrid.ColumnDefinitions.Add((New-Object System.Windows.Controls.ColumnDefinition -Property @{ Width = 'Auto' }))
    $tbUpnUser = New-DlgTextBox
    $tbUpnUser.Margin = '0,0,6,0'
    [System.Windows.Controls.Grid]::SetColumn($tbUpnUser, 0)
    $lblUpnSuffix = New-Object System.Windows.Controls.TextBlock
    $lblUpnSuffix.VerticalAlignment = 'Center'
    $lblUpnSuffix.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextSecondary
    [System.Windows.Controls.Grid]::SetColumn($lblUpnSuffix, 1)
    $upnGrid.Children.Add($tbUpnUser) | Out-Null
    $upnGrid.Children.Add($lblUpnSuffix) | Out-Null
    $sp.Children.Add($upnGrid)

    $lblSam = New-DlgLabel "Nombre de inicio de sesión (anterior a Windows 2000):"; $sp.Children.Add($lblSam)
    $tbSam = New-DlgTextBox
    $sp.Children.Add($tbSam)
    $lblPwd = New-DlgLabel "Contraseña:"; $sp.Children.Add($lblPwd)
    $tbPwd = New-DlgPasswordBox; $sp.Children.Add($tbPwd)
    $lblPwd2 = New-DlgLabel "Repetir contraseña:"; $sp.Children.Add($lblPwd2)
    $tbPwdConfirm = New-DlgPasswordBox; $sp.Children.Add($tbPwdConfirm)

    $lblOU = New-DlgLabel "Unidad Organizativa (OU):"; $sp.Children.Add($lblOU)
    $cbOU = New-DlgComboBox @() 0
    $cbOU.MinWidth = 480
    $cbOU.MaxDropDownHeight = 320
    $cbOU.DisplayMemberPath = 'Label'
    $cbOU.SelectedValuePath = 'DistinguishedName'
    $cbOU.ToolTip = "Seleccioná la OU o contenedor destino."
    $sp.Children.Add($cbOU)

    try {
      $adpForOu = Get-ADParams
      $domainInfo = Get-ADDomainCached -adParams $adpForOu
      $usersContainerDn = $domainInfo.UsersContainer

      $ouDns = Get-ADOrganizationalUnit @adpForOu -Filter * -Properties DistinguishedName |
      Sort-Object DistinguishedName |
      Select-Object -ExpandProperty DistinguishedName

      if ((-not [string]::IsNullOrWhiteSpace($usersContainerDn)) -and (-not ($ouDns -contains $usersContainerDn))) {
        $ouDns += $usersContainerDn
      }

      # Seguridad: excluir Domain Controllers del desplegable para evitar errores humanos.
      $ouDns = @(
        $ouDns |
        Where-Object { $_ -and ($_ -notmatch '^(?i)(OU|CN)=Domain Controllers,') } |
        Sort-Object -Unique
      )

      $cbOU.Items.Clear() | Out-Null

      foreach ($ouDn in @($ouDns)) {
        if (-not [string]::IsNullOrWhiteSpace($ouDn)) {
          $label = Get-ContainerLabelFromDN $ouDn
          $cbOU.Items.Add([PSCustomObject]@{
              Label             = $label
              DistinguishedName = $ouDn
            }) | Out-Null
        }
      }
      if ($cbOU.Items.Count -gt 0) { $cbOU.SelectedIndex = 0 }
      else { Show-Error "No hay OUs disponibles para crear usuarios (se excluye 'Domain Controllers')." }
    }
    catch {
      Show-Exception "Error cargando OUs para crear usuario:" $_
    }

    # Similar a ADUC: completar campos de identidad automáticamente, pero editables.
    $updateIdentity = {
      $fn = Get-NormalizedText $tbFirstName.Text
      $ln = Get-NormalizedText $tbLastName.Text

      $nameParts = @()
      if (-not [string]::IsNullOrWhiteSpace($fn)) { $nameParts += $fn }
      if (-not [string]::IsNullOrWhiteSpace($ln)) { $nameParts += $ln }
      $full = ($nameParts -join ' ').Trim()
      if (-not [string]::IsNullOrWhiteSpace($full)) {
        $tbFullName.Text = $full
        $tbDisplayName.Text = $full
      }

      if ((-not [string]::IsNullOrWhiteSpace($fn)) -and (-not [string]::IsNullOrWhiteSpace($ln))) {
        $samAuto = (($fn.Substring(0, 1) + $ln).ToLower() -replace '[^a-z0-9._-]', '')
        $tbSam.Text = $samAuto
        $tbUpnUser.Text = $samAuto
      }
      elseif (-not [string]::IsNullOrWhiteSpace($ln)) {
        $samAuto = ($ln.ToLower() -replace '[^a-z0-9._-]', '')
        $tbSam.Text = $samAuto
        $tbUpnUser.Text = $samAuto
      }
    }
    $tbFirstName.Add_TextChanged($updateIdentity)
    $tbLastName.Add_TextChanged($updateIdentity)

    $adpForDomain = Get-ADParams
    $domainRootForUpn = (Get-ADDomainCached -adParams $adpForDomain).DNSRoot
    $lblUpnSuffix.Text = "@$domainRootForUpn"

    $cbMustChange = New-Object System.Windows.Controls.CheckBox
    $cbMustChange.Content = "El usuario debe cambiar la contraseña en el próximo inicio"
    $cbMustChange.IsChecked = $true
    $cbMustChange.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
    $cbMustChange.Margin = '0,10,0,0'
    $cbMustChange.IsThreeState = $false
    $sp.Children.Add($cbMustChange)

    $cbCannotChange = New-Object System.Windows.Controls.CheckBox
    $cbCannotChange.Content = "El usuario no puede cambiar la contraseña"
    $cbCannotChange.IsChecked = $false
    $cbCannotChange.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
    $cbCannotChange.Margin = '0,2,0,0'
    $cbCannotChange.IsThreeState = $false
    $sp.Children.Add($cbCannotChange)

    $cbPwdNeverExpires = New-Object System.Windows.Controls.CheckBox
    $cbPwdNeverExpires.Content = "La contraseña nunca expira"
    $cbPwdNeverExpires.IsChecked = $false
    $cbPwdNeverExpires.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
    $cbPwdNeverExpires.Margin = '0,2,0,0'
    $cbPwdNeverExpires.IsThreeState = $false
    $sp.Children.Add($cbPwdNeverExpires)

    $cbEnabled = New-Object System.Windows.Controls.CheckBox
    $cbEnabled.Content = "Cuenta habilitada"
    $cbEnabled.IsChecked = $true
    $cbEnabled.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
    $cbEnabled.Margin = '0,2,0,0'
    $cbEnabled.IsThreeState = $false
    $sp.Children.Add($cbEnabled)

    $modeUi = 'Create'
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'FirstName' -LabelControl $lblFirstName -InputControl $tbFirstName
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Initials' -LabelControl $lblInitials -InputControl $tbInitials
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'LastName' -LabelControl $lblLastName -InputControl $tbLastName
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'FullName' -LabelControl $lblFullName -InputControl $tbFullName
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'DisplayName' -LabelControl $lblDisplayName -InputControl $tbDisplayName
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Description' -LabelControl $lblDescription -InputControl $tbDescription
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Office' -LabelControl $lblOffice -InputControl $tbOffice
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'OfficePhone' -LabelControl $lblOfficePhone -InputControl $tbOfficePhone
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Email' -LabelControl $lblEmail -InputControl $tbEmail
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'WebPage' -LabelControl $lblWebPage -InputControl $tbWebPage
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'StreetAddress' -LabelControl $lblStreetAddress -InputControl $tbStreetAddress
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'POBox' -LabelControl $lblPOBox -InputControl $tbPOBox
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'City' -LabelControl $lblCity -InputControl $tbCity
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'State' -LabelControl $lblState -InputControl $tbState
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'PostalCode' -LabelControl $lblPostalCode -InputControl $tbPostalCode
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Country' -LabelControl $lblCountry -InputControl $tbCountry
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'UpnUser' -LabelControl $lblUpn -InputControl $upnGrid
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'SamAccountName' -LabelControl $lblSam -InputControl $tbSam
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Password' -LabelControl $lblPwd -InputControl $tbPwd
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Password' -LabelControl $lblPwd2 -InputControl $tbPwdConfirm
    Apply-UserFieldUiPolicy -Mode $modeUi -Field 'OU' -LabelControl $lblOU -InputControl $cbOU

    $cbMustChange.Visibility = if (Test-UserFieldVisible -Mode $modeUi -Field 'MustChangePassword') { 'Visible' } else { 'Collapsed' }
    $cbMustChange.IsEnabled = Test-UserFieldEditable -Mode $modeUi -Field 'MustChangePassword'
    $cbCannotChange.Visibility = if (Test-UserFieldVisible -Mode $modeUi -Field 'CannotChangePassword') { 'Visible' } else { 'Collapsed' }
    $cbCannotChange.IsEnabled = Test-UserFieldEditable -Mode $modeUi -Field 'CannotChangePassword'
    $cbPwdNeverExpires.Visibility = if (Test-UserFieldVisible -Mode $modeUi -Field 'PasswordNeverExpires') { 'Visible' } else { 'Collapsed' }
    $cbPwdNeverExpires.IsEnabled = Test-UserFieldEditable -Mode $modeUi -Field 'PasswordNeverExpires'
    $cbEnabled.Visibility = if (Test-UserFieldVisible -Mode $modeUi -Field 'Enabled') { 'Visible' } else { 'Collapsed' }
    $cbEnabled.IsEnabled = Test-UserFieldEditable -Mode $modeUi -Field 'Enabled'

    $btnCreate = New-DlgButton "Crear Usuario" 'Success'
    $sp.Children.Add($btnCreate)

    $scroll = New-Object System.Windows.Controls.ScrollViewer
    $scroll.Content = $sp
    $dlg.Content = $scroll

    $btnCreate.Add_Click({
        try {
          $mode = 'Create'
          $fn = Get-NormalizedText $tbFirstName.Text
          $ln = Get-NormalizedText $tbLastName.Text
          $cnName = Get-NormalizedText $tbFullName.Text
          $displayName = Get-NormalizedText $tbDisplayName.Text
          $upnUser = Get-NormalizedText $tbUpnUser.Text
          $sam = Get-NormalizedText $tbSam.Text
          $selectedOU = [string]$cbOU.SelectedValue
          $pwdPlain = $tbPwd.Password
          $pwdConfirm = $tbPwdConfirm.Password

          $effectiveSam = if (Test-UserFieldEditable -Mode $mode -Field 'SamAccountName') { $sam } else { New-DefaultSam -firstName $fn -lastName $ln }
          if ([string]::IsNullOrWhiteSpace($effectiveSam)) { $effectiveSam = New-DefaultSam -firstName $fn -lastName $ln }

          $effectiveCn = if (Test-UserFieldEditable -Mode $mode -Field 'FullName') { $cnName } else { '' }
          if ([string]::IsNullOrWhiteSpace($effectiveCn)) {
            $effectiveCn = ((@($fn, $ln) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) -join ' ').Trim()
          }
          if ([string]::IsNullOrWhiteSpace($effectiveCn)) { $effectiveCn = $effectiveSam }

          $effectiveUpnUser = if (Test-UserFieldEditable -Mode $mode -Field 'UpnUser') { $upnUser } else { '' }
          if ([string]::IsNullOrWhiteSpace($effectiveUpnUser)) { $effectiveUpnUser = $effectiveSam }

          if (-not (Test-UserFieldValue -Mode $mode -Field 'FirstName' -Value $fn -ErrorMessage "El campo 'Nombre' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'LastName' -Value $ln -ErrorMessage "El campo 'Apellido' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'FullName' -Value $effectiveCn -ErrorMessage "El campo 'Nombre completo (CN)' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'UpnUser' -Value $effectiveUpnUser -ErrorMessage "El campo 'UPN' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'SamAccountName' -Value $effectiveSam -ErrorMessage "El campo 'SamAccountName' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'OU' -Value $selectedOU -ErrorMessage "Seleccioná una OU o contenedor destino (requerido por política).")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Initials' -Value (Get-NormalizedText $tbInitials.Text) -ErrorMessage "El campo 'Iniciales' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Description' -Value (Get-NormalizedText $tbDescription.Text) -ErrorMessage "El campo 'Descripción' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Office' -Value (Get-NormalizedText $tbOffice.Text) -ErrorMessage "El campo 'Oficina' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'OfficePhone' -Value (Get-NormalizedText $tbOfficePhone.Text) -ErrorMessage "El campo 'Teléfono' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Email' -Value (Get-NormalizedText $tbEmail.Text) -ErrorMessage "El campo 'Email' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'WebPage' -Value (Get-NormalizedText $tbWebPage.Text) -ErrorMessage "El campo 'Página Web' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'StreetAddress' -Value (Get-NormalizedText $tbStreetAddress.Text) -ErrorMessage "El campo 'Calle' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'POBox' -Value (Get-NormalizedText $tbPOBox.Text) -ErrorMessage "El campo 'Casilla Postal' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'City' -Value (Get-NormalizedText $tbCity.Text) -ErrorMessage "El campo 'Ciudad' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'State' -Value (Get-NormalizedText $tbState.Text) -ErrorMessage "El campo 'Provincia/Estado' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'PostalCode' -Value (Get-NormalizedText $tbPostalCode.Text) -ErrorMessage "El campo 'Código Postal' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Country' -Value (Get-NormalizedText $tbCountry.Text) -ErrorMessage "El campo 'País/Región' es requerido por política.")) { return }
          $canSetPassword = Test-UserFieldEditable -Mode $mode -Field 'Password'
          if (($canSetPassword) -and ((Test-UserFieldRequired -Mode $mode -Field 'Password') -or (-not [string]::IsNullOrWhiteSpace($pwdPlain)) -or (-not [string]::IsNullOrWhiteSpace($pwdConfirm)))) {
            if ([string]::IsNullOrWhiteSpace($pwdPlain) -or [string]::IsNullOrWhiteSpace($pwdConfirm)) {
              Show-Error "El campo contraseña es requerido por política."
              return
            }
          }
          if ($canSetPassword -and ((-not [string]::IsNullOrWhiteSpace($pwdPlain)) -or (-not [string]::IsNullOrWhiteSpace($pwdConfirm))) -and ($pwdPlain -ne $pwdConfirm)) {
            Show-Error "Las contraseñas no coinciden."
            return
          }
          if ((Test-UserFieldEditable -Mode $mode -Field 'MustChangePassword') -and (Test-UserFieldEditable -Mode $mode -Field 'CannotChangePassword') -and (Get-Checked $cbMustChange) -and (Get-Checked $cbCannotChange)) {
            Show-Error "No podés marcar a la vez 'debe cambiar contraseña' y 'no puede cambiar contraseña'."
            return
          }

          $adp = Get-ADParams
          $domainRoot = (Get-ADDomainCached -adParams $adp).DNSRoot

          $upn = "$effectiveUpnUser@$domainRoot"
          $safeSam = Escape-ADFilterLiteral $effectiveSam
          $safeUpn = Escape-ADFilterLiteral $upn
          $safeCn = Escape-ADFilterLiteral $effectiveCn

          $existingSam = Get-ADUser @adp -Filter "SamAccountName -eq '$safeSam'" -ResultSetSize 1 -ErrorAction SilentlyContinue
          if ($existingSam) {
            Show-Error "El SAM '$effectiveSam' ya existe. Corregí el dato y volvé a intentar."
            return
          }

          $existingUpn = Get-ADUser @adp -Filter "UserPrincipalName -eq '$safeUpn'" -ResultSetSize 1 -ErrorAction SilentlyContinue
          if ($existingUpn) {
            Show-Error "El UPN '$upn' ya existe. Corregí el dato y volvé a intentar."
            return
          }

          $params = @{
            Name              = $effectiveCn
            SamAccountName    = $effectiveSam
            UserPrincipalName = $upn
            ErrorAction       = 'Stop'
          }

          if ((Test-UserFieldEditable -Mode $mode -Field 'FirstName') -and (-not [string]::IsNullOrWhiteSpace($fn))) { $params.GivenName = $fn }
          if ((Test-UserFieldEditable -Mode $mode -Field 'LastName') -and (-not [string]::IsNullOrWhiteSpace($ln))) { $params.Surname = $ln }
          if ((Test-UserFieldEditable -Mode $mode -Field 'DisplayName') -and (-not [string]::IsNullOrWhiteSpace($displayName))) { $params.DisplayName = $displayName }
          if ((Test-UserFieldEditable -Mode $mode -Field 'Initials') -and (-not [string]::IsNullOrWhiteSpace($tbInitials.Text))) { $params.Initials = $tbInitials.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'Description') -and (-not [string]::IsNullOrWhiteSpace($tbDescription.Text))) { $params.Description = $tbDescription.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'Email') -and (-not [string]::IsNullOrWhiteSpace($tbEmail.Text))) { $params.EmailAddress = $tbEmail.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'Office') -and (-not [string]::IsNullOrWhiteSpace($tbOffice.Text))) { $params.Office = $tbOffice.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'OfficePhone') -and (-not [string]::IsNullOrWhiteSpace($tbOfficePhone.Text))) { $params.OfficePhone = $tbOfficePhone.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'WebPage') -and (-not [string]::IsNullOrWhiteSpace($tbWebPage.Text))) { $params.HomePage = $tbWebPage.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'StreetAddress') -and (-not [string]::IsNullOrWhiteSpace($tbStreetAddress.Text))) { $params.StreetAddress = $tbStreetAddress.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'POBox') -and (-not [string]::IsNullOrWhiteSpace($tbPOBox.Text))) { $params.POBox = $tbPOBox.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'City') -and (-not [string]::IsNullOrWhiteSpace($tbCity.Text))) { $params.City = $tbCity.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'State') -and (-not [string]::IsNullOrWhiteSpace($tbState.Text))) { $params.State = $tbState.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'PostalCode') -and (-not [string]::IsNullOrWhiteSpace($tbPostalCode.Text))) { $params.PostalCode = $tbPostalCode.Text.Trim() }
          if ((Test-UserFieldEditable -Mode $mode -Field 'Country') -and (-not [string]::IsNullOrWhiteSpace($tbCountry.Text))) { $params.Country = $tbCountry.Text.Trim() }

          $hasPassword = $canSetPassword -and (-not [string]::IsNullOrWhiteSpace($pwdPlain))
          if ($hasPassword) {
            $params.AccountPassword = (ConvertTo-SecureString $pwdPlain -AsPlainText -Force)
          }

          if (Test-UserFieldEditable -Mode $mode -Field 'Enabled') {
            $params.Enabled = if ($hasPassword) { (Get-Checked $cbEnabled) } else { $false }
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'MustChangePassword') { $params.ChangePasswordAtLogon = (Get-Checked $cbMustChange) }
          if (Test-UserFieldEditable -Mode $mode -Field 'CannotChangePassword') { $params.CannotChangePassword = (Get-Checked $cbCannotChange) }
          if (Test-UserFieldEditable -Mode $mode -Field 'PasswordNeverExpires') { $params.PasswordNeverExpires = (Get-Checked $cbPwdNeverExpires) }

          if ($selectedOU -and ($selectedOU -match '^(?i)(OU|CN)=Domain Controllers,')) {
            Show-Error "Por seguridad no se permite crear usuarios en 'Domain Controllers'. Seleccioná otra OU."
            return
          }
          if (-not [string]::IsNullOrWhiteSpace($selectedOU)) {
            $existingName = Get-ADObject @adp -SearchBase $selectedOU -SearchScope OneLevel -Filter "Name -eq '$safeCn'" -ResultSetSize 1 -ErrorAction SilentlyContinue
            if ($existingName) {
              Show-Error "Ya existe un objeto con nombre '$effectiveCn' en el contenedor seleccionado. Corregí el nombre y volvé a intentar."
              return
            }
            if (Test-UserFieldEditable -Mode $mode -Field 'OU') { $params.Path = $selectedOU }
          }

          $newUserParams = Merge-ADParams -params $params -adParams $adp
          $createdReal = Invoke-AdWriteOperation `
            -Action { New-ADUser @newUserParams } `
            -AuditAction 'Crear Usuario' `
            -AuditObject $effectiveSam `
            -SuccessStatus "✅ Usuario '$effectiveCn' creado." `
            -SimulatedStatus "[SIMULATION] Usuario '$effectiveCn' validado para creacion."
          if ($createdReal) {
            [System.Windows.MessageBox]::Show("Usuario '$effectiveCn' creado correctamente.", "Éxito", "OK", "Information") | Out-Null
          }
          $dlg.Close()
        }
        catch {
          $msg = $_.Exception.Message
          Write-AuditLog -Action 'Crear Usuario' -Result 'ERROR' -Object $effectiveSam -Detail $msg
          Show-Error "No se pudo crear el usuario. Corregí los datos y volvé a intentar.`n`nDetalle: $msg"
        }
      }.GetNewClosure())

    $dlg.ShowDialog() | Out-Null
  })

# Copiar perfil de usuario (similar a ADUC)
$btnUserCopyProfile.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $sel = Get-SelectedUser; if (-not $sel) { return }

    try {
      $adp = Get-ADParams
      $src = Get-ADUser @adp -Identity $sel.SamAccountName -Properties GivenName, Surname, EmailAddress, Company, Office, DistinguishedName, Name, SamAccountName

      $dlg = New-DialogWindow "Copiar Perfil: $($src.SamAccountName)" 480 620
      $sp = New-Object System.Windows.Controls.StackPanel; $sp.Margin = '16'

      $sp.Children.Add((New-DlgLabel "Usuario origen: $($src.SamAccountName)"))

      $sp.Children.Add((New-DlgLabel "Nombre:")); $tbFirstName = New-DlgTextBox $src.GivenName; $sp.Children.Add($tbFirstName)
      $sp.Children.Add((New-DlgLabel "Apellido:")); $tbLastName = New-DlgTextBox $src.Surname; $sp.Children.Add($tbLastName)

      $sp.Children.Add((New-DlgLabel "SamAccountName (nuevo):"))
      $tbSam = New-DlgTextBox
      $sp.Children.Add($tbSam)

      $updateSam = {
        $f = Get-NormalizedText $tbFirstName.Text
        $l = Get-NormalizedText $tbLastName.Text
        if ((-not [string]::IsNullOrWhiteSpace($f)) -and (-not [string]::IsNullOrWhiteSpace($l))) {
          $tbSam.Text = ($f.Substring(0, 1) + $l).ToLower() -replace '\s', ''
        }
        else {
          $tbSam.Text = ''
        }
      }
      $tbFirstName.Add_TextChanged($updateSam)
      $tbLastName.Add_TextChanged($updateSam)
      & $updateSam

      $sp.Children.Add((New-DlgLabel "Email:")); $tbEmail = New-DlgTextBox $src.EmailAddress; $sp.Children.Add($tbEmail)
      $sp.Children.Add((New-DlgLabel "Empresa:")); $tbCompany = New-DlgTextBox $src.Company; $sp.Children.Add($tbCompany)
      $sp.Children.Add((New-DlgLabel "Oficina:")); $tbOffice = New-DlgTextBox $src.Office; $sp.Children.Add($tbOffice)
      $sp.Children.Add((New-DlgLabel "Contraseña inicial:")); $tbPwd = New-DlgPasswordBox; $sp.Children.Add($tbPwd)
      $sp.Children.Add((New-DlgLabel "Repetir contraseña inicial:")); $tbPwdConfirm = New-DlgPasswordBox; $sp.Children.Add($tbPwdConfirm)

      $sp.Children.Add((New-DlgLabel "Unidad Organizativa (OU):"))
      $cbOU = New-DlgComboBox @() 0
      $cbOU.MinWidth = 380
      $cbOU.MaxDropDownHeight = 320
      $cbOU.DisplayMemberPath = 'Label'
      $cbOU.SelectedValuePath = 'DistinguishedName'
      $sp.Children.Add($cbOU)

      $srcOuDn = Get-OUFromDN $src.DistinguishedName
      try {
        $domainInfo = Get-ADDomainCached -adParams $adp
        $usersContainerDn = $domainInfo.UsersContainer
        $ouDns = Get-ADOrganizationalUnit @adp -Filter * -Properties DistinguishedName |
        Sort-Object DistinguishedName |
        Select-Object -ExpandProperty DistinguishedName

        if ((-not [string]::IsNullOrWhiteSpace($usersContainerDn)) -and (-not ($ouDns -contains $usersContainerDn))) {
          $ouDns += $usersContainerDn
        }

        $ouDns = @(
          $ouDns |
          Where-Object { $_ -and ($_ -notmatch '^(?i)(OU|CN)=Domain Controllers,') } |
          Sort-Object -Unique
        )

        $cbOU.Items.Clear() | Out-Null
        foreach ($ouDn in @($ouDns)) {
          if (-not [string]::IsNullOrWhiteSpace($ouDn)) {
            $cbOU.Items.Add([PSCustomObject]@{
                Label             = (Get-ContainerLabelFromDN $ouDn)
                DistinguishedName = $ouDn
              }) | Out-Null
          }
        }
        if ($cbOU.Items.Count -gt 0) {
          $prefIdx = -1
          for ($i = 0; $i -lt $cbOU.Items.Count; $i++) {
            if ([string]$cbOU.Items[$i].DistinguishedName -eq [string]$srcOuDn) { $prefIdx = $i; break }
          }
          if ($prefIdx -ge 0) { $cbOU.SelectedIndex = $prefIdx } else { $cbOU.SelectedIndex = 0 }
        }
      }
      catch {
        Show-Exception "Error cargando OUs para copiar perfil:" $_
      }

      $cbEnabled = New-Object System.Windows.Controls.CheckBox
      $cbEnabled.Content = "Cuenta habilitada"
      $cbEnabled.IsChecked = $true
      $cbEnabled.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
      $cbEnabled.Margin = '0,10,0,0'
      $sp.Children.Add($cbEnabled)

      $btnCreate = New-DlgButton "Crear Copia de Perfil" 'Success'
      $sp.Children.Add($btnCreate)

      $scroll = New-Object System.Windows.Controls.ScrollViewer
      $scroll.Content = $sp
      $dlg.Content = $scroll

      $btnCreate.Add_Click({
          try {
            $fn = Get-NormalizedText $tbFirstName.Text
            $ln = Get-NormalizedText $tbLastName.Text
            $sam = Get-NormalizedText $tbSam.Text
            $pwdPlain = $tbPwd.Password
            $pwdConfirm = $tbPwdConfirm.Password

            if ([string]::IsNullOrWhiteSpace($fn) -or [string]::IsNullOrWhiteSpace($ln) -or [string]::IsNullOrWhiteSpace($sam) -or [string]::IsNullOrWhiteSpace($pwdPlain) -or [string]::IsNullOrWhiteSpace($pwdConfirm)) {
              Show-Error "Completá Nombre, Apellido, SamAccountName y ambas contraseñas."
              return
            }
            if ($pwdPlain -ne $pwdConfirm) {
              Show-Error "Las contraseñas no coinciden."
              return
            }
            if ($sam -eq $src.SamAccountName) {
              Show-Error "El SamAccountName del nuevo usuario debe ser distinto al usuario origen."
              return
            }
            if (($fn -eq (Get-NormalizedText $src.GivenName)) -and ($ln -eq (Get-NormalizedText $src.Surname))) {
              Show-Error "Debés cambiar el nombre/apellido respecto del usuario origen."
              return
            }

            $attrChanged = $false
            foreach ($pair in @(
                @{ New = (Get-NormalizedText $tbEmail.Text); Source = (Get-NormalizedText $src.EmailAddress) },
                @{ New = (Get-NormalizedText $tbCompany.Text); Source = (Get-NormalizedText $src.Company) },
                @{ New = (Get-NormalizedText $tbOffice.Text); Source = (Get-NormalizedText $src.Office) }
              )) {
              if ($pair.New -ne $pair.Source) { $attrChanged = $true; break }
            }
            if (-not $attrChanged) {
              Show-Error "Debés cambiar al menos un atributo (email, empresa u oficina)."
              return
            }

            $selectedOU = [string]$cbOU.SelectedValue
            if ([string]::IsNullOrWhiteSpace($selectedOU)) { Show-Error "Seleccioná una OU o contenedor destino."; return }
            if ($selectedOU -match '^(?i)(OU|CN)=Domain Controllers,') { Show-Error "Por seguridad no se permite crear usuarios en 'Domain Controllers'."; return }

            $adp2 = Get-ADParams
            $domainRoot = (Get-ADDomainCached -adParams $adp2).DNSRoot
            $name = "$fn $ln"

            $newParams = @{
              Name              = $name
              GivenName         = $fn
              Surname           = $ln
              SamAccountName    = $sam
              UserPrincipalName = "$sam@$domainRoot"
              AccountPassword   = (ConvertTo-SecureString $pwdPlain -AsPlainText -Force)
              Enabled           = (Get-Checked $cbEnabled)
              Path              = $selectedOU
              EmailAddress      = (Get-NormalizedText $tbEmail.Text)
              Company           = (Get-NormalizedText $tbCompany.Text)
              Office            = (Get-NormalizedText $tbOffice.Text)
            }

            $createParams = @{}
            foreach ($k in $newParams.Keys) {
              if (-not [string]::IsNullOrWhiteSpace([string]$newParams[$k])) { $createParams[$k] = $newParams[$k] }
            }

            $createParams = Merge-ADParams -params $createParams -adParams $adp2
            $groupErrors = @()
            $createdReal = Invoke-AdWriteOperation `
              -Action {
                New-ADUser @createParams

                $newUser = Get-ADUser @adp2 -Identity $sam -Properties DistinguishedName, SamAccountName
                $sourceGroups = Get-ADPrincipalGroupMembership @adp2 -Identity $src.DistinguishedName
                foreach ($g in @($sourceGroups)) {
                  if ($null -eq $g) { continue }
                  $sidValue = ''
                  if ($g.SID) { $sidValue = $g.SID.Value }
                  if ($sidValue -match '-513$') { continue }
                  try {
                    Add-ADGroupMember @adp2 -Identity $g.DistinguishedName -Members $newUser.DistinguishedName -ErrorAction Stop
                  }
                  catch {
                    $groupErrors += "$($g.Name): $($_.Exception.Message)"
                  }
                }
              } `
              -AuditAction 'Copiar Perfil Usuario' `
              -AuditObject $sam `
              -SuccessStatus "✅ Perfil copiado a '$sam' respetando grupos/permisos." `
              -SimulatedStatus "[SIMULATION] Perfil '$($src.SamAccountName)' validado para copia a '$sam'." `
              -OnSuccess { Raise-ButtonClick $btnUserSearch }

            if ($createdReal) {
              if ($groupErrors.Count -gt 0) {
                $preview = ($groupErrors | Select-Object -First 10) -join "`n - "
                [System.Windows.MessageBox]::Show(
                  "Usuario creado, pero hubo errores copiando algunos grupos:`n - $preview",
                  "Copia de perfil con advertencias",
                  "OK",
                  "Warning"
                ) | Out-Null
                Set-Status "⚠️ Usuario '$sam' creado. Revisá grupos con errores." '#fab387'
                Write-AuditLog -Action 'Copiar Perfil Usuario' -Result 'WARN' -Object $sam -Detail ("Errores de grupos: " + ($groupErrors.Count))
              }
              else {
                [System.Windows.MessageBox]::Show("Perfil copiado correctamente para '$sam'.", "Éxito", "OK", "Information") | Out-Null
              }
            }
            $dlg.Close()
          }
          catch { Show-Exception "Error copiando perfil de usuario:" $_ }
        }.GetNewClosure())

      $dlg.ShowDialog() | Out-Null
    }
    catch { Show-Exception "Error preparando copia de perfil:" $_ }
  })

# Modificar usuario
$btnUserEdit.Add_Click({
    if (-not (Assert-ADModule)) { return }
    if (-not (Assert-UserAdminPermission -Operation 'Modify')) { return }
    $sel = Get-SelectedUser; if (-not $sel) { return }

    try {
      $adp = Get-ADParams
      $user = Get-ADUser @adp -Identity $sel.SamAccountName -Properties GivenName, Initials, Surname, DisplayName, Description, UserPrincipalName, SamAccountName, EmailAddress, Office, OfficePhone, HomePage, StreetAddress, POBox, City, State, PostalCode, Country, DistinguishedName, Name, Enabled, CannotChangePassword, PasswordNeverExpires, pwdLastSet

      $dlg = New-DialogWindow "Modificar Usuario: $($user.SamAccountName)" 560 860
      $sp = New-Object System.Windows.Controls.StackPanel; $sp.Margin = '16'

      $lblFirstName = New-DlgLabel "Nombre:"; $sp.Children.Add($lblFirstName)
      $tbFirstName = New-DlgTextBox $user.GivenName; $sp.Children.Add($tbFirstName)
      $lblInitials = New-DlgLabel "Iniciales:"; $sp.Children.Add($lblInitials)
      $tbInitials = New-DlgTextBox $user.Initials; $sp.Children.Add($tbInitials)
      $lblLastName = New-DlgLabel "Apellido:"; $sp.Children.Add($lblLastName)
      $tbLastName = New-DlgTextBox $user.Surname; $sp.Children.Add($tbLastName)
      $lblFullName = New-DlgLabel "Nombre completo (CN):"; $sp.Children.Add($lblFullName)
      $tbFullName = New-DlgTextBox $user.Name; $sp.Children.Add($tbFullName)
      $lblDisplayName = New-DlgLabel "Nombre para mostrar:"; $sp.Children.Add($lblDisplayName)
      $tbDisplayName = New-DlgTextBox $user.DisplayName; $sp.Children.Add($tbDisplayName)
      $lblDescription = New-DlgLabel "Descripción:"; $sp.Children.Add($lblDescription)
      $tbDescription = New-DlgTextBox $user.Description; $sp.Children.Add($tbDescription)
      $lblOffice = New-DlgLabel "Oficina:"; $sp.Children.Add($lblOffice)
      $tbOffice = New-DlgTextBox $user.Office; $sp.Children.Add($tbOffice)
      $lblOfficePhone = New-DlgLabel "Teléfono:"; $sp.Children.Add($lblOfficePhone)
      $tbOfficePhone = New-DlgTextBox $user.OfficePhone; $sp.Children.Add($tbOfficePhone)
      $lblEmail = New-DlgLabel "Email:"; $sp.Children.Add($lblEmail)
      $tbEmail = New-DlgTextBox $user.EmailAddress; $sp.Children.Add($tbEmail)
      $lblWebPage = New-DlgLabel "Página Web:"; $sp.Children.Add($lblWebPage)
      $tbWebPage = New-DlgTextBox $user.HomePage; $sp.Children.Add($tbWebPage)

      $lblStreetAddress = New-DlgLabel "Calle:"; $sp.Children.Add($lblStreetAddress)
      $tbStreetAddress = New-DlgTextBox $user.StreetAddress
      $tbStreetAddress.AcceptsReturn = $true
      $tbStreetAddress.Height = 60
      $tbStreetAddress.TextWrapping = 'Wrap'
      $tbStreetAddress.VerticalScrollBarVisibility = 'Auto'
      $sp.Children.Add($tbStreetAddress)
      $lblPOBox = New-DlgLabel "Casilla Postal:"; $sp.Children.Add($lblPOBox)
      $tbPOBox = New-DlgTextBox $user.POBox; $sp.Children.Add($tbPOBox)
      $lblCity = New-DlgLabel "Ciudad:"; $sp.Children.Add($lblCity)
      $tbCity = New-DlgTextBox $user.City; $sp.Children.Add($tbCity)
      $lblState = New-DlgLabel "Provincia/Estado:"; $sp.Children.Add($lblState)
      $tbState = New-DlgTextBox $user.State; $sp.Children.Add($tbState)
      $lblPostalCode = New-DlgLabel "Código Postal:"; $sp.Children.Add($lblPostalCode)
      $tbPostalCode = New-DlgTextBox $user.PostalCode; $sp.Children.Add($tbPostalCode)
      $lblCountry = New-DlgLabel "País/Región:"; $sp.Children.Add($lblCountry)
      $tbCountry = New-DlgTextBox $user.Country; $sp.Children.Add($tbCountry)

      $lblUpn = New-DlgLabel "Nombre de inicio de sesión (UPN):"; $sp.Children.Add($lblUpn)
      $upnGrid = New-Object System.Windows.Controls.Grid
      $upnGrid.ColumnDefinitions.Add((New-Object System.Windows.Controls.ColumnDefinition -Property @{ Width = '*' }))
      $upnGrid.ColumnDefinitions.Add((New-Object System.Windows.Controls.ColumnDefinition -Property @{ Width = 'Auto' }))
      $upnUserPart = ''
      if ((-not [string]::IsNullOrWhiteSpace($user.UserPrincipalName)) -and ($user.UserPrincipalName -match '^([^@]+)@')) { $upnUserPart = $matches[1] }
      if ([string]::IsNullOrWhiteSpace($upnUserPart)) { $upnUserPart = $user.SamAccountName }
      $tbUpnUser = New-DlgTextBox $upnUserPart
      $tbUpnUser.Margin = '0,0,6,0'
      [System.Windows.Controls.Grid]::SetColumn($tbUpnUser, 0)
      $lblUpnSuffix = New-Object System.Windows.Controls.TextBlock
      $lblUpnSuffix.VerticalAlignment = 'Center'
      $lblUpnSuffix.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextSecondary
      [System.Windows.Controls.Grid]::SetColumn($lblUpnSuffix, 1)
      $upnGrid.Children.Add($tbUpnUser) | Out-Null
      $upnGrid.Children.Add($lblUpnSuffix) | Out-Null
      $sp.Children.Add($upnGrid)

      $lblSam = New-DlgLabel "Nombre de inicio de sesión (anterior a Windows 2000):"; $sp.Children.Add($lblSam)
      $tbSam = New-DlgTextBox $user.SamAccountName
      $sp.Children.Add($tbSam)

      $lblPwd = New-DlgLabel "Nueva contraseña (opcional):"; $sp.Children.Add($lblPwd)
      $tbPwd = New-DlgPasswordBox; $sp.Children.Add($tbPwd)
      $lblPwd2 = New-DlgLabel "Repetir nueva contraseña:"; $sp.Children.Add($lblPwd2)
      $tbPwdConfirm = New-DlgPasswordBox; $sp.Children.Add($tbPwdConfirm)

      $lblOU = New-DlgLabel "Unidad Organizativa (OU):"; $sp.Children.Add($lblOU)
      $cbOU = New-DlgComboBox @() 0
      $cbOU.MinWidth = 420
      $cbOU.MaxDropDownHeight = 320
      $cbOU.DisplayMemberPath = 'Label'
      $cbOU.SelectedValuePath = 'DistinguishedName'
      $cbOU.ToolTip = "Seleccioná la OU o contenedor destino."
      $sp.Children.Add($cbOU)

      try {
        $domainInfo = Get-ADDomainCached -adParams $adp
        $usersContainerDn = $domainInfo.UsersContainer
        $ouDns = Get-ADOrganizationalUnit @adp -Filter * -Properties DistinguishedName |
        Sort-Object DistinguishedName |
        Select-Object -ExpandProperty DistinguishedName

        if ((-not [string]::IsNullOrWhiteSpace($usersContainerDn)) -and (-not ($ouDns -contains $usersContainerDn))) {
          $ouDns += $usersContainerDn
        }

        $ouDns = @(
          $ouDns |
          Where-Object { $_ -and ($_ -notmatch '^(?i)(OU|CN)=Domain Controllers,') } |
          Sort-Object -Unique
        )

        $cbOU.Items.Clear() | Out-Null
        foreach ($ouDn in @($ouDns)) {
          if (-not [string]::IsNullOrWhiteSpace($ouDn)) {
            $cbOU.Items.Add([PSCustomObject]@{
                Label             = (Get-ContainerLabelFromDN $ouDn)
                DistinguishedName = $ouDn
              }) | Out-Null
          }
        }

        $currentOuDn = Get-OUFromDN $user.DistinguishedName
        if ($cbOU.Items.Count -gt 0) {
          $prefIdx = -1
          for ($i = 0; $i -lt $cbOU.Items.Count; $i++) {
            if ([string]$cbOU.Items[$i].DistinguishedName -eq [string]$currentOuDn) { $prefIdx = $i; break }
          }
          if ($prefIdx -ge 0) { $cbOU.SelectedIndex = $prefIdx } else { $cbOU.SelectedIndex = 0 }
        }
      }
      catch {
        Show-Exception "Error cargando OUs para modificar usuario:" $_
      }

      $adpForDomain = Get-ADParams
      $domainRootForUpn = (Get-ADDomainCached -adParams $adpForDomain).DNSRoot
      $lblUpnSuffix.Text = "@$domainRootForUpn"

      $cbMustChange = New-Object System.Windows.Controls.CheckBox
      $cbMustChange.Content = "El usuario debe cambiar la contraseña en el próximo inicio"
      $mustChangeAtLogon = $false
      if ($null -ne $user.pwdLastSet) {
        try { $mustChangeAtLogon = ([Int64]$user.pwdLastSet -eq 0) } catch { $mustChangeAtLogon = $false }
      }
      $cbMustChange.IsChecked = $mustChangeAtLogon
      $cbMustChange.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
      $cbMustChange.Margin = '0,10,0,0'
      $cbMustChange.IsThreeState = $false
      $sp.Children.Add($cbMustChange)

      $cbCannotChange = New-Object System.Windows.Controls.CheckBox
      $cbCannotChange.Content = "El usuario no puede cambiar la contraseña"
      $cbCannotChange.IsChecked = [bool]$user.CannotChangePassword
      $cbCannotChange.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
      $cbCannotChange.Margin = '0,2,0,0'
      $cbCannotChange.IsThreeState = $false
      $sp.Children.Add($cbCannotChange)

      $cbPwdNeverExpires = New-Object System.Windows.Controls.CheckBox
      $cbPwdNeverExpires.Content = "La contraseña nunca expira"
      $cbPwdNeverExpires.IsChecked = [bool]$user.PasswordNeverExpires
      $cbPwdNeverExpires.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
      $cbPwdNeverExpires.Margin = '0,2,0,0'
      $cbPwdNeverExpires.IsThreeState = $false
      $sp.Children.Add($cbPwdNeverExpires)

      $cbEnabled = New-Object System.Windows.Controls.CheckBox
      $cbEnabled.Content = "Cuenta habilitada"
      $cbEnabled.IsChecked = [bool]$user.Enabled
      $cbEnabled.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
      $cbEnabled.Margin = '0,2,0,0'
      $cbEnabled.IsThreeState = $false
      $sp.Children.Add($cbEnabled)

      $modeUi = 'Modify'
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'FirstName' -LabelControl $lblFirstName -InputControl $tbFirstName
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Initials' -LabelControl $lblInitials -InputControl $tbInitials
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'LastName' -LabelControl $lblLastName -InputControl $tbLastName
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'FullName' -LabelControl $lblFullName -InputControl $tbFullName
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'DisplayName' -LabelControl $lblDisplayName -InputControl $tbDisplayName
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Description' -LabelControl $lblDescription -InputControl $tbDescription
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Office' -LabelControl $lblOffice -InputControl $tbOffice
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'OfficePhone' -LabelControl $lblOfficePhone -InputControl $tbOfficePhone
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Email' -LabelControl $lblEmail -InputControl $tbEmail
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'WebPage' -LabelControl $lblWebPage -InputControl $tbWebPage
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'StreetAddress' -LabelControl $lblStreetAddress -InputControl $tbStreetAddress
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'POBox' -LabelControl $lblPOBox -InputControl $tbPOBox
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'City' -LabelControl $lblCity -InputControl $tbCity
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'State' -LabelControl $lblState -InputControl $tbState
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'PostalCode' -LabelControl $lblPostalCode -InputControl $tbPostalCode
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Country' -LabelControl $lblCountry -InputControl $tbCountry
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'UpnUser' -LabelControl $lblUpn -InputControl $upnGrid
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'SamAccountName' -LabelControl $lblSam -InputControl $tbSam
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Password' -LabelControl $lblPwd -InputControl $tbPwd
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'Password' -LabelControl $lblPwd2 -InputControl $tbPwdConfirm
      Apply-UserFieldUiPolicy -Mode $modeUi -Field 'OU' -LabelControl $lblOU -InputControl $cbOU

      $cbMustChange.Visibility = if (Test-UserFieldVisible -Mode $modeUi -Field 'MustChangePassword') { 'Visible' } else { 'Collapsed' }
      $cbMustChange.IsEnabled = Test-UserFieldEditable -Mode $modeUi -Field 'MustChangePassword'
      $cbCannotChange.Visibility = if (Test-UserFieldVisible -Mode $modeUi -Field 'CannotChangePassword') { 'Visible' } else { 'Collapsed' }
      $cbCannotChange.IsEnabled = Test-UserFieldEditable -Mode $modeUi -Field 'CannotChangePassword'
      $cbPwdNeverExpires.Visibility = if (Test-UserFieldVisible -Mode $modeUi -Field 'PasswordNeverExpires') { 'Visible' } else { 'Collapsed' }
      $cbPwdNeverExpires.IsEnabled = Test-UserFieldEditable -Mode $modeUi -Field 'PasswordNeverExpires'
      $cbEnabled.Visibility = if (Test-UserFieldVisible -Mode $modeUi -Field 'Enabled') { 'Visible' } else { 'Collapsed' }
      $cbEnabled.IsEnabled = Test-UserFieldEditable -Mode $modeUi -Field 'Enabled'

      $btnSave = New-DlgButton "Guardar Cambios" 'Primary'
      $sp.Children.Add($btnSave)

      $scroll = New-Object System.Windows.Controls.ScrollViewer
      $scroll.Content = $sp
      $dlg.Content = $scroll

      $btnSave.Add_Click({
        try {
          $mode = 'Modify'
          $fn = Get-NormalizedText $tbFirstName.Text
          $ln = Get-NormalizedText $tbLastName.Text
          $cnName = Get-NormalizedText $tbFullName.Text
            $displayName = Get-NormalizedText $tbDisplayName.Text
            $upnUser = Get-NormalizedText $tbUpnUser.Text
            $sam = Get-NormalizedText $tbSam.Text
          $selectedOU = [string]$cbOU.SelectedValue
          $pwdPlain = $tbPwd.Password
          $pwdConfirm = $tbPwdConfirm.Password

          $effectiveSam = if (Test-UserFieldEditable -Mode $mode -Field 'SamAccountName') { $sam } else { [string]$user.SamAccountName }
          if ([string]::IsNullOrWhiteSpace($effectiveSam)) { $effectiveSam = [string]$user.SamAccountName }
          $effectiveCn = if (Test-UserFieldEditable -Mode $mode -Field 'FullName') { $cnName } else { [string]$user.Name }
          if ([string]::IsNullOrWhiteSpace($effectiveCn)) { $effectiveCn = [string]$user.Name }
          $effectiveUpnUser = if (Test-UserFieldEditable -Mode $mode -Field 'UpnUser') { $upnUser } else { '' }
          if ([string]::IsNullOrWhiteSpace($effectiveUpnUser)) {
            if ((-not [string]::IsNullOrWhiteSpace([string]$user.UserPrincipalName)) -and ([string]$user.UserPrincipalName -match '^([^@]+)@')) {
              $effectiveUpnUser = [string]$matches[1]
            }
            else {
              $effectiveUpnUser = $effectiveSam
            }
          }

          if (-not (Test-UserFieldValue -Mode $mode -Field 'FirstName' -Value $fn -ErrorMessage "El campo 'Nombre' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'LastName' -Value $ln -ErrorMessage "El campo 'Apellido' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'FullName' -Value $effectiveCn -ErrorMessage "El campo 'Nombre completo (CN)' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'UpnUser' -Value $effectiveUpnUser -ErrorMessage "El campo 'UPN' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'SamAccountName' -Value $effectiveSam -ErrorMessage "El campo 'SamAccountName' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'OU' -Value $selectedOU -ErrorMessage "Seleccioná una OU o contenedor destino (requerido por política).")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Initials' -Value (Get-NormalizedText $tbInitials.Text) -ErrorMessage "El campo 'Iniciales' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Description' -Value (Get-NormalizedText $tbDescription.Text) -ErrorMessage "El campo 'Descripción' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Office' -Value (Get-NormalizedText $tbOffice.Text) -ErrorMessage "El campo 'Oficina' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'OfficePhone' -Value (Get-NormalizedText $tbOfficePhone.Text) -ErrorMessage "El campo 'Teléfono' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Email' -Value (Get-NormalizedText $tbEmail.Text) -ErrorMessage "El campo 'Email' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'WebPage' -Value (Get-NormalizedText $tbWebPage.Text) -ErrorMessage "El campo 'Página Web' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'StreetAddress' -Value (Get-NormalizedText $tbStreetAddress.Text) -ErrorMessage "El campo 'Calle' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'POBox' -Value (Get-NormalizedText $tbPOBox.Text) -ErrorMessage "El campo 'Casilla Postal' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'City' -Value (Get-NormalizedText $tbCity.Text) -ErrorMessage "El campo 'Ciudad' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'State' -Value (Get-NormalizedText $tbState.Text) -ErrorMessage "El campo 'Provincia/Estado' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'PostalCode' -Value (Get-NormalizedText $tbPostalCode.Text) -ErrorMessage "El campo 'Código Postal' es requerido por política.")) { return }
          if (-not (Test-UserFieldValue -Mode $mode -Field 'Country' -Value (Get-NormalizedText $tbCountry.Text) -ErrorMessage "El campo 'País/Región' es requerido por política.")) { return }

          if ((Test-UserFieldEditable -Mode $mode -Field 'MustChangePassword') -and (Test-UserFieldEditable -Mode $mode -Field 'CannotChangePassword') -and (Get-Checked $cbMustChange) -and (Get-Checked $cbCannotChange)) {
            Show-Error "No podés marcar a la vez 'debe cambiar contraseña' y 'no puede cambiar contraseña'."
            return
          }
          $canSetPassword = Test-UserFieldEditable -Mode $mode -Field 'Password'
          if ($canSetPassword -and ((-not [string]::IsNullOrWhiteSpace($pwdPlain)) -or (-not [string]::IsNullOrWhiteSpace($pwdConfirm)))) {
            if ([string]::IsNullOrWhiteSpace($pwdPlain) -or [string]::IsNullOrWhiteSpace($pwdConfirm)) {
              Show-Error "Si querés cambiar contraseña, completá ambos campos."
              return
            }
            if ($pwdPlain -ne $pwdConfirm) {
                Show-Error "Las contraseñas no coinciden."
              return
            }
          }
          if ($selectedOU -and ($selectedOU -match '^(?i)(OU|CN)=Domain Controllers,')) { Show-Error "Por seguridad no se permite mover usuarios a 'Domain Controllers'."; return }

          $adp2 = Get-ADParams
          $domainRoot = (Get-ADDomainCached -adParams $adp2).DNSRoot
          $params = @{ Identity = [string]$user.SamAccountName }
          $hasUserChanges = $false
          $clearAttrs = @()
          if ((Test-UserFieldEditable -Mode $mode -Field 'FirstName') -and (-not [string]::IsNullOrWhiteSpace($fn))) { $params.GivenName = $fn; $hasUserChanges = $true }
          if (Test-UserFieldEditable -Mode $mode -Field 'Initials') {
            $initialsValue = Get-NormalizedText $tbInitials.Text
            if (-not [string]::IsNullOrWhiteSpace($initialsValue)) { $params.Initials = $initialsValue } else { $clearAttrs += 'initials' }
            $hasUserChanges = $true
          }
          if ((Test-UserFieldEditable -Mode $mode -Field 'LastName') -and (-not [string]::IsNullOrWhiteSpace($ln))) { $params.Surname = $ln; $hasUserChanges = $true }
          if (Test-UserFieldEditable -Mode $mode -Field 'SamAccountName') { $params.SamAccountName = $effectiveSam; $hasUserChanges = $true }
          if (Test-UserFieldEditable -Mode $mode -Field 'UpnUser') { $params.UserPrincipalName = "$effectiveUpnUser@$domainRoot"; $hasUserChanges = $true }
          if (Test-UserFieldEditable -Mode $mode -Field 'Enabled') { $params.Enabled = (Get-Checked $cbEnabled); $hasUserChanges = $true }
          if (Test-UserFieldEditable -Mode $mode -Field 'MustChangePassword') { $params.ChangePasswordAtLogon = (Get-Checked $cbMustChange); $hasUserChanges = $true }
          if (Test-UserFieldEditable -Mode $mode -Field 'CannotChangePassword') { $params.CannotChangePassword = (Get-Checked $cbCannotChange); $hasUserChanges = $true }
          if (Test-UserFieldEditable -Mode $mode -Field 'PasswordNeverExpires') { $params.PasswordNeverExpires = (Get-Checked $cbPwdNeverExpires); $hasUserChanges = $true }

          if (Test-UserFieldEditable -Mode $mode -Field 'DisplayName') {
            if (-not [string]::IsNullOrWhiteSpace($displayName)) { $params.DisplayName = $displayName } else { $clearAttrs += 'DisplayName' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'Description') {
            if (-not [string]::IsNullOrWhiteSpace($tbDescription.Text)) { $params.Description = $tbDescription.Text.Trim() } else { $clearAttrs += 'description' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'Email') {
            if (-not [string]::IsNullOrWhiteSpace($tbEmail.Text)) { $params.EmailAddress = $tbEmail.Text.Trim() } else { $clearAttrs += 'mail' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'Office') {
            if (-not [string]::IsNullOrWhiteSpace($tbOffice.Text)) { $params.Office = $tbOffice.Text.Trim() } else { $clearAttrs += 'physicalDeliveryOfficeName' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'OfficePhone') {
            if (-not [string]::IsNullOrWhiteSpace($tbOfficePhone.Text)) { $params.OfficePhone = $tbOfficePhone.Text.Trim() } else { $clearAttrs += 'telephoneNumber' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'WebPage') {
            if (-not [string]::IsNullOrWhiteSpace($tbWebPage.Text)) { $params.HomePage = $tbWebPage.Text.Trim() } else { $clearAttrs += 'wWWHomePage' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'StreetAddress') {
            if (-not [string]::IsNullOrWhiteSpace($tbStreetAddress.Text)) { $params.StreetAddress = $tbStreetAddress.Text.Trim() } else { $clearAttrs += 'streetAddress' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'POBox') {
            if (-not [string]::IsNullOrWhiteSpace($tbPOBox.Text)) { $params.POBox = $tbPOBox.Text.Trim() } else { $clearAttrs += 'postOfficeBox' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'City') {
            if (-not [string]::IsNullOrWhiteSpace($tbCity.Text)) { $params.City = $tbCity.Text.Trim() } else { $clearAttrs += 'l' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'State') {
            if (-not [string]::IsNullOrWhiteSpace($tbState.Text)) { $params.State = $tbState.Text.Trim() } else { $clearAttrs += 'st' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'PostalCode') {
            if (-not [string]::IsNullOrWhiteSpace($tbPostalCode.Text)) { $params.PostalCode = $tbPostalCode.Text.Trim() } else { $clearAttrs += 'postalCode' }
            $hasUserChanges = $true
          }
          if (Test-UserFieldEditable -Mode $mode -Field 'Country') {
            if (-not [string]::IsNullOrWhiteSpace($tbCountry.Text)) { $params.Country = $tbCountry.Text.Trim() } else { $clearAttrs += 'co' }
            $hasUserChanges = $true
          }
          if ($clearAttrs.Count -gt 0) { $params.Clear = @($clearAttrs | Sort-Object -Unique) }

          $modifiedReal = Invoke-AdWriteOperation `
            -Action {
              if ($hasUserChanges -or ($clearAttrs.Count -gt 0)) {
                $setParams = Merge-ADParams -params $params -adParams $adp2
                Set-ADUser @setParams
              }

              $lookupIdentity = if (Test-UserFieldEditable -Mode $mode -Field 'SamAccountName') { $effectiveSam } else { [string]$user.SamAccountName }
              $refreshed = Get-ADUser @adp2 -Identity $lookupIdentity -Properties DistinguishedName, Name

              if ($canSetPassword -and (-not [string]::IsNullOrWhiteSpace($pwdPlain))) {
                $pwd = ConvertTo-SecureString $pwdPlain -AsPlainText -Force
                Set-ADAccountPassword @adp2 -Identity $refreshed.DistinguishedName -NewPassword $pwd -Reset
              }
              if ((Test-UserFieldEditable -Mode $mode -Field 'FullName') -and (-not [string]::IsNullOrWhiteSpace($effectiveCn)) -and ($effectiveCn -ne $refreshed.Name)) {
                $renameParams = Merge-ADParams -params @{ Identity = $refreshed.DistinguishedName; NewName = $effectiveCn } -adParams $adp2
                Rename-ADObject @renameParams
                $refreshed = Get-ADUser @adp2 -Identity $lookupIdentity -Properties DistinguishedName, Name
              }

              if ((Test-UserFieldEditable -Mode $mode -Field 'OU') -and (-not [string]::IsNullOrWhiteSpace($selectedOU))) {
                $currentOuAfterUpdate = Get-OUFromDN $refreshed.DistinguishedName
                if ($selectedOU -ne $currentOuAfterUpdate) {
                  Move-ADObject @adp2 -Identity $refreshed.DistinguishedName -TargetPath $selectedOU -ErrorAction Stop
                }
              }
            } `
            -AuditAction 'Modificar Usuario' `
            -AuditObject $effectiveSam `
            -SuccessStatus "✅ Usuario '$effectiveSam' modificado." `
            -SimulatedStatus "[SIMULATION] Cambios validados para el usuario '$effectiveSam'." `
            -OnSuccess { Raise-ButtonClick $btnUserSearch }
          if ($modifiedReal) {
            [System.Windows.MessageBox]::Show("Usuario modificado correctamente.", "Éxito", "OK", "Information") | Out-Null
          }
          $dlg.Close()
          }
          catch { Show-Exception "Error al modificar usuario:" $_ }
        }.GetNewClosure())

      $dlg.ShowDialog() | Out-Null
    }
    catch { Show-Exception "Error preparando edición de usuario:" $_ }
  })

# Resetear contraseña
$btnUserResetPwd.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $sel = Get-SelectedUser; if (-not $sel) { return }

    $dlg = New-DialogWindow "Resetear Contraseña" 400 250
    $sp = New-Object System.Windows.Controls.StackPanel; $sp.Margin = '16'
    $sp.Children.Add((New-DlgLabel "Usuario: $($sel.SamAccountName)"))
    $sp.Children.Add((New-DlgLabel "Nueva contraseña:"))
    $tbPwd = New-DlgPasswordBox; $sp.Children.Add($tbPwd)
    $sp.Children.Add((New-DlgLabel "Repetir nueva contraseña:"))
    $tbPwdConfirm = New-DlgPasswordBox; $sp.Children.Add($tbPwdConfirm)

    $cbChange = New-Object System.Windows.Controls.CheckBox
    $cbChange.Content = "Cambiar contraseña en próximo inicio"
    $cbChange.IsChecked = $true
    $cbChange.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextPrimary
    $cbChange.Margin = '0,8,0,0'
    $cbChange.IsThreeState = $false
    $sp.Children.Add($cbChange)

    $btnReset = New-DlgButton "Resetear" 'Warn'; $sp.Children.Add($btnReset)
    $dlg.Content = $sp

    $btnReset.Add_Click({
        try {
          if ([string]::IsNullOrWhiteSpace($tbPwd.Password) -or [string]::IsNullOrWhiteSpace($tbPwdConfirm.Password)) {
            Show-Error "Ingresá y repetí la nueva contraseña."
            return
          }
          if ($tbPwd.Password -ne $tbPwdConfirm.Password) {
            Show-Error "Las contraseñas no coinciden."
            return
          }
          $adp = Get-ADParams
          $pwd = ConvertTo-SecureString $tbPwd.Password -AsPlainText -Force
          $resetReal = Invoke-AdWriteOperation `
            -Action {
              Set-ADAccountPassword @adp -Identity $sel.SamAccountName -NewPassword $pwd -Reset
              if (Get-Checked $cbChange) { Set-ADUser @adp -Identity $sel.SamAccountName -ChangePasswordAtLogon $true }
            } `
            -AuditAction 'Resetear Contraseña Usuario' `
            -AuditObject ([string]$sel.SamAccountName) `
            -SuccessStatus "✅ Contraseña de '$($sel.SamAccountName)' reseteada." `
            -SimulatedStatus "[SIMULATION] Reset de contraseña validado para '$($sel.SamAccountName)'."
          if ($resetReal) {
            [System.Windows.MessageBox]::Show("Contraseña reseteada.", "Éxito", "OK", "Information") | Out-Null
          }
          $dlg.Close()
        }
        catch { Show-Exception "Error al resetear contraseña:" $_ }
      }.GetNewClosure())

    $dlg.ShowDialog() | Out-Null
  })

# Deshabilitar / Habilitar / Desbloquear / Eliminar
$btnUserDisable.Add_Click({
    Invoke-SelectedUserAction `
      -Action { param($sel) $adp = Get-ADParams; Disable-ADAccount @adp -Identity $sel.SamAccountName } `
      -SuccessMessage "✅ Usuario '{0}' deshabilitado." `
      -ErrorContext "Error deshabilitando usuario:" `
      -ConfirmMessage "¿Deshabilitar al usuario '{0}'?" `
      -AuditAction "Deshabilitar Usuario"
  })
$btnUserEnable.Add_Click({
    Invoke-SelectedUserAction `
      -Action { param($sel) $adp = Get-ADParams; Enable-ADAccount @adp -Identity $sel.SamAccountName } `
      -SuccessMessage "✅ Usuario '{0}' habilitado." `
      -ErrorContext "Error habilitando usuario:" `
      -AuditAction "Habilitar Usuario"
  })
$btnUserUnlock.Add_Click({
    Invoke-SelectedUserAction `
      -Action { param($sel) $adp = Get-ADParams; Unlock-ADAccount @adp -Identity $sel.SamAccountName } `
      -SuccessMessage "✅ Usuario '{0}' desbloqueado." `
      -ErrorContext "Error desbloqueando usuario:" `
      -AuditAction "Desbloquear Usuario"
  })
$btnUserDelete.Add_Click({
    Invoke-SelectedUserAction `
      -Action { param($sel) $adp = Get-ADParams; Remove-ADUser @adp -Identity $sel.SamAccountName -Confirm:$false } `
      -SuccessMessage "✅ Usuario '{0}' eliminado." `
      -ErrorContext "Error eliminando usuario:" `
      -ConfirmMessage "⚠️ ¿Estás seguro de ELIMINAR al usuario '{0}'?`nEsta acción no se puede deshacer." `
      -AuditAction "Eliminar Usuario"
  })

# ── GRUPOS ───────────────────────────────────────────────────────────────────
$btnGroupSearch.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $filter = Get-NormalizedText $txtGroupSearch.Text
    $maxResults = 500
    try {
      [System.Windows.Input.Mouse]::OverrideCursor = [System.Windows.Input.Cursors]::Wait
      Set-Status "Buscando grupos..." '#89b4fa'
      $adp = Get-ADParams

      if ([string]::IsNullOrWhiteSpace($filter)) {
        $groups = Get-ADGroup @adp `
          -Filter * `
          -ResultSetSize ($maxResults + 1) `
          -Properties Name, SamAccountName, GroupCategory, GroupScope, Description |
        Select-Object Name, SamAccountName, GroupCategory, GroupScope, Description, DistinguishedName
      }
      else {
        $safeFilter = Escape-ADFilterLiteral $filter
        $groups = Get-ADGroup @adp `
          -Filter "Name -like '*$safeFilter*' -or SamAccountName -like '*$safeFilter*'" `
          -ResultSetSize ($maxResults + 1) `
          -Properties Name, SamAccountName, GroupCategory, GroupScope, Description |
        Select-Object Name, SamAccountName, GroupCategory, GroupScope, Description, DistinguishedName
      }

      $totalFound = @($groups).Count
      if ($totalFound -gt $maxResults) {
        $groups = @($groups | Select-Object -First $maxResults)
      }

      $dgGroups.ItemsSource = @($groups)
      if ($totalFound -gt $maxResults) {
        Set-Status "⚠️ Se muestran los primeros $maxResults grupos. Refiná la búsqueda para acotar resultados." '#fab387'
      }
      else {
        Set-Status "✅ Se encontraron $($groups.Count) grupo(s)." '#a6e3a1'
      }
    }
    catch { Show-Exception "Error buscando grupos:" $_ }
    finally { [System.Windows.Input.Mouse]::OverrideCursor = $null }
  })
Bind-EnterKeyToButton -textBox $txtGroupSearch -button $btnGroupSearch

$dgGroups.Add_MouseDoubleClick({
    if ($dgGroups.SelectedItem) {
      $btnGroupMembers.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
  })

$btnGroupNew.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $dlg = New-DialogWindow "Crear Nuevo Grupo" 440 400
    $sp = New-Object System.Windows.Controls.StackPanel; $sp.Margin = '16'
    $sp.Children.Add((New-DlgLabel "Nombre del grupo:")); $tbName = New-DlgTextBox; $sp.Children.Add($tbName)
    $sp.Children.Add((New-DlgLabel "Descripción:")); $tbDesc = New-DlgTextBox; $sp.Children.Add($tbDesc)
    $sp.Children.Add((New-DlgLabel "Categoría:")); $cbCat = New-DlgComboBox @('Security', 'Distribution'); $sp.Children.Add($cbCat)
    $sp.Children.Add((New-DlgLabel "Ámbito:")); $cbScope = New-DlgComboBox @('Global', 'Universal', 'DomainLocal'); $sp.Children.Add($cbScope)
    $sp.Children.Add((New-DlgLabel "OU Destino (opcional):")); $tbOU = New-DlgTextBox; $sp.Children.Add($tbOU)
    $btnCreate = New-DlgButton "Crear Grupo" 'Success'; $sp.Children.Add($btnCreate)
    $dlg.Content = $sp

    $btnCreate.Add_Click({
        try {
          $name = Get-RequiredTrimmedText $tbName.Text "Ingresá el nombre del grupo."
          if ($null -eq $name) { return }
          $params = @{
            Name           = $name
            SamAccountName = $name
            GroupCategory  = $cbCat.SelectedItem
            GroupScope     = $cbScope.SelectedItem
          }
          if ($tbDesc.Text.Trim()) { $params.Description = $tbDesc.Text.Trim() }
          if ($tbOU.Text.Trim()) { $params.Path = $tbOU.Text.Trim() }
          $newGroupParams = Merge-ADParams -params $params
          $createdReal = Invoke-AdWriteOperation `
            -Action { New-ADGroup @newGroupParams } `
            -AuditAction 'Crear Grupo' `
            -AuditObject $name `
            -SuccessStatus "✅ Grupo creado." `
            -SimulatedStatus "[SIMULATION] Grupo '$name' validado para creacion."
          if ($createdReal) {
            [System.Windows.MessageBox]::Show("Grupo '$name' creado.", "Éxito", "OK", "Information") | Out-Null
          }
          $dlg.Close()
        }
        catch { Show-Exception "Error al crear grupo:" $_ }
      }.GetNewClosure())

    $dlg.ShowDialog() | Out-Null
  })

$btnGroupAddMember.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $sel = Get-SelectedGroup; if (-not $sel) { return }
    $dlg = New-DialogWindow "Agregar Miembro a: $($sel.Name)" 440 200
    $sp = New-Object System.Windows.Controls.StackPanel; $sp.Margin = '16'
    $sp.Children.Add((New-DlgLabel "SamAccountName del usuario/grupo a agregar:"))
    $tbMember = New-DlgTextBox; $sp.Children.Add($tbMember)
    $btnAdd = New-DlgButton "Agregar" 'Success'; $sp.Children.Add($btnAdd)
    $dlg.Content = $sp

    $btnAdd.Add_Click({
        try {
          $m = Get-RequiredTrimmedText $tbMember.Text "Ingresá el SamAccountName a agregar."
          if ($null -eq $m) { return }
          $adp = Get-ADParams
          $addedReal = Invoke-AdWriteOperation `
            -Action { Add-ADGroupMember @adp -Identity $sel.SamAccountName -Members $m } `
            -AuditAction 'Agregar Miembro a Grupo' `
            -AuditObject ("Grupo: $($sel.Name) | Miembro: $m") `
            -SuccessStatus "✅ Miembro agregado." `
            -SimulatedStatus "[SIMULATION] Alta de miembro validada para '$m' en '$($sel.Name)'."
          if ($addedReal) {
            [System.Windows.MessageBox]::Show("Miembro agregado al grupo '$($sel.Name)'.", "Éxito", "OK", "Information") | Out-Null
          }
          $dlg.Close()
        }
        catch { Show-Exception "Error agregando miembro:" $_ }
      }.GetNewClosure())

    $dlg.ShowDialog() | Out-Null
  })

$btnGroupRemoveMember.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $sel = Get-SelectedGroup; if (-not $sel) { return }
    $dlg = New-DialogWindow "Quitar Miembro de: $($sel.Name)" 440 200
    $sp = New-Object System.Windows.Controls.StackPanel; $sp.Margin = '16'
    $sp.Children.Add((New-DlgLabel "SamAccountName del usuario/grupo a quitar:"))
    $tbMember = New-DlgTextBox; $sp.Children.Add($tbMember)
    $btnRemove = New-DlgButton "Quitar" 'Danger'; $sp.Children.Add($btnRemove)
    $dlg.Content = $sp

    $btnRemove.Add_Click({
        try {
          $m = Get-RequiredTrimmedText $tbMember.Text "Ingresá el SamAccountName a quitar."
          if ($null -eq $m) { return }
          $adp = Get-ADParams
          $removedReal = Invoke-AdWriteOperation `
            -Action { Remove-ADGroupMember @adp -Identity $sel.SamAccountName -Members $m -Confirm:$false } `
            -AuditAction 'Quitar Miembro de Grupo' `
            -AuditObject ("Grupo: $($sel.Name) | Miembro: $m") `
            -SuccessStatus "✅ Miembro quitado." `
            -SimulatedStatus "[SIMULATION] Baja de miembro validada para '$m' en '$($sel.Name)'."
          if ($removedReal) {
            [System.Windows.MessageBox]::Show("Miembro quitado del grupo '$($sel.Name)'.", "Éxito", "OK", "Information") | Out-Null
          }
          $dlg.Close()
        }
        catch { Show-Exception "Error quitando miembro:" $_ }
      }.GetNewClosure())

    $dlg.ShowDialog() | Out-Null
  })

$btnGroupMembers.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $sel = Get-SelectedGroup; if (-not $sel) { return }
    try {
      $theme = Get-ActiveTheme
      $adp = Get-ADParams
      $members = Get-ADGroupMember @adp -Identity $sel.SamAccountName | Select-Object Name, SamAccountName, objectClass
      $dlg = New-DialogWindow "Miembros de: $($sel.Name)" 500 400
      $dg = New-Object System.Windows.Controls.DataGrid
      $dg.AutoGenerateColumns = $true; $dg.IsReadOnly = $true; $dg.CanUserAddRows = $false
      $dg.Background = ConvertTo-Brush $theme.SurfaceBg
      $dg.Foreground = ConvertTo-Brush $theme.TextPrimary
      $dg.BorderBrush = ConvertTo-Brush $theme.Border
      $dg.RowBackground = ConvertTo-Brush $theme.RowBg
      $dg.AlternatingRowBackground = ConvertTo-Brush $theme.RowAltBg
      $dg.HorizontalGridLinesBrush = ConvertTo-Brush $theme.GridLine
      $dg.ItemsSource = @($members)
      $dlg.Content = $dg
      $dlg.ShowDialog() | Out-Null
    }
    catch { Show-Exception "Error obteniendo miembros:" $_ }
  })

$btnGroupDelete.Add_Click({
    Invoke-SelectedGroupAction `
      -Action { param($sel) $adp = Get-ADParams; Remove-ADGroup @adp -Identity $sel.SamAccountName -Confirm:$false } `
      -SuccessMessage "✅ Grupo '{0}' eliminado." `
      -ErrorContext "Error eliminando grupo:" `
      -ConfirmMessage "⚠️ ¿Estás seguro de ELIMINAR el grupo '{0}'?`nEsta acción no se puede deshacer." `
      -AuditAction "Eliminar Grupo"
  })

# ── COMPUTADORAS ─────────────────────────────────────────────────────────────
$btnComputerSearch.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $filter = Get-NormalizedText $txtComputerSearch.Text
    $maxResults = 500

    try {
      [System.Windows.Input.Mouse]::OverrideCursor = [System.Windows.Input.Cursors]::Wait
      Set-Status "Buscando computadoras..." '#89b4fa'
      $adp = Get-ADParams

      if ([string]::IsNullOrWhiteSpace($filter)) {
        $computers = Get-ADComputer @adp `
          -Filter * `
          -ResultSetSize ($maxResults + 1) `
          -Properties Name, SamAccountName, DNSHostName, OperatingSystem, Enabled, DistinguishedName |
        Select-Object Name, SamAccountName, DNSHostName, OperatingSystem, Enabled,
        @{N = 'OUPath'; E = { Get-OUFromDN $_.DistinguishedName } },
        DistinguishedName
      }
      else {
        $safeFilter = Escape-ADFilterLiteral $filter
        $computers = Get-ADComputer @adp `
          -Filter "Name -like '*$safeFilter*' -or SamAccountName -like '*$safeFilter*' -or DNSHostName -like '*$safeFilter*'" `
          -ResultSetSize ($maxResults + 1) `
          -Properties Name, SamAccountName, DNSHostName, OperatingSystem, Enabled, DistinguishedName |
        Select-Object Name, SamAccountName, DNSHostName, OperatingSystem, Enabled,
        @{N = 'OUPath'; E = { Get-OUFromDN $_.DistinguishedName } },
        DistinguishedName
      }

      $totalFound = @($computers).Count
      if ($totalFound -gt $maxResults) {
        $computers = @($computers | Select-Object -First $maxResults)
      }

      $dgComputers.ItemsSource = @($computers)
      if ($totalFound -gt $maxResults) {
        Set-Status "Se muestran las primeras $maxResults computadoras. Refina la busqueda para acotar resultados." '#fab387'
      }
      else {
        Set-Status "Se encontraron $($computers.Count) computadora(s)." '#a6e3a1'
      }
    }
    catch [Microsoft.ActiveDirectory.Management.ADException] {
      Show-Error "No se pudo interpretar el filtro de busqueda. Proba con nombre, SAM o DNS."
    }
    catch { Show-Exception "Error buscando computadoras:" $_ }
    finally { [System.Windows.Input.Mouse]::OverrideCursor = $null }
  })
Bind-EnterKeyToButton -textBox $txtComputerSearch -button $btnComputerSearch
$btnComputerRefresh.Add_Click({ Raise-ButtonClick $btnComputerSearch })

$btnComputerDelete.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $sel = Get-SelectedComputer
    if (-not $sel) { return }

    if (-not (Show-Confirm "¿Borrar el equipo '$($sel.Name)'?`nEsta acción elimina la cuenta de equipo en Active Directory.")) { return }

    try {
      $adp = Get-ADParams
      $deletedReal = Invoke-AdWriteOperation `
        -Action { Remove-ADComputer @adp -Identity $sel.DistinguishedName -Confirm:$false -ErrorAction Stop } `
        -AuditAction 'Eliminar Computadora' `
        -AuditObject ([string]$sel.Name) `
        -SuccessStatus "Computadora '$($sel.Name)' eliminada." `
        -SimulatedStatus "[SIMULATION] Eliminacion validada para '$($sel.Name)'." `
        -OnSuccess { Raise-ButtonClick $btnComputerSearch }
      if ($deletedReal) {
        [System.Windows.MessageBox]::Show("Computadora '$($sel.Name)' eliminada.", "Borrar equipo", "OK", "Information") | Out-Null
      }
    }
    catch {
      Show-Exception "Error borrando computadora:" $_
    }
  })

$btnComputerMove.Add_Click({
    $sel = Get-SelectedComputer
    if (-not $sel) { return }

    Show-MoveAdObjectDialog `
      -DistinguishedName ([string]$sel.DistinguishedName) `
      -DisplayName ([string]$sel.Name) `
      -ObjectType 'computadora' `
      -OnSuccess { Raise-ButtonClick $btnComputerSearch }
  })

$btnComputerAddToGroup.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $sel = Get-SelectedComputer
    if (-not $sel) { return }

    $dlg = New-DialogWindow "Agregar computadora a grupo" 460 240
    $sp = New-Object System.Windows.Controls.StackPanel
    $sp.Margin = '16'
    $sp.Children.Add((New-DlgLabel "Computadora seleccionada:"))
    $sp.Children.Add((New-DlgLabel $sel.Name))
    $sp.Children.Add((New-DlgLabel "Grupo destino (nombre o SAM):"))
    $tbGroup = New-DlgTextBox
    $sp.Children.Add($tbGroup)
    $btnAdd = New-DlgButton "Agregar a grupo" 'Primary'
    $sp.Children.Add($btnAdd)
    $dlg.Content = $sp

    $btnAdd.Add_Click({
        try {
          $groupInput = Get-RequiredTrimmedText $tbGroup.Text "Ingresá el nombre o SAM del grupo destino."
          if ($null -eq $groupInput) { return }

          $adp = Get-ADParams
          $safeGroup = Escape-ADFilterLiteral $groupInput
          $group = Get-ADGroup @adp `
            -Filter "Name -eq '$safeGroup' -or SamAccountName -eq '$safeGroup'" `
            -Properties Name, SamAccountName `
            -ErrorAction Stop |
          Select-Object -First 1

          if (-not $group) {
            Show-Error "No se encontro un grupo que coincida con '$groupInput'."
            return
          }

          $addedReal = Invoke-AdWriteOperation `
            -Action { Add-ADGroupMember @adp -Identity $group.SamAccountName -Members $sel.DistinguishedName -ErrorAction Stop } `
            -AuditAction 'Agregar Computadora a Grupo' `
            -AuditObject ("Computadora: $($sel.Name) | Grupo: $($group.SamAccountName)") `
            -SuccessStatus "Computadora '$($sel.Name)' agregada al grupo '$($group.SamAccountName)'." `
            -SimulatedStatus "[SIMULATION] Alta validada para '$($sel.Name)' en '$($group.SamAccountName)'."
          if ($addedReal) {
            [System.Windows.MessageBox]::Show("Computadora '$($sel.Name)' agregada al grupo '$($group.SamAccountName)'.", "Agregar a grupo", "OK", "Information") | Out-Null
          }
          $dlg.Close()
        }
        catch {
          Show-Exception "Error agregando computadora al grupo:" $_
        }
      }.GetNewClosure())

    $dlg.ShowDialog() | Out-Null
  })

