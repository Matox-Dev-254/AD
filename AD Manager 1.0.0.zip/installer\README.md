# AD Manager Installer

Fase 1 de instalacion para despliegue interno.

## Instalar

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\installer\install.ps1
```

Opciones:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\installer\install.ps1 -NoDesktopShortcut
powershell.exe -ExecutionPolicy Bypass -File .\installer\install.ps1 -Silent
```

## Generar copia de distribucion

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\installer\build-release.ps1
powershell.exe -ExecutionPolicy Bypass -File .\installer\build-release.ps1 -Zip
```

## Desinstalar

Desinstalacion estandar:

```powershell
powershell.exe -ExecutionPolicy Bypass -File "C:\Program Files\AD Manager\installer\uninstall.ps1"
```

Desinstalacion completa:

```powershell
powershell.exe -ExecutionPolicy Bypass -File "C:\Program Files\AD Manager\installer\uninstall.ps1" -Purge
```

## Comportamiento

- Instala binarios en `C:\Program Files\AD Manager\`
- Crea acceso directo en Inicio y Escritorio por defecto
- Conserva configuracion compartida en `C:\ProgramData\ADManager\`
- Conserva configuracion por usuario en `%LOCALAPPDATA%\ADManager\`
- Conserva logs por defecto salvo `-Purge`
- Registra la app en `Programas y caracteristicas`
- Permite generar una copia separada en `dist\` para distribucion
