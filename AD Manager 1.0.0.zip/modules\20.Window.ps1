﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 20.Window.ps1

# ── CARGAR VENTANA ────────────────────────────────────────────────────────────
$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

function Get-Control([string]$name) { $window.FindName($name) }

$txtStatus = Get-Control 'txtStatus'
$txtUserSearch = Get-Control 'txtUserSearch'
$btnUserSearch = Get-Control 'btnUserSearch'
$btnUserRefresh = Get-Control 'btnUserRefresh'
$dgUsers = Get-Control 'dgUsers'
$btnUserNew = Get-Control 'btnUserNew'
$btnUserCopyProfile = Get-Control 'btnUserCopyProfile'
$btnUserEdit = Get-Control 'btnUserEdit'
$btnUserResetPwd = Get-Control 'btnUserResetPwd'
$btnUserDisable = Get-Control 'btnUserDisable'
$btnUserEnable = Get-Control 'btnUserEnable'
$btnUserUnlock = Get-Control 'btnUserUnlock'
$btnUserDelete = Get-Control 'btnUserDelete'

$txtGroupSearch = Get-Control 'txtGroupSearch'
$btnGroupSearch = Get-Control 'btnGroupSearch'
$dgGroups = Get-Control 'dgGroups'
$btnGroupNew = Get-Control 'btnGroupNew'
$btnGroupAddMember = Get-Control 'btnGroupAddMember'
$btnGroupRemoveMember = Get-Control 'btnGroupRemoveMember'
$btnGroupMembers = Get-Control 'btnGroupMembers'
$btnGroupDelete = Get-Control 'btnGroupDelete'

$txtComputerSearch = Get-Control 'txtComputerSearch'
$btnComputerSearch = Get-Control 'btnComputerSearch'
$btnComputerRefresh = Get-Control 'btnComputerRefresh'
$dgComputers = Get-Control 'dgComputers'
$btnComputerDelete = Get-Control 'btnComputerDelete'
$btnComputerMove = Get-Control 'btnComputerMove'
$btnComputerAddToGroup = Get-Control 'btnComputerAddToGroup'

$dgMoveObjects = Get-Control 'dgMoveObjects'
$btnMoveExecute = Get-Control 'btnMoveExecute'
$btnMoveRefreshSourceOU = Get-Control 'btnMoveRefreshSourceOU'
$btnMoveRefreshTargetOU = Get-Control 'btnMoveRefreshTargetOU'
$btnMoveLoadFromSource = Get-Control 'btnMoveLoadFromSource'
$btnMoveLoadFromTarget = Get-Control 'btnMoveLoadFromTarget'
$btnMoveNewOU = Get-Control 'btnMoveNewOU'
$btnMoveDeleteOU = Get-Control 'btnMoveDeleteOU'
$dgMoveTargetObjects = Get-Control 'dgMoveTargetObjects'
$tvMoveSourceOUs = Get-Control 'tvMoveSourceOUs'
$tvMoveTargetOUs = Get-Control 'tvMoveTargetOUs'

$txtBatchCsvPath = Get-Control 'txtBatchCsvPath'
$btnBatchBrowseCsv = Get-Control 'btnBatchBrowseCsv'
$btnBatchTemplate = Get-Control 'btnBatchTemplate'
$btnBatchTemplateEmpty = Get-Control 'btnBatchTemplateEmpty'
$btnBatchPreview = Get-Control 'btnBatchPreview'
$btnBatchExecute = Get-Control 'btnBatchExecute'
$btnBatchExportReport = Get-Control 'btnBatchExportReport'
$dgBatchResults = Get-Control 'dgBatchResults'

$txtAttrSearch = Get-Control 'txtAttrSearch'
$btnAttrSearch = Get-Control 'btnAttrSearch'
$btnAttrClear = Get-Control 'btnAttrClear'
$txtAttrDN = Get-Control 'txtAttrDN'
$dgAttributes = Get-Control 'dgAttributes'
$btnAttrSave = Get-Control 'btnAttrSave'
$chkAuditEnableCentral = Get-Control 'chkAuditEnableCentral'
$cbAuditMode = Get-Control 'cbAuditMode'
$txtAuditCentralFilePath = Get-Control 'txtAuditCentralFilePath'
$btnAuditBrowseCentralFile = Get-Control 'btnAuditBrowseCentralFile'
$txtAuditSqlConnection = Get-Control 'txtAuditSqlConnection'
$txtAuditSqlTable = Get-Control 'txtAuditSqlTable'
$txtAuditDiagnostics = Get-Control 'txtAuditDiagnostics'
$btnAuditDiagScrollDown = Get-Control 'btnAuditDiagScrollDown'
$btnAuditApplyConfig = Get-Control 'btnAuditApplyConfig'
$btnAuditSaveConfig = Get-Control 'btnAuditSaveConfig'
$btnAuditLoadConfig = Get-Control 'btnAuditLoadConfig'
$btnAuditDiagnoseConfig = Get-Control 'btnAuditDiagnoseConfig'
$btnAuditTestConfig = Get-Control 'btnAuditTestConfig'
 $borderUserSearchPanel = Get-Control 'borderUserSearchPanel'
 $borderUserActionsPanel = Get-Control 'borderUserActionsPanel'
 $borderGroupSearchPanel = Get-Control 'borderGroupSearchPanel'
 $borderGroupActionsPanel = Get-Control 'borderGroupActionsPanel'
 $borderComputerSearchPanel = Get-Control 'borderComputerSearchPanel'
 $borderComputerActionsPanel = Get-Control 'borderComputerActionsPanel'
 $borderAttrSearchPanel = Get-Control 'borderAttrSearchPanel'
 $borderAttrActionsPanel = Get-Control 'borderAttrActionsPanel'
 $borderConfigHeaderPanel = Get-Control 'borderConfigHeaderPanel'
 $borderConfigBodyPanel = Get-Control 'borderConfigBodyPanel'
 $borderConfigActionsPanel = Get-Control 'borderConfigActionsPanel'

$borderHeader = Get-Control 'borderHeader'
$headerDragZone = Get-Control 'headerDragZone'
$txtTitle = Get-Control 'txtTitle'
$txtSubtitle = Get-Control 'txtSubtitle'
$btnMinimizeApp = Get-Control 'btnMinimizeApp'
$btnMaximizeApp = Get-Control 'btnMaximizeApp'
$btnCloseApp = Get-Control 'btnCloseApp'
$btnThemeToggle = Get-Control 'btnThemeToggle'

$borderDomainBar = Get-Control 'borderDomainBar'
$txtDomainLabel = Get-Control 'txtDomainLabel'
$cbDomainSelect = Get-Control 'cbDomainSelect'
$btnDomainConnect = Get-Control 'btnDomainConnect'
$btnDomainDisconnect = Get-Control 'btnDomainDisconnect'
$chkSimulationMode = Get-Control 'chkSimulationMode'
$txtDomainInfo = Get-Control 'txtDomainInfo'

$borderStatus = $txtStatus.Parent
$tabControl = Get-Control 'mainTabControl'

function Invoke-WindowDragMove {
  try {
    if ([System.Windows.Input.Mouse]::LeftButton -eq [System.Windows.Input.MouseButtonState]::Pressed) {
      $window.DragMove()
    }
  }
  catch {
    # Evitar ruido si el drag se corta por un cambio de estado.
  }
}

if ($headerDragZone) {
  $headerDragZone.Add_MouseLeftButtonDown({
      if ($_.ClickCount -ge 2) {
        if ($window.WindowState -eq [System.Windows.WindowState]::Maximized) {
          $window.WindowState = [System.Windows.WindowState]::Normal
        }
        else {
          $window.WindowState = [System.Windows.WindowState]::Maximized
        }
        $_.Handled = $true
        return
      }
      Invoke-WindowDragMove
    })
}

if ($borderHeader) {
  $borderHeader.Add_MouseLeftButtonDown({
      if ($_.OriginalSource -is [System.Windows.Controls.Button]) { return }
      Invoke-WindowDragMove
    })
}

if ($btnMinimizeApp) {
  $btnMinimizeApp.Add_Click({ $window.WindowState = [System.Windows.WindowState]::Minimized })
}

if ($btnMaximizeApp) {
  $btnMaximizeApp.Add_Click({
      if ($window.WindowState -eq [System.Windows.WindowState]::Maximized) {
        $window.WindowState = [System.Windows.WindowState]::Normal
      }
      else {
        $window.WindowState = [System.Windows.WindowState]::Maximized
      }
    })
}

if ($btnCloseApp) {
  $btnCloseApp.Add_Click({ $window.Close() })
}

