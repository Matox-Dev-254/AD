﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 00.Bootstrap.ps1

# Si estamos en PowerShell 7+ (MTA), relanzar con Windows PowerShell (STA)
if ($PSVersionTable.PSVersion.Major -ge 7 -or [System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
  $wpExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  if (Test-Path $wpExe) {
    Start-Process $wpExe -ArgumentList "-ExecutionPolicy Bypass -NoProfile -STA -File `"$PSCommandPath`"" -WindowStyle Hidden -Wait
    return
  }
  else {
    Write-Warning "No se encontró Windows PowerShell. Ejecutá con: powershell.exe -STA -File `"$PSCommandPath`""
    return
  }
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class ConsoleWindowHelper {
  [DllImport("kernel32.dll")]
  public static extern IntPtr GetConsoleWindow();

  [DllImport("user32.dll")]
  public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
"@

function Hide-ConsoleWindow {
  try {
    $consoleHandle = [ConsoleWindowHelper]::GetConsoleWindow()
    if (($null -ne $consoleHandle) -and ($consoleHandle -ne [IntPtr]::Zero)) {
      [ConsoleWindowHelper]::ShowWindow($consoleHandle, 0) | Out-Null
    }
  }
  catch {
    # Si no se puede ocultar, continuar sin bloquear la app.
  }
}

# Verificar/instalar módulo AD (offline/local)
$script:ADModuleAvailable = $false
$script:ADModuleImportedInSession = $false
$script:ADInstallAttempted = $false
$script:SimulationMode = $false
$script:WhatIfPreference = $false
$global:ProgressPreference = 'SilentlyContinue'
$script:AdManagerInstallRoot = Split-Path -Path $PSScriptRoot -Parent
$script:AdManagerProgramDataRoot = if (-not [string]::IsNullOrWhiteSpace([string]$env:ProgramData)) { Join-Path $env:ProgramData 'ADManager' } else { Join-Path $script:AdManagerInstallRoot 'Data' }
$script:AdManagerLocalDataRoot = if (-not [string]::IsNullOrWhiteSpace([string]$env:LOCALAPPDATA)) { Join-Path $env:LOCALAPPDATA 'ADManager' } else { Join-Path $script:AdManagerInstallRoot 'UserData' }

function Get-AdManagerProgramDataPath([string]$childPath = '') {
  if ([string]::IsNullOrWhiteSpace($childPath)) { return $script:AdManagerProgramDataRoot }
  return (Join-Path $script:AdManagerProgramDataRoot $childPath)
}

function Get-AdManagerLocalDataPath([string]$childPath = '') {
  if ([string]::IsNullOrWhiteSpace($childPath)) { return $script:AdManagerLocalDataRoot }
  return (Join-Path $script:AdManagerLocalDataRoot $childPath)
}

function Ensure-ParentDirectory([string]$path) {
  if ([string]::IsNullOrWhiteSpace($path)) { return }
  $parent = Split-Path -Path $path -Parent
  if ((-not [string]::IsNullOrWhiteSpace($parent)) -and (-not (Test-Path -Path $parent -PathType Container))) {
    New-Item -Path $parent -ItemType Directory -Force | Out-Null
  }
}

function Test-IsAdministrator {
  try {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object System.Security.Principal.WindowsPrincipal($id)
    return $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
  }
  catch {
    return $false
  }
}

function Install-RSATFromWindowsUpdate {
  $capabilities = @(
    'Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0',
    'Rsat.GroupPolicy.Management.Tools~~~~0.0.1.0'
  )

  foreach ($capName in $capabilities) {
    try {
      if (Get-Command Add-WindowsCapability -ErrorAction SilentlyContinue) {
        Add-WindowsCapability -Online -Name $capName -ErrorAction Stop | Out-Null
      }
      else {
        $dismArgs = "/online /add-capability /capabilityname:$capName /quiet /norestart"
        $proc = Start-Process -FilePath dism.exe -ArgumentList $dismArgs -Wait -PassThru -NoNewWindow
        if (($proc.ExitCode -ne 0) -and ($proc.ExitCode -ne 3010)) {
          throw "DISM devolvió ExitCode $($proc.ExitCode) instalando $capName."
        }
      }
    }
    catch {
      return $false
    }
  }

  return [bool](Get-Module -ListAvailable -Name ActiveDirectory)
}

function Ensure-ADModuleAvailable {
  if (Get-Module -ListAvailable -Name ActiveDirectory) {
    $script:ADModuleAvailable = $true
    return
  }

  $script:ADModuleAvailable = $false
  $script:ADInstallAttempted = $true

  if (-not (Test-IsAdministrator)) {
    Write-Warning "RSAT no está instalado. Para instalar automáticamente desde Windows Update/Internet, ejecutá este script como administrador."
    return
  }

  if (Install-RSATFromWindowsUpdate) {
    if (Get-Module -ListAvailable -Name ActiveDirectory) {
      $script:ADModuleAvailable = $true
      return
    }
  }
}

Hide-ConsoleWindow
Ensure-ADModuleAvailable

function Assert-ADModule {
  if (-not $script:ADModuleAvailable) {
    [System.Windows.MessageBox]::Show(
      "El módulo ActiveDirectory (RSAT) no está instalado.`n`nIntento automático:`n- Ejecutar como administrador`n- Instalar desde Windows Update/Internet`n`nSi no se instala, podés hacerlo manualmente desde Características opcionales.`n`nLa GUI se puede ver pero las funciones AD no van a funcionar.",
      "Módulo AD no disponible", "OK", "Warning"
    ) | Out-Null
    return $false
  }

  if (-not $script:ADModuleImportedInSession) {
    try {
      Import-Module ActiveDirectory -ErrorAction Stop
      $script:ADModuleImportedInSession = $true
    }
    catch {
      [System.Windows.MessageBox]::Show(
        "El módulo ActiveDirectory está instalado pero no se pudo cargar en la sesión actual.`n`nDetalle:`n$($_.Exception.Message)",
        "Módulo AD no disponible", "OK", "Warning"
      ) | Out-Null
      return $false
    }
  }

  return $true
}

function Start-ADSessionWarmup {
  if ((-not $script:ADModuleAvailable) -or $script:ADModuleImportedInSession) { return }
  try {
    Import-Module ActiveDirectory -ErrorAction Stop
    $script:ADModuleImportedInSession = $true
  }
  catch {
    # Si falla el warm-up, la primera operacion real reintentara via Assert-ADModule.
  }
}
