﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 70.Operations.ps1

# ── MOVER ────────────────────────────────────────────────────────────────────
$script:MoveViewInitialized = $false

function Initialize-MoveViewIfNeeded {
  if ($script:MoveViewInitialized) { return }
  if (-not (Assert-ADModule)) { return }

  Load-OUTreeForControl $tvMoveSourceOUs
  Load-OUTreeForControl -treeView $tvMoveTargetOUs -HideProtectedContainers
  $script:MoveViewInitialized = $true
}

function Load-OUTreeForControl(
  [System.Windows.Controls.TreeView]$treeView,
  [switch]$HideProtectedContainers
) {
  if (-not (Assert-ADModule)) { return }
  try {
    [System.Windows.Input.Mouse]::OverrideCursor = [System.Windows.Input.Cursors]::Wait
    $treeView.Items.Clear()
    $adp = Get-ADParams
    $domain = Get-ADDomainCached -adParams $adp

    $rootItem = New-Object System.Windows.Controls.TreeViewItem
    $rootItem.Header = $domain.DNSRoot
    $rootItem.Tag = $domain.DistinguishedName
    $rootItem.IsExpanded = $true
    $theme = Get-ActiveTheme
    $rootItem.Foreground = ConvertTo-Brush $theme.TreeItemFg

    # Traer OUs y contenedores para verse como ADUC (Users, Computers, Builtin, etc.).
    $nodes = Get-ADObject @adp `
      -SearchBase $domain.DistinguishedName `
      -SearchScope Subtree `
      -LDAPFilter "(|(objectClass=organizationalUnit)(objectClass=container))" `
      -Properties Name, DistinguishedName, ObjectClass |
    Where-Object {
      ($_.DistinguishedName -ne $domain.DistinguishedName) -and
      ($_.Name -ne 'DomainUpdates')
    } |
    Sort-Object DistinguishedName

    if ($HideProtectedContainers) {
      $nodes = @($nodes | Where-Object { -not (Is-ProtectedContainerDN $_.DistinguishedName) })
    }

    $nodeHash = @{}
    foreach ($ou in $nodes) {
      $item = New-Object System.Windows.Controls.TreeViewItem
      $item.Header = $ou.Name
      $item.Tag = $ou.DistinguishedName
      $item.Foreground = ConvertTo-Brush $theme.TreeItemFg
      $nodeHash[$ou.DistinguishedName] = $item
    }

    foreach ($ou in $nodes) {
      $parentDN = Get-OUFromDN $ou.DistinguishedName
      if ($nodeHash.ContainsKey($parentDN)) {
        $nodeHash[$parentDN].Items.Add($nodeHash[$ou.DistinguishedName]) | Out-Null
      }
      else {
        $rootItem.Items.Add($nodeHash[$ou.DistinguishedName]) | Out-Null
      }
    }

    $treeView.Items.Add($rootItem) | Out-Null
  }
  catch { Show-Exception "Error cargando OUs:" $_ }
  finally { [System.Windows.Input.Mouse]::OverrideCursor = $null }
}
$btnMoveRefreshSourceOU.Add_Click({
    $script:MoveViewInitialized = $true
    Load-OUTreeForControl $tvMoveSourceOUs
    Set-Status "✅ OUs de origen recargadas." '#a6e3a1'
  })
$btnMoveRefreshTargetOU.Add_Click({
    $script:MoveViewInitialized = $true
    Load-OUTreeForControl -treeView $tvMoveTargetOUs -HideProtectedContainers
    Set-Status "✅ OUs de destino recargadas." '#a6e3a1'
  })

$btnMoveNewOU.Add_Click({
    Initialize-MoveViewIfNeeded
    if (-not (Assert-ADModule)) { return }
    $parentOU = $tvMoveTargetOUs.SelectedItem
    $parentDN = Get-TreeSelectionDN -treeView $tvMoveTargetOUs `
      -selectionMessage "Seleccioná una OU/contendor padre en destino." `
      -invalidDnMessage "La OU padre no es válida." `
      -DenyProtected `
      -protectedMessage "Por seguridad no se permite crear OUs dentro de 'Domain Controllers'."
    if ($null -eq $parentDN) { return }

    $dlg = New-DialogWindow "Crear OU" 420 210
    $sp = New-Object System.Windows.Controls.StackPanel; $sp.Margin = '16'
    $sp.Children.Add((New-DlgLabel "Padre: $($parentOU.Header)"))
    $sp.Children.Add((New-DlgLabel "Nombre de la nueva OU:"))
    $tbName = New-DlgTextBox; $sp.Children.Add($tbName)
    $btnCreateOU = New-DlgButton "Crear OU" 'Success'; $sp.Children.Add($btnCreateOU)
    $dlg.Content = $sp

    $btnCreateOU.Add_Click({
        try {
          $name = Get-RequiredTrimmedText $tbName.Text "Ingresá el nombre de la OU."
          if ($null -eq $name) { return }
          $adp = Get-ADParams
          Invoke-AdWriteOperation `
            -Action { New-ADOrganizationalUnit @adp -Name $name -Path $parentDN -ProtectedFromAccidentalDeletion $true } `
            -AuditAction 'Crear OU' `
            -AuditObject $name `
            -SuccessStatus "✅ OU '$name' creada." `
            -SimulatedStatus "[SIMULATION] OU '$name' validada para creacion." `
            -OnSuccess {
              Load-OUTreeForControl -treeView $tvMoveTargetOUs -HideProtectedContainers
              Load-OUTreeForControl $tvMoveSourceOUs
            } | Out-Null
          $dlg.Close()
        }
        catch { Show-Exception "Error creando OU:" $_ }
      }.GetNewClosure())

    $dlg.ShowDialog() | Out-Null
  })

$btnMoveDeleteOU.Add_Click({
    Initialize-MoveViewIfNeeded
    if (-not (Assert-ADModule)) { return }
    $selOU = $tvMoveTargetOUs.SelectedItem
    $selDN = Get-TreeSelectionDN -treeView $tvMoveTargetOUs `
      -selectionMessage "Seleccioná la OU a eliminar en destino." `
      -invalidDnMessage "La OU seleccionada no es válida."
    if ($null -eq $selDN) { return }
    if (-not (Test-Guard ($selDN -match '^OU=') "Solo se pueden eliminar objetos tipo OU.")) { return }

    if (Show-Confirm "⚠️ ¿Eliminar OU '$($selOU.Header)'?`nIntentaré quitar la protección por eliminación accidental.") {
      try {
        $adp = Get-ADParams
        Invoke-AdWriteOperation `
          -Action {
            Set-ADOrganizationalUnit @adp -Identity $selDN -ProtectedFromAccidentalDeletion $false -ErrorAction SilentlyContinue
            Remove-ADOrganizationalUnit @adp -Identity $selDN -Recursive -Confirm:$false
          } `
          -AuditAction 'Eliminar OU' `
          -AuditObject ([string]$selOU.Header) `
          -SuccessStatus "✅ OU '$($selOU.Header)' eliminada." `
          -SimulatedStatus "[SIMULATION] Eliminacion validada para la OU '$($selOU.Header)'." `
          -OnSuccess {
            Load-OUTreeForControl -treeView $tvMoveTargetOUs -HideProtectedContainers
            Load-OUTreeForControl $tvMoveSourceOUs
          } | Out-Null
      }
      catch { Show-Exception "Error eliminando OU:" $_ }
    }
  })

function Get-ObjectsForOUDN([string]$dn) {
  $adp = Get-ADParams
  $objs = @()
  $objs += Get-ADUser @adp -SearchBase $dn -SearchScope Subtree -Filter * -Properties Name, DistinguishedName |
  Select-Object Name, @{N = 'ObjectClass'; E = { 'user' } }, @{N = 'OUPath'; E = { Get-OUFromDN $_.DistinguishedName } }, DistinguishedName
  $objs += Get-ADGroup @adp -SearchBase $dn -SearchScope Subtree -Filter * -Properties Name, DistinguishedName |
  Select-Object Name, @{N = 'ObjectClass'; E = { 'group' } }, @{N = 'OUPath'; E = { Get-OUFromDN $_.DistinguishedName } }, DistinguishedName
  $objs += Get-ADComputer @adp -SearchBase $dn -SearchScope Subtree -Filter * -Properties Name, DistinguishedName |
  Select-Object Name, @{N = 'ObjectClass'; E = { 'computer' } }, @{N = 'OUPath'; E = { Get-OUFromDN $_.DistinguishedName } }, DistinguishedName
  $objs += Get-ADOrganizationalUnit @adp -SearchBase $dn -SearchScope Subtree -Filter * -Properties Name, DistinguishedName |
  Where-Object { $_.DistinguishedName -ne $dn } |
  Select-Object Name, @{N = 'ObjectClass'; E = { 'organizationalUnit' } }, @{N = 'OUPath'; E = { Get-OUFromDN $_.DistinguishedName } }, DistinguishedName
  return @($objs)
}

function Show-MoveAdObjectDialog(
  [string]$DistinguishedName,
  [string]$DisplayName,
  [string]$ObjectType = 'objeto',
  [scriptblock]$OnSuccess = $null
) {
  if (-not (Assert-ADModule)) { return }
  if ([string]::IsNullOrWhiteSpace($DistinguishedName)) {
    Show-Error "No se encontro el DN del objeto seleccionado."
    return
  }

  $currentOuDn = Get-OUFromDN $DistinguishedName
  $currentOuLabel = Get-ContainerLabelFromDN $currentOuDn

  $dlg = New-DialogWindow "Mover $ObjectType" 560 620
  $root = New-Object System.Windows.Controls.Grid
  $root.Margin = '16'
  foreach ($rowHeight in @('Auto', 'Auto', 'Auto', 'Auto', 'Auto', '*', 'Auto')) {
    $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = $rowHeight })) | Out-Null
  }

  $lblSelectedTitle = New-DlgLabel "Objeto seleccionado:"
  [System.Windows.Controls.Grid]::SetRow($lblSelectedTitle, 0)
  $root.Children.Add($lblSelectedTitle) | Out-Null

  $lblSelectedValue = New-DlgLabel $DisplayName
  $lblSelectedValue.FontSize = 15
  $lblSelectedValue.FontWeight = 'SemiBold'
  [System.Windows.Controls.Grid]::SetRow($lblSelectedValue, 1)
  $root.Children.Add($lblSelectedValue) | Out-Null

  $lblCurrentOu = New-DlgLabel "OU actual:"
  $lblCurrentOu.Margin = '0,6,0,0'
  [System.Windows.Controls.Grid]::SetRow($lblCurrentOu, 2)
  $root.Children.Add($lblCurrentOu) | Out-Null

  $lblCurrentOuValue = New-DlgLabel $currentOuLabel
  $lblCurrentOuValue.Padding = '0,2,0,6'
  [System.Windows.Controls.Grid]::SetRow($lblCurrentOuValue, 3)
  $root.Children.Add($lblCurrentOuValue) | Out-Null

  $lblTargetOu = New-DlgLabel "OU destino:"
  $lblTargetOu.Margin = '0,8,0,0'
  [System.Windows.Controls.Grid]::SetRow($lblTargetOu, 4)
  $root.Children.Add($lblTargetOu) | Out-Null

  $tvTarget = New-Object System.Windows.Controls.TreeView
  $tvTarget.Margin = '0,6,0,0'
  $tvTarget.MinHeight = 280
  $theme = Get-ActiveTheme
  $tvTarget.Background = ConvertTo-Brush $theme.SurfaceBg
  $tvTarget.Foreground = ConvertTo-Brush $theme.TextPrimary
  $tvTarget.BorderBrush = ConvertTo-Brush $theme.Border
  [System.Windows.Controls.Grid]::SetRow($tvTarget, 5)
  $root.Children.Add($tvTarget) | Out-Null

  $actions = New-Object System.Windows.Controls.WrapPanel
  $actions.Margin = '0,12,0,0'
  $actions.HorizontalAlignment = 'Right'
  $btnRefresh = New-DlgButton "Recargar OUs" 'Primary'
  $btnRefresh.Margin = '0,0,8,0'
  $btnMove = New-DlgButton "Mover" 'Warn'
  $btnMove.Margin = '0'
  $actions.Children.Add($btnRefresh) | Out-Null
  $actions.Children.Add($btnMove) | Out-Null
  [System.Windows.Controls.Grid]::SetRow($actions, 6)
  $root.Children.Add($actions) | Out-Null
  $dlg.Content = $root

  $refreshTree = {
    Load-OUTreeForControl -treeView $tvTarget -HideProtectedContainers
  }.GetNewClosure()

  $btnRefresh.Add_Click($refreshTree)
  & $refreshTree

  $btnMove.Add_Click({
      $targetDN = Get-TreeSelectionDN -treeView $tvTarget `
        -selectionMessage "Seleccioná una OU de destino." `
        -invalidDnMessage "La OU de destino no es valida." `
        -DenyProtected `
        -protectedMessage "Por seguridad no se permite mover objetos a 'Domain Controllers'."
      if ($null -eq $targetDN) { return }
      if ($targetDN -eq $currentOuDn) {
        Show-Error "La computadora ya se encuentra en esa OU."
        return
      }

      $targetItem = $tvTarget.SelectedItem
      $targetLabel = if ($targetItem) { [string]$targetItem.Header } else { Get-ContainerLabelFromDN $targetDN }
      if (-not (Show-Confirm "Mover '$DisplayName' a '$targetLabel'?")) { return }

      try {
        $adp = Get-ADParams
        $movedReal = Invoke-AdWriteOperation `
          -Action { Move-ADObject @adp -Identity $DistinguishedName -TargetPath $targetDN -ErrorAction Stop } `
          -AuditAction 'Mover Computadora OU' `
          -AuditObject ("Computadora: $DisplayName | Destino: $targetDN") `
          -SuccessStatus "Computadora '$DisplayName' movida." `
          -SimulatedStatus "[SIMULATION] Movimiento validado para '$DisplayName'." `
          -OnSuccess $OnSuccess
        if ($movedReal) {
          [System.Windows.MessageBox]::Show("Computadora '$DisplayName' movida correctamente.", "Mover computadora", "OK", "Information") | Out-Null
        }
        $dlg.Close()
      }
      catch {
        Show-Exception "Error moviendo computadora:" $_
      }
    }.GetNewClosure())

  $dlg.ShowDialog() | Out-Null
}

$btnMoveLoadFromSource.Add_Click({
    Initialize-MoveViewIfNeeded
    if (-not (Assert-ADModule)) { return }
    $sourceDN = Get-TreeSelectionDN -treeView $tvMoveSourceOUs `
      -selectionMessage "Seleccioná una OU de origen." `
      -invalidDnMessage "La OU de origen no es válida."
    if ($null -eq $sourceDN) { return }

    try {
      [System.Windows.Input.Mouse]::OverrideCursor = [System.Windows.Input.Cursors]::Wait
      Set-Status "Cargando objetos desde OU origen..." '#89b4fa'
      $objs = Get-ObjectsForOUDN -dn $sourceDN
      $dgMoveObjects.ItemsSource = @($objs)
      Set-Status "✅ Se encontraron $($objs.Count) objeto(s) en origen." '#a6e3a1'
    }
    catch { Show-Exception "Error cargando objetos de OU origen:" $_ }
    finally { [System.Windows.Input.Mouse]::OverrideCursor = $null }
  })

$btnMoveLoadFromTarget.Add_Click({
    Initialize-MoveViewIfNeeded
    if (-not (Assert-ADModule)) { return }
    $targetDN = Get-TreeSelectionDN -treeView $tvMoveTargetOUs `
      -selectionMessage "Seleccioná una OU de destino." `
      -invalidDnMessage "La OU de destino no es válida." `
      -DenyProtected `
      -protectedMessage "Por seguridad no se permite operar sobre 'Domain Controllers' como destino."
    if ($null -eq $targetDN) { return }

    try {
      [System.Windows.Input.Mouse]::OverrideCursor = [System.Windows.Input.Cursors]::Wait
      Set-Status "Cargando objetos desde OU destino..." '#89b4fa'
      $objs = Get-ObjectsForOUDN -dn $targetDN
      $dgMoveTargetObjects.ItemsSource = @($objs)
      Set-Status "✅ Se encontraron $($objs.Count) objeto(s) en destino." '#a6e3a1'
    }
    catch { Show-Exception "Error cargando objetos de OU destino:" $_ }
    finally { [System.Windows.Input.Mouse]::OverrideCursor = $null }
  })

$btnMoveExecute.Add_Click({
    Initialize-MoveViewIfNeeded
    if (-not (Assert-ADModule)) { return }
    $sourceDN = Get-TreeSelectionDN -treeView $tvMoveSourceOUs `
      -selectionMessage "Seleccioná una OU de origen." `
      -invalidDnMessage "La OU de origen no es válida."
    if ($null -eq $sourceDN) { return }
    $selectedItems = @($dgMoveObjects.SelectedItems)
    if (-not (Test-Guard ($selectedItems.Count -gt 0) "Seleccioná uno o más objetos de la lista.")) { return }
    $targetOU = $tvMoveTargetOUs.SelectedItem
    $targetDN = Get-TreeSelectionDN -treeView $tvMoveTargetOUs `
      -selectionMessage "Seleccioná una OU de destino." `
      -invalidDnMessage "La OU de destino no es válida." `
      -DenyProtected `
      -protectedMessage "Por seguridad no se permite mover objetos a 'Domain Controllers'."
    if ($null -eq $targetDN) { return }

    $confirmMsg = if ($selectedItems.Count -eq 1) {
      "¿Mover '$($selectedItems[0].Name)' a '$($targetOU.Header)'?"
    }
    else {
      "¿Mover $($selectedItems.Count) objetos a '$($targetOU.Header)'?"
    }

    if (Show-Confirm $confirmMsg) {
      try {
        $adp = Get-ADParams
        $moved = @()
        $failed = @()

        foreach ($sel in $selectedItems) {
          try {
            if (-not $script:SimulationMode) {
              Move-ADObject @adp -Identity $sel.DistinguishedName -TargetPath $targetDN -ErrorAction Stop
            }
            $moved += $sel.Name
          }
          catch {
            $failed += [PSCustomObject]@{
              Name    = $sel.Name
              Message = $_.Exception.Message
            }
          }
        }

        $resultTag = if ($script:SimulationMode) { 'SIMULATED' } else { 'OK' }
        if ($failed.Count -eq 0) {
          if ($script:SimulationMode) {
            if ($moved.Count -eq 1) {
              $statusText = "[SIMULATION] '$($moved[0])' validado para mover a '$($targetOU.Header)'."
            }
            else {
              $statusText = "[SIMULATION] $($moved.Count) objeto(s) validados para mover a '$($targetOU.Header)'."
            }
            $statusColor = '#fab387'
          }
          else {
            if ($moved.Count -eq 1) {
              $statusText = "✅ '$($moved[0])' movido a '$($targetOU.Header)'."
            }
            else {
              $statusText = "✅ $($moved.Count) objeto(s) movidos a '$($targetOU.Header)'."
            }
            $statusColor = '#a6e3a1'
          }
          Set-Status $statusText $statusColor
          Write-AuditLog -Action 'Mover Objetos OU' -Result $resultTag -Object ("Destino: $($targetOU.Header) | Cantidad: $($moved.Count)")
        }
        else {
          $warnResult = if ($script:SimulationMode) { 'SIMULATED' } else { 'WARN' }
          Set-Status "⚠️ Movidos: $($moved.Count). Fallidos: $($failed.Count)." '#fab387'
          Write-AuditLog -Action 'Mover Objetos OU' -Result $warnResult -Object ("Destino: $($targetOU.Header) | Movidos: $($moved.Count) | Fallidos: $($failed.Count)")
          $preview = ($failed | Select-Object -First 8 | ForEach-Object { " - $($_.Name): $($_.Message)" }) -join "`n"
          [System.Windows.MessageBox]::Show(
            "Finalizó con errores.`n`nMovidos: $($moved.Count)`nFallidos: $($failed.Count)`n`n$preview",
            "Mover múltiples objetos",
            "OK",
            "Warning"
          ) | Out-Null
        }

        Raise-ButtonClick $btnMoveLoadFromSource
        Raise-ButtonClick $btnMoveLoadFromTarget
      }
      catch { Show-Exception "Error al mover:" $_ }
    }
  })

if ($tabControl) {
  $tabControl.Add_SelectionChanged({
      if ($_.Source -ne $tabControl) { return }
      $selectedTab = $tabControl.SelectedItem
      if (($selectedTab -is [System.Windows.Controls.TabItem]) -and ([string]$selectedTab.Header -eq 'Mover')) {
        Initialize-MoveViewIfNeeded
      }
    })
}

# ── LOTE CSV ─────────────────────────────────────────────────────────────────
$script:batchLastResults = @()
$script:batchLastReportPath = $null

function Get-CsvValue($row, [string]$name) {
  if ($null -eq $row) { return '' }
  $prop = $row.PSObject.Properties[$name]
  if ($null -eq $prop -or $null -eq $prop.Value) { return '' }
  return ([string]$prop.Value).Trim()
}

function ConvertTo-BoolOrDefault([string]$value, [bool]$defaultValue = $false) {
  if ([string]::IsNullOrWhiteSpace($value)) { return $defaultValue }
  switch -Regex ($value.Trim().ToLowerInvariant()) {
    '^(1|true|t|si|sí|yes|y|on)$' { return $true }
    '^(0|false|f|no|n|off)$' { return $false }
    default { return $defaultValue }
  }
}

function Get-BatchIdentity($row) {
  $id = Get-CsvValue $row 'Identity'
  if ([string]::IsNullOrWhiteSpace($id)) { $id = Get-CsvValue $row 'SamAccountName' }
  if ([string]::IsNullOrWhiteSpace($id)) { $id = Get-CsvValue $row 'DistinguishedName' }
  return $id
}

function New-BatchResult([int]$rowNumber, [string]$action, [string]$identity, [string]$status, [string]$message) {
  return [PSCustomObject]@{
    Row      = $rowNumber
    Action   = $action
    Identity = $identity
    Status   = $status
    Message  = $message
  }
}

function Invoke-BatchCsvProcess([string]$csvPath, [switch]$Preview) {
  if (-not (Assert-ADModule)) { return @() }

  $path = Get-RequiredTrimmedText $csvPath "Seleccioná un archivo CSV."
  if ($null -eq $path) { return @() }
  if (-not (Test-Path -Path $path -PathType Leaf)) {
    Show-Error "No existe el archivo: $path"
    return @()
  }

  try {
    $rows = Import-Csv -Path $path -ErrorAction Stop
  }
  catch {
    Show-Exception "Error leyendo CSV:" $_
    return @()
  }

  if ($null -eq $rows -or $rows.Count -eq 0) {
    Show-Error "El CSV está vacío."
    return @()
  }

  $simulate = $Preview.IsPresent -or $script:SimulationMode
  $modeLabel = if ($simulate) { "SIMULACIÓN" } else { "EJECUCIÓN" }
  Set-Status "Procesando lote CSV ($modeLabel)..." '#89b4fa'

  $results = @()
  $adp = Get-ADParams
  $domainRoot = ''
  try { $domainRoot = (Get-ADDomainCached -adParams $adp).DNSRoot } catch {}

  for ($idx = 0; $idx -lt $rows.Count; $idx++) {
    $rowNumber = $idx + 1
    $row = $rows[$idx]
    $actionRaw = Get-CsvValue $row 'Action'
    $action = $actionRaw.ToLowerInvariant()
    $identity = Get-BatchIdentity $row

    try {
      if ([string]::IsNullOrWhiteSpace($action)) {
        throw "Falta columna Action en fila $rowNumber (valores: Alta, Modificar, Baja, Mover)."
      }

      switch ($action) {
        'alta' {
          $fn = Get-CsvValue $row 'FirstName'
          $ln = Get-CsvValue $row 'LastName'
          $sam = Get-CsvValue $row 'SamAccountName'
          $upnUser = Get-CsvValue $row 'UpnUser'
          $cnName = Get-CsvValue $row 'FullName'
          $displayName = Get-CsvValue $row 'DisplayName'
          $ou = Get-CsvValue $row 'OU'
          $pwdPlain = Get-CsvValue $row 'Password'

          if ([string]::IsNullOrWhiteSpace($fn) -or [string]::IsNullOrWhiteSpace($ln) -or [string]::IsNullOrWhiteSpace($sam) -or [string]::IsNullOrWhiteSpace($ou)) {
            throw "Alta requiere FirstName, LastName, SamAccountName y OU."
        }
          if ($ou -match '^(?i)(OU|CN)=Domain Controllers,') {
            throw "No se permite crear usuarios en 'Domain Controllers'."
          }
          if ([string]::IsNullOrWhiteSpace($cnName)) { $cnName = "$fn $ln" }
          if ([string]::IsNullOrWhiteSpace($displayName)) { $displayName = $cnName }
          if ([string]::IsNullOrWhiteSpace($upnUser)) { $upnUser = $sam }
          if ([string]::IsNullOrWhiteSpace($pwdPlain) -and (-not $simulate)) {
            throw "Alta requiere Password en ejecución real."
          }

          $params = @{
            Name              = $cnName
            GivenName         = $fn
            Surname           = $ln
            SamAccountName    = $sam
            UserPrincipalName = "$upnUser@$domainRoot"
            DisplayName       = $displayName
            Enabled           = (ConvertTo-BoolOrDefault (Get-CsvValue $row 'Enabled') $true)
            Path              = $ou
            WhatIf            = $simulate
          }
          $initials = Get-CsvValue $row 'Initials'
          if (-not [string]::IsNullOrWhiteSpace($initials)) { $params.Initials = $initials }
          if (-not [string]::IsNullOrWhiteSpace($pwdPlain)) { $params.AccountPassword = (ConvertTo-SecureString $pwdPlain -AsPlainText -Force) }

          $email = Get-CsvValue $row 'Email'
          if (-not [string]::IsNullOrWhiteSpace($email)) { $params.EmailAddress = $email }
          $office = Get-CsvValue $row 'Office'
          if (-not [string]::IsNullOrWhiteSpace($office)) { $params.Office = $office }

          $createParams = Merge-ADParams -params $params -adParams $adp
          New-ADUser @createParams

          $mustChange = ConvertTo-BoolOrDefault (Get-CsvValue $row 'MustChangePassword') $true
          $cannotChange = ConvertTo-BoolOrDefault (Get-CsvValue $row 'CannotChangePassword') $false
          $neverExpires = ConvertTo-BoolOrDefault (Get-CsvValue $row 'PasswordNeverExpires') $false

          $postParams = Merge-ADParams -params @{
            Identity              = $sam
            ChangePasswordAtLogon = $mustChange
            CannotChangePassword  = $cannotChange
            PasswordNeverExpires  = $neverExpires
            WhatIf                = $simulate
          } -adParams $adp

          Set-ADUser @postParams
          $identity = $sam
        }
        'modificar' {
          if ([string]::IsNullOrWhiteSpace($identity)) { throw "Modificar requiere Identity o SamAccountName." }

          $params = Merge-ADParams -params @{
            Identity = $identity
            WhatIf   = $simulate
          } -adParams $adp

          $fn = Get-CsvValue $row 'FirstName'
          $ini = Get-CsvValue $row 'Initials'
          $ln = Get-CsvValue $row 'LastName'
          $displayName = Get-CsvValue $row 'DisplayName'
          $upnUser = Get-CsvValue $row 'UpnUser'
          $sam = Get-CsvValue $row 'SamAccountName'

          if (-not [string]::IsNullOrWhiteSpace($fn)) { $params.GivenName = $fn }
          if (-not [string]::IsNullOrWhiteSpace($ini)) { $params.Initials = $ini }
          if (-not [string]::IsNullOrWhiteSpace($ln)) { $params.Surname = $ln }
          if (-not [string]::IsNullOrWhiteSpace($displayName)) { $params.DisplayName = $displayName }
          if (-not [string]::IsNullOrWhiteSpace($sam)) { $params.SamAccountName = $sam; $identity = $sam }
          if (-not [string]::IsNullOrWhiteSpace($upnUser)) { $params.UserPrincipalName = "$upnUser@$domainRoot" }

          $email = Get-CsvValue $row 'Email'
          $title = Get-CsvValue $row 'Title'
          $dept = Get-CsvValue $row 'Department'
          $company = Get-CsvValue $row 'Company'
          $office = Get-CsvValue $row 'Office'
          $phone = Get-CsvValue $row 'OfficePhone'
          $desc = Get-CsvValue $row 'Description'
          if (-not [string]::IsNullOrWhiteSpace($email)) { $params.EmailAddress = $email }
          if (-not [string]::IsNullOrWhiteSpace($title)) { $params.Title = $title }
          if (-not [string]::IsNullOrWhiteSpace($dept)) { $params.Department = $dept }
          if (-not [string]::IsNullOrWhiteSpace($company)) { $params.Company = $company }
          if (-not [string]::IsNullOrWhiteSpace($office)) { $params.Office = $office }
          if (-not [string]::IsNullOrWhiteSpace($phone)) { $params.OfficePhone = $phone }
          if (-not [string]::IsNullOrWhiteSpace($desc)) { $params.Description = $desc }

          $enabledRaw = Get-CsvValue $row 'Enabled'
          if (-not [string]::IsNullOrWhiteSpace($enabledRaw)) { $params.Enabled = (ConvertTo-BoolOrDefault $enabledRaw $true) }
          $mustChangeRaw = Get-CsvValue $row 'MustChangePassword'
          if (-not [string]::IsNullOrWhiteSpace($mustChangeRaw)) { $params.ChangePasswordAtLogon = (ConvertTo-BoolOrDefault $mustChangeRaw $false) }
          $cannotChangeRaw = Get-CsvValue $row 'CannotChangePassword'
          if (-not [string]::IsNullOrWhiteSpace($cannotChangeRaw)) { $params.CannotChangePassword = (ConvertTo-BoolOrDefault $cannotChangeRaw $false) }
          $neverExpiresRaw = Get-CsvValue $row 'PasswordNeverExpires'
          if (-not [string]::IsNullOrWhiteSpace($neverExpiresRaw)) { $params.PasswordNeverExpires = (ConvertTo-BoolOrDefault $neverExpiresRaw $false) }

          Set-ADUser @params

          $newPwd = Get-CsvValue $row 'NewPassword'
          if (-not [string]::IsNullOrWhiteSpace($newPwd)) {
            $pwd = ConvertTo-SecureString $newPwd -AsPlainText -Force
            Set-ADAccountPassword @adp -Identity $identity -NewPassword $pwd -Reset -WhatIf:$simulate
          }

          $newCn = Get-CsvValue $row 'FullName'
          if (-not [string]::IsNullOrWhiteSpace($newCn)) {
            $obj = Get-ADUser @adp -Identity $identity -Properties DistinguishedName, Name
            if ($obj.Name -ne $newCn) {
              Rename-ADObject @adp -Identity $obj.DistinguishedName -NewName $newCn -WhatIf:$simulate
            }
          }

          $targetOu = Get-CsvValue $row 'OU'
          if (-not [string]::IsNullOrWhiteSpace($targetOu)) {
            if ($targetOu -match '^(?i)(OU|CN)=Domain Controllers,') { throw "No se permite mover a 'Domain Controllers'." }
            $obj = Get-ADUser @adp -Identity $identity -Properties DistinguishedName
            Move-ADObject @adp -Identity $obj.DistinguishedName -TargetPath $targetOu -WhatIf:$simulate
          }
        }
        'baja' {
          if ([string]::IsNullOrWhiteSpace($identity)) { throw "Baja requiere Identity o SamAccountName." }
          $delete = ConvertTo-BoolOrDefault (Get-CsvValue $row 'Delete') $false
          if ($delete) {
            Remove-ADUser @adp -Identity $identity -Confirm:$false -WhatIf:$simulate
          }
          else {
            Disable-ADAccount @adp -Identity $identity -WhatIf:$simulate
            $targetOu = Get-CsvValue $row 'TargetOU'
            if (-not [string]::IsNullOrWhiteSpace($targetOu)) {
              if ($targetOu -match '^(?i)(OU|CN)=Domain Controllers,') { throw "No se permite mover a 'Domain Controllers'." }
              $obj = Get-ADUser @adp -Identity $identity -Properties DistinguishedName
              Move-ADObject @adp -Identity $obj.DistinguishedName -TargetPath $targetOu -WhatIf:$simulate
            }
          }
        }
        'mover' {
          if ([string]::IsNullOrWhiteSpace($identity)) { throw "Mover requiere Identity o SamAccountName." }
          $targetOu = Get-CsvValue $row 'TargetOU'
          if ([string]::IsNullOrWhiteSpace($targetOu)) { throw "Mover requiere TargetOU." }
          if ($targetOu -match '^(?i)(OU|CN)=Domain Controllers,') { throw "No se permite mover a 'Domain Controllers'." }

          $dn = $identity
          if ($identity -notmatch '^(?i)(CN|OU)=') {
            $obj = Get-ADUser @adp -Identity $identity -Properties DistinguishedName
            $dn = $obj.DistinguishedName
          }
          Move-ADObject @adp -Identity $dn -TargetPath $targetOu -WhatIf:$simulate
        }
        default {
          throw "Acción no soportada: '$actionRaw'. Usá Alta, Modificar, Baja o Mover."
        }
      }

      $msg = if ($simulate) { "Simulado correctamente." } else { "Ejecutado correctamente." }
      $results += New-BatchResult -rowNumber $rowNumber -action $actionRaw -identity $identity -status 'OK' -message $msg
      $auditResult = if ($simulate) { 'SIMULATED' } else { 'OK' }
      Write-AuditLog -Action ("Lote CSV: $actionRaw") -Result $auditResult -Object ([string]$identity) -Detail ("Fila: " + $rowNumber)
    }
    catch {
      $results += New-BatchResult -rowNumber $rowNumber -action $actionRaw -identity $identity -status 'ERROR' -message $_.Exception.Message
      Write-AuditLog -Action ("Lote CSV: $actionRaw") -Result 'ERROR' -Object ([string]$identity) -Detail ("Fila: " + $rowNumber + " | " + $_.Exception.Message)
    }
  }

  return @($results)
}

function Save-BatchReport([object[]]$results) {
  if ($null -eq $results -or $results.Count -eq 0) { return $null }
  $dir = Join-Path $PSScriptRoot 'BatchReports'
  if (-not (Test-Path -Path $dir -PathType Container)) {
    New-Item -Path $dir -ItemType Directory -Force | Out-Null
  }
  $file = Join-Path $dir ("ADBatch_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
  $results | Export-Csv -Path $file -NoTypeInformation -Encoding UTF8
  return $file
}

function New-BatchTemplateRows {
  return @(
    [PSCustomObject]@{
      Action                = 'Alta'
      Identity              = ''
      SamAccountName        = 'jperez'
      DistinguishedName     = ''
      FirstName             = 'Juan'
      Initials              = 'P'
      LastName              = 'Perez'
      FullName              = 'Juan Perez'
      DisplayName           = 'Perez, Juan'
      UpnUser               = 'jperez'
      OU                    = 'OU=Usuarios,DC=empresa,DC=local'
      TargetOU              = ''
      Password              = 'Temporal#2026'
      NewPassword           = ''
      Email                 = 'juan.perez@empresa.local'
      Title                 = 'Analista'
      Department            = 'IT'
      Company               = 'Empresa'
      Office                = 'CABA - Piso 3'
      OfficePhone           = '+54 11 5555 0001'
      Description           = 'Alta por lote'
      Enabled               = 'true'
      MustChangePassword    = 'true'
      CannotChangePassword  = 'false'
      PasswordNeverExpires  = 'false'
      Delete                = 'false'
    }
    [PSCustomObject]@{
      Action                = 'Modificar'
      Identity              = 'jperez'
      SamAccountName        = ''
      DistinguishedName     = ''
      FirstName             = ''
      Initials              = ''
      LastName              = ''
      FullName              = ''
      DisplayName           = ''
      UpnUser               = ''
      OU                    = ''
      TargetOU              = ''
      Password              = ''
      NewPassword           = ''
      Email                 = 'juan.perez2@empresa.local'
      Title                 = 'Senior Analyst'
      Department            = 'IT'
      Company               = ''
      Office                = ''
      OfficePhone           = ''
      Description           = 'Actualizacion por lote'
      Enabled               = 'true'
      MustChangePassword    = ''
      CannotChangePassword  = ''
      PasswordNeverExpires  = ''
      Delete                = ''
    }
    [PSCustomObject]@{
      Action                = 'Baja'
      Identity              = 'jperez'
      SamAccountName        = ''
      DistinguishedName     = ''
      FirstName             = ''
      Initials              = ''
      LastName              = ''
      FullName              = ''
      DisplayName           = ''
      UpnUser               = ''
      OU                    = ''
      TargetOU              = 'OU=Bajas,DC=empresa,DC=local'
      Password              = ''
      NewPassword           = ''
      Email                 = ''
      Title                 = ''
      Department            = ''
      Company               = ''
      Office                = ''
      OfficePhone           = ''
      Description           = 'Baja por lote'
      Enabled               = ''
      MustChangePassword    = ''
      CannotChangePassword  = ''
      PasswordNeverExpires  = ''
      Delete                = 'false'
    }
    [PSCustomObject]@{
      Action                = 'Mover'
      Identity              = 'CN=Juan Perez,OU=Usuarios,DC=empresa,DC=local'
      SamAccountName        = ''
      DistinguishedName     = ''
      FirstName             = ''
      Initials              = ''
      LastName              = ''
      FullName              = ''
      DisplayName           = ''
      UpnUser               = ''
      OU                    = ''
      TargetOU              = 'OU=Soporte,DC=empresa,DC=local'
      Password              = ''
      NewPassword           = ''
      Email                 = ''
      Title                 = ''
      Department            = ''
      Company               = ''
      Office                = ''
      OfficePhone           = ''
      Description           = 'Movimiento por lote'
      Enabled               = ''
      MustChangePassword    = ''
      CannotChangePassword  = ''
      PasswordNeverExpires  = ''
      Delete                = ''
    }
  )
}

function Save-BatchTemplate([string]$path) {
  $templateRows = New-BatchTemplateRows
  $templateRows | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
  return $path
}

function Get-BatchTemplateHeaders {
  return @(
    'Action', 'Identity', 'SamAccountName', 'DistinguishedName',
    'FirstName', 'Initials', 'LastName', 'FullName', 'DisplayName', 'UpnUser',
    'OU', 'TargetOU',
    'Password', 'NewPassword',
    'Email', 'Title', 'Department', 'Company', 'Office', 'OfficePhone', 'Description',
    'Enabled', 'MustChangePassword', 'CannotChangePassword', 'PasswordNeverExpires',
    'Delete'
  )
}

function Save-BatchTemplateEmpty([string]$path) {
  $headerLine = (Get-BatchTemplateHeaders) -join ','
  Set-Content -Path $path -Value $headerLine -Encoding UTF8
  return $path
}

$btnBatchBrowseCsv.Add_Click({
    try {
      $ofd = New-Object Microsoft.Win32.OpenFileDialog
      $ofd.Filter = "CSV (*.csv)|*.csv|Todos (*.*)|*.*"
      $ofd.Multiselect = $false
      if ($ofd.ShowDialog() -eq $true) {
        $txtBatchCsvPath.Text = $ofd.FileName
      }
    }
    catch { Show-Exception "Error seleccionando CSV:" $_ }
  })

$btnBatchTemplate.Add_Click({
    try {
      $sfd = New-Object Microsoft.Win32.SaveFileDialog
      $sfd.Filter = "CSV (*.csv)|*.csv|Todos (*.*)|*.*"
      $sfd.FileName = "Plantilla_AD_Lote.csv"
      if ($sfd.ShowDialog() -ne $true) { return }

      $out = Save-BatchTemplate -path $sfd.FileName
      $txtBatchCsvPath.Text = $out
      [System.Windows.MessageBox]::Show("Plantilla generada en:`n$out", "Plantilla CSV", "OK", "Information") | Out-Null
      Set-Status "✅ Plantilla CSV generada: $out" '#a6e3a1'
      Write-AuditLog -Action 'Generar Plantilla CSV' -Result 'OK' -Object $out
    }
    catch { Show-Exception "Error generando plantilla CSV:" $_ }
  })

$btnBatchTemplateEmpty.Add_Click({
    try {
      $sfd = New-Object Microsoft.Win32.SaveFileDialog
      $sfd.Filter = "CSV (*.csv)|*.csv|Todos (*.*)|*.*"
      $sfd.FileName = "Plantilla_AD_Lote_Vacia.csv"
      if ($sfd.ShowDialog() -ne $true) { return }

      $out = Save-BatchTemplateEmpty -path $sfd.FileName
      $txtBatchCsvPath.Text = $out
      [System.Windows.MessageBox]::Show("Plantilla vacía generada en:`n$out", "Plantilla CSV", "OK", "Information") | Out-Null
      Set-Status "✅ Plantilla vacía generada: $out" '#a6e3a1'
      Write-AuditLog -Action 'Generar Plantilla CSV Vacia' -Result 'OK' -Object $out
    }
    catch { Show-Exception "Error generando plantilla vacía:" $_ }
  })

$btnBatchPreview.Add_Click({
    $path = Get-RequiredTrimmedText $txtBatchCsvPath.Text "Seleccioná un CSV para preview."
    if ($null -eq $path) { return }

    $results = Invoke-BatchCsvProcess -csvPath $path -Preview
    $script:batchLastResults = @($results)
    $dgBatchResults.ItemsSource = @($results)

    $ok = @($results | Where-Object { $_.Status -eq 'OK' }).Count
    $err = @($results | Where-Object { $_.Status -eq 'ERROR' }).Count
    Set-Status "🧪 Preview CSV finalizado. OK: $ok | ERROR: $err" '#fab387'
    Write-AuditLog -Action 'Preview Lote CSV' -Result 'SIMULATED' -Object $path -Detail ("OK: $ok | ERROR: $err")
  })

$btnBatchExecute.Add_Click({
    if (-not (Assert-ADModule)) { return }
    $path = Get-RequiredTrimmedText $txtBatchCsvPath.Text "Seleccioná un CSV para ejecutar."
    if ($null -eq $path) { return }

    if (-not $script:SimulationMode) {
      if (-not (Show-Confirm "⚠️ Se ejecutarán cambios reales en AD. ¿Continuar?")) { return }
    }

    $results = Invoke-BatchCsvProcess -csvPath $path
    $script:batchLastResults = @($results)
    $dgBatchResults.ItemsSource = @($results)

    $ok = @($results | Where-Object { $_.Status -eq 'OK' }).Count
    $err = @($results | Where-Object { $_.Status -eq 'ERROR' }).Count
    if ($script:SimulationMode) {
      Set-Status "🧪 Ejecución en simulación finalizada. OK: $ok | ERROR: $err" '#fab387'
      Write-AuditLog -Action 'Ejecutar Lote CSV' -Result 'SIMULATED' -Object $path -Detail ("OK: $ok | ERROR: $err")
    }
    else {
      Set-Status "✅ Ejecución CSV finalizada. OK: $ok | ERROR: $err" '#a6e3a1'
      Write-AuditLog -Action 'Ejecutar Lote CSV' -Result 'OK' -Object $path -Detail ("OK: $ok | ERROR: $err")
    }
  })

$btnBatchExportReport.Add_Click({
    if ($null -eq $script:batchLastResults -or $script:batchLastResults.Count -eq 0) {
      Show-Error "No hay resultados para exportar."
      return
    }
    try {
      $out = Save-BatchReport -results $script:batchLastResults
      $script:batchLastReportPath = $out
      [System.Windows.MessageBox]::Show("Reporte exportado en:`n$out", "Reporte CSV", "OK", "Information") | Out-Null
      Set-Status "✅ Reporte exportado: $out" '#a6e3a1'
      Write-AuditLog -Action 'Exportar Reporte Lote CSV' -Result 'OK' -Object $out
    }
    catch { Show-Exception "Error exportando reporte:" $_ }
  })
