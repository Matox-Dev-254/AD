[CmdletBinding()]
param(
  [string]$InstallDir,
  [switch]$NoDesktopShortcut,
  [switch]$Silent
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Test-IsAdministrator {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Ensure-Directory([string]$Path) {
  if (-not (Test-Path -Path $Path -PathType Container)) {
    New-Item -Path $Path -ItemType Directory -Force | Out-Null
  }
}

function Ensure-RegistryKey([string]$Path) {
  if (-not (Test-Path -Path $Path)) {
    New-Item -Path $Path -Force | Out-Null
  }
}

function Remove-PathIfExists([string]$Path) {
  if (Test-Path -Path $Path) {
    Remove-Item -Path $Path -Recurse -Force
  }
}

function Copy-DirectoryContent([string]$SourceDir, [string]$TargetDir) {
  Ensure-Directory -Path $TargetDir
  Copy-Item -Path (Join-Path $SourceDir '*') -Destination $TargetDir -Recurse -Force
}

function Copy-ModulesContent([string]$SourceDir, [string]$TargetDir) {
  Ensure-Directory -Path $TargetDir

  $files = Get-ChildItem -Path $SourceDir -Recurse -File -Force | Where-Object {
    $_.FullName -notmatch '\\AuditLogs(\\|$)'
  }

  foreach ($file in $files) {
    $relativePath = $file.FullName.Substring($SourceDir.Length).TrimStart('\')
    $targetPath = Join-Path $TargetDir $relativePath
    $targetParent = Split-Path -Path $targetPath -Parent
    Ensure-Directory -Path $targetParent
    Copy-Item -Path $file.FullName -Destination $targetPath -Force
  }
}

function New-ShortcutFile([string]$ShortcutPath, [string]$TargetPath, [string]$Arguments, [string]$WorkingDirectory, [string]$Description) {
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($ShortcutPath)
  $shortcut.TargetPath = $TargetPath
  $shortcut.Arguments = $Arguments
  $shortcut.WorkingDirectory = $WorkingDirectory
  $shortcut.Description = $Description
  $shortcut.IconLocation = "$TargetPath,0"
  $shortcut.Save()
}

function Get-DesktopShortcutPaths([string]$ShortcutName) {
  $paths = @()
  $commonDesktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
  $userDesktop = [Environment]::GetFolderPath('Desktop')

  if (-not [string]::IsNullOrWhiteSpace($commonDesktop)) {
    $paths += (Join-Path $commonDesktop $ShortcutName)
  }
  if (-not [string]::IsNullOrWhiteSpace($userDesktop)) {
    $paths += (Join-Path $userDesktop $ShortcutName)
  }

  return @($paths | Select-Object -Unique)
}

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$packageRoot = Split-Path -Parent $scriptRoot
$config = Import-PowerShellDataFile -Path (Join-Path $scriptRoot 'Product.Config.psd1')

if (-not (Test-IsAdministrator)) {
  throw 'La instalación requiere ejecutar PowerShell como administrador.'
}

if ([string]::IsNullOrWhiteSpace($InstallDir)) {
  $InstallDir = Join-Path ${env:ProgramFiles} $config.InstallDirName
}

$programDataDir = Join-Path ${env:ProgramData} $config.ProgramDataDirName
$startMenuDir = Join-Path ([Environment]::GetFolderPath('CommonPrograms')) $config.StartMenuFolder
$powershellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$mainScriptPath = Join-Path $InstallDir $config.MainScript
$uninstallScriptPath = Join-Path $InstallDir 'installer\uninstall.ps1'
$launchArguments = "-ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden -File `"$mainScriptPath`""
$uninstallArguments = "-ExecutionPolicy Bypass -NoProfile -File `"$uninstallScriptPath`""
$uninstallKeyPath = "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$($config.UninstallKey)"

Ensure-Directory -Path $programDataDir
Ensure-Directory -Path (Join-Path $programDataDir 'Logs')

Remove-PathIfExists -Path $InstallDir
Ensure-Directory -Path $InstallDir

Copy-Item -Path (Join-Path $packageRoot $config.MainScript) -Destination $InstallDir -Force
Copy-ModulesContent -SourceDir (Join-Path $packageRoot 'modules') -TargetDir (Join-Path $InstallDir 'modules')
Ensure-Directory -Path (Join-Path $InstallDir 'installer')
Copy-Item -Path (Join-Path $scriptRoot 'uninstall.ps1') -Destination (Join-Path $InstallDir 'installer') -Force
Copy-Item -Path (Join-Path $scriptRoot 'Product.Config.psd1') -Destination (Join-Path $InstallDir 'installer') -Force

$startMenuShortcut = Join-Path $startMenuDir $config.ShortcutName
Ensure-Directory -Path $startMenuDir
New-ShortcutFile -ShortcutPath $startMenuShortcut -TargetPath $powershellExe -Arguments $launchArguments -WorkingDirectory $InstallDir -Description $config.ProductName

if (-not $NoDesktopShortcut) {
  foreach ($desktopShortcut in (Get-DesktopShortcutPaths -ShortcutName $config.ShortcutName)) {
    $desktopParent = Split-Path -Path $desktopShortcut -Parent
    Ensure-Directory -Path $desktopParent
    New-ShortcutFile -ShortcutPath $desktopShortcut -TargetPath $powershellExe -Arguments $launchArguments -WorkingDirectory $InstallDir -Description $config.ProductName
  }
}

Ensure-RegistryKey -Path $uninstallKeyPath
Set-ItemProperty -Path $uninstallKeyPath -Name 'DisplayName' -Value $config.ProductName
Set-ItemProperty -Path $uninstallKeyPath -Name 'Publisher' -Value $config.Publisher
Set-ItemProperty -Path $uninstallKeyPath -Name 'DisplayVersion' -Value $config.Version
Set-ItemProperty -Path $uninstallKeyPath -Name 'InstallLocation' -Value $InstallDir
Set-ItemProperty -Path $uninstallKeyPath -Name 'DisplayIcon' -Value $powershellExe
Set-ItemProperty -Path $uninstallKeyPath -Name 'UninstallString' -Value "`"$powershellExe`" $uninstallArguments"
Set-ItemProperty -Path $uninstallKeyPath -Name 'QuietUninstallString' -Value "`"$powershellExe`" $uninstallArguments -Silent"
Set-ItemProperty -Path $uninstallKeyPath -Name 'NoModify' -Value 1 -Type DWord
Set-ItemProperty -Path $uninstallKeyPath -Name 'NoRepair' -Value 1 -Type DWord

if (-not $Silent) {
  Write-Host ''
  Write-Host 'Instalacion completada.' -ForegroundColor Green
  Write-Host "Aplicacion: $InstallDir"
  Write-Host "Datos compartidos: $programDataDir"
  Write-Host "Acceso Inicio: $startMenuShortcut"
  if (-not $NoDesktopShortcut) {
    Write-Host 'Acceso Escritorio: creado'
  }
}
