[CmdletBinding()]
param(
  [switch]$Purge,
  [switch]$Silent
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Test-IsAdministrator {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Remove-PathIfExists([string]$Path) {
  if (Test-Path -Path $Path) {
    Remove-Item -Path $Path -Recurse -Force
  }
}

function Remove-ShortcutIfExists([string]$Path) {
  if (Test-Path -Path $Path -PathType Leaf) {
    Remove-Item -Path $Path -Force
  }
}

function Get-DesktopShortcutPaths([string]$ShortcutName) {
  $paths = @()
  $commonDesktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
  $userDesktop = [Environment]::GetFolderPath('Desktop')

  if (-not [string]::IsNullOrWhiteSpace($commonDesktop)) {
    $paths += (Join-Path $commonDesktop $ShortcutName)
  }
  if (-not [string]::IsNullOrWhiteSpace($userDesktop)) {
    $paths += (Join-Path $userDesktop $ShortcutName)
  }

  return @($paths | Select-Object -Unique)
}

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$config = Import-PowerShellDataFile -Path (Join-Path $scriptRoot 'Product.Config.psd1')

if (-not (Test-IsAdministrator)) {
  throw 'La desinstalacion requiere ejecutar PowerShell como administrador.'
}

$installDir = Split-Path -Parent $scriptRoot
$programDataDir = Join-Path ${env:ProgramData} $config.ProgramDataDirName
$localAppDataDir = Join-Path ${env:LOCALAPPDATA} $config.ProgramDataDirName
$startMenuDir = Join-Path ([Environment]::GetFolderPath('CommonPrograms')) $config.StartMenuFolder
$startMenuShortcut = Join-Path $startMenuDir $config.ShortcutName
$uninstallKeyPath = "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$($config.UninstallKey)"

if ((-not $Silent) -and $Purge) {
  $caption = 'Desinstalacion completa'
  $message = 'Se eliminaran binarios, accesos directos, configuracion y logs. ¿Deseas continuar?'
  $choices = [System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription]]::new()
  $choices.Add((New-Object System.Management.Automation.Host.ChoiceDescription '&Si', 'Confirma la limpieza completa.'))
  $choices.Add((New-Object System.Management.Automation.Host.ChoiceDescription '&No', 'Cancela la desinstalacion.'))
  $choice = $Host.UI.PromptForChoice($caption, $message, $choices, 1)
  if ($choice -ne 0) { return }
}

Remove-ShortcutIfExists -Path $startMenuShortcut
foreach ($desktopShortcut in (Get-DesktopShortcutPaths -ShortcutName $config.ShortcutName)) {
  Remove-ShortcutIfExists -Path $desktopShortcut
}
Remove-PathIfExists -Path $installDir
if (Test-Path -Path $startMenuDir -PathType Container) {
  $remaining = Get-ChildItem -Path $startMenuDir -Force -ErrorAction SilentlyContinue
  if ($null -eq $remaining -or $remaining.Count -eq 0) {
    Remove-Item -Path $startMenuDir -Force
  }
}

if (Test-Path -Path $uninstallKeyPath) {
  Remove-Item -Path $uninstallKeyPath -Recurse -Force
}

if ($Purge) {
  Remove-PathIfExists -Path $programDataDir
  Remove-PathIfExists -Path $localAppDataDir
}

if (-not $Silent) {
  Write-Host ''
  if ($Purge) {
    Write-Host 'Desinstalacion completa realizada.' -ForegroundColor Green
  }
  else {
    Write-Host 'Desinstalacion realizada. Se conservaron configuracion y logs.' -ForegroundColor Green
  }
}
