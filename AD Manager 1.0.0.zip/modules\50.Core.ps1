﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 50.Core.ps1

# ── AUX ──────────────────────────────────────────────────────────────────────
function Set-Status([string]$msg, [string]$color = '#a6adc8') {
  $txtStatus.Text = $msg
  $script:StatusColor = $color
  $txtStatus.Foreground = ConvertTo-Brush $color
}

$script:AuditLogDir = Get-AdManagerProgramDataPath 'Logs'
$script:AuditLogFilePrefix = 'AD_Audit_'
$script:AuditLocalRetentionMonths = 2
$script:AuditSettings = @{
  EnableCentral      = $false
  CentralMode        = 'FileShare' # FileShare | SqlServer
  CentralFilePath    = '\\SERVIDOR\AD-Audit\AD_Audit_Central.csv'
  SqlConnectionString = '' # Ej: Server=SQL01;Database=AdminAD;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;
  SqlTable           = 'dbo.ADAuditLog'
}
$script:AuditConfigLocalPath = Get-AdManagerProgramDataPath 'audit.settings.json'
$script:AuditConfigLegacyPath = Join-Path $PSScriptRoot 'audit.settings.json'
$script:AuditConfigSharedPath = [string]$env:AD_MANAGER_AUDIT_CONFIG_PATH
$script:AuditConfigPath = $script:AuditConfigLocalPath
$script:AuditLastCentralError = ''
$script:AuditLastCentralOk = ''
$script:AuditUiSyncInProgress = $false
$script:UserPolicyConfigEnvPath = [string]$env:AD_MANAGER_USER_POLICY_PATH
$script:UserPolicyConfigLocalPath = Get-AdManagerProgramDataPath 'user.form.policy.json'
$script:UserPolicyConfigLegacyModulePath = Join-Path $PSScriptRoot 'user.form.policy.json'
$script:UserPolicyConfigProgramDataPath = if (-not [string]::IsNullOrWhiteSpace([string]$env:ProgramData)) { Join-Path $env:ProgramData 'ADManager\user.form.policy.json' } else { '' }
$script:UserPolicyConfigAppDataPath = if (-not [string]::IsNullOrWhiteSpace([string]$env:LOCALAPPDATA)) { Join-Path $env:LOCALAPPDATA 'ADManager\user.form.policy.json' } else { '' }
$script:UserPolicyLegacyPaths = @(
  $script:UserPolicyConfigLegacyModulePath,
  (Join-Path ([Environment]::GetFolderPath('Desktop')) 'user.form.policy.json'),
  (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'user.form.policy.json')
)
$script:UserPolicyConfigPath = $script:UserPolicyConfigLocalPath
$script:UserPolicy = $null
$script:UserPolicyUnlocked = $false

function ConvertTo-BoolValue([object]$value, [bool]$defaultValue = $false) {
  if ($null -eq $value) { return $defaultValue }
  if ($value -is [bool]) { return [bool]$value }
  $text = ([string]$value).Trim().ToLowerInvariant()
  switch -Regex ($text) {
    '^(1|true|t|si|sí|yes|y|on)$' { return $true }
    '^(0|false|f|no|n|off)$' { return $false }
    default { return $defaultValue }
  }
}

function Set-AuditSettingsFromGui {
  if (-not $chkAuditEnableCentral) { return }

  $mode = [string]$cbAuditMode.SelectedItem
  if ([string]::IsNullOrWhiteSpace($mode)) { $mode = 'FileShare' }
  if (($mode -ne 'FileShare') -and ($mode -ne 'SqlServer')) { $mode = 'FileShare' }

  $script:AuditSettings.EnableCentral = (Get-Checked $chkAuditEnableCentral)
  $script:AuditSettings.CentralMode = $mode
  $rawCentralPath = [string]$txtAuditCentralFilePath.Text.Trim()
  if ($mode -eq 'FileShare') {
    $resolvedCentralPath = Resolve-AuditCentralFilePath -inputPath $rawCentralPath -CreateIfMissing
    $script:AuditSettings.CentralFilePath = $resolvedCentralPath
    if ($txtAuditCentralFilePath) { $txtAuditCentralFilePath.Text = $resolvedCentralPath }
  }
  else {
    $script:AuditSettings.CentralFilePath = $rawCentralPath
  }
  $script:AuditSettings.SqlConnectionString = [string]$txtAuditSqlConnection.Text.Trim()
  $script:AuditSettings.SqlTable = [string]$txtAuditSqlTable.Text.Trim()
}

function Resolve-AuditCentralFilePath([string]$inputPath, [switch]$CreateIfMissing) {
  $path = [string]$inputPath
  if ([string]::IsNullOrWhiteSpace($path)) { return '' }
  $path = $path.Trim()

  # Si no termina en .csv, se interpreta como carpeta.
  if ($path -notmatch '\.csv$') {
    $folder = $path
    $selectedCsv = $null

    if (Test-Path -Path $folder -PathType Container) {
      $preferred = Join-Path $folder 'AD_Audit_Central.csv'
      if (Test-Path -Path $preferred -PathType Leaf) {
        $selectedCsv = $preferred
      }
      else {
        $anyCsv = Get-ChildItem -Path $folder -Filter '*.csv' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
        if ($anyCsv) { $selectedCsv = $anyCsv.FullName }
      }
    }

    if ($null -eq $selectedCsv) {
      $selectedCsv = Join-Path $folder 'AD_Audit_Central.csv'
    }
    $path = $selectedCsv
  }

  if ($CreateIfMissing) {
    Ensure-CentralFileLog -path $path
  }

  return $path
}

function Update-AuditGuiFromSettings {
  if (-not $chkAuditEnableCentral) { return }

  $script:AuditUiSyncInProgress = $true
  try {
    $chkAuditEnableCentral.IsChecked = ConvertTo-BoolValue $script:AuditSettings.EnableCentral $false

    if ($cbAuditMode.Items.Count -eq 0) {
      $cbAuditMode.Items.Add('FileShare') | Out-Null
      $cbAuditMode.Items.Add('SqlServer') | Out-Null
    }

    $mode = [string]$script:AuditSettings.CentralMode
    if (($mode -ne 'FileShare') -and ($mode -ne 'SqlServer')) { $mode = 'FileShare' }
    $cbAuditMode.SelectedItem = $mode

    if (($mode -eq 'FileShare') -and [string]::IsNullOrWhiteSpace([string]$script:AuditSettings.CentralFilePath)) {
      $script:AuditSettings.CentralFilePath = '\\SERVIDOR\AD-Audit\AD_Audit_Central.csv'
    }

    $txtAuditCentralFilePath.Text = [string]$script:AuditSettings.CentralFilePath
    $txtAuditSqlConnection.Text = [string]$script:AuditSettings.SqlConnectionString
    $txtAuditSqlTable.Text = [string]$script:AuditSettings.SqlTable
  }
  finally {
    $script:AuditUiSyncInProgress = $false
  }
}

function Get-AuditConfigReadPaths {
  $paths = @()
  if (-not [string]::IsNullOrWhiteSpace($script:AuditConfigSharedPath)) {
    $paths += $script:AuditConfigSharedPath

    # Compatibilidad: admitir typo histórico "settines" en la ruta compartida.
    if ($script:AuditConfigSharedPath -match 'settines') {
      $paths += ($script:AuditConfigSharedPath -replace 'settines', 'settings')
    }
  }
  if (-not [string]::IsNullOrWhiteSpace($script:AuditConfigLocalPath)) { $paths += $script:AuditConfigLocalPath }
  if ((-not [string]::IsNullOrWhiteSpace($script:AuditConfigLegacyPath)) -and ($script:AuditConfigLegacyPath -ne $script:AuditConfigLocalPath)) { $paths += $script:AuditConfigLegacyPath }
  return @($paths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
}

function Get-AuditConfigWritePath {
  if (-not [string]::IsNullOrWhiteSpace($script:AuditConfigSharedPath)) { return $script:AuditConfigSharedPath }
  return $script:AuditConfigLocalPath
}

function Get-AuditConfigCandidatesText {
  $paths = Get-AuditConfigReadPaths
  if ($null -eq $paths -or $paths.Count -eq 0) { return '(sin rutas configuradas)' }
  return ($paths -join ' | ')
}

function Write-AuditSettingsFile([string]$path, [string]$json) {
  if ([string]::IsNullOrWhiteSpace($path)) { throw "Ruta de configuración inválida." }
  $parent = Split-Path -Path $path -Parent
  if ((-not [string]::IsNullOrWhiteSpace($parent)) -and (-not (Test-Path -Path $parent -PathType Container))) {
    New-Item -Path $parent -ItemType Directory -Force | Out-Null
  }
  Set-Content -Path $path -Value $json -Encoding UTF8
}

function Save-AuditSettingsToFile {
  $out = [PSCustomObject]@{
    EnableCentral       = [bool]$script:AuditSettings.EnableCentral
    CentralMode         = [string]$script:AuditSettings.CentralMode
    CentralFilePath     = [string]$script:AuditSettings.CentralFilePath
    SqlConnectionString = [string]$script:AuditSettings.SqlConnectionString
    SqlTable            = [string]$script:AuditSettings.SqlTable
  }
  $json = $out | ConvertTo-Json -Depth 4
  $targetPath = Get-AuditConfigWritePath
  try {
    Write-AuditSettingsFile -path $targetPath -json $json
    $script:AuditConfigPath = $targetPath
  }
  catch {
    if ($targetPath -ne $script:AuditConfigLocalPath) {
      Write-AuditSettingsFile -path $script:AuditConfigLocalPath -json $json
      $script:AuditConfigPath = $script:AuditConfigLocalPath
      return
    }
    throw
  }
}

function Load-AuditSettingsFromFile {
  $existingPaths = @()
  foreach ($candidate in (Get-AuditConfigReadPaths)) {
    if (Test-Path -Path $candidate -PathType Leaf) { $existingPaths += $candidate }
  }
  if ($existingPaths.Count -eq 0) { return $false }

  $lastErrorMessage = ''
  foreach ($path in $existingPaths) {
    try {
      $raw = Get-Content -Path $path -Raw -ErrorAction Stop
      if ([string]::IsNullOrWhiteSpace($raw)) { continue }
      $cfg = $raw | ConvertFrom-Json -ErrorAction Stop
      if (-not $cfg) { continue }

      $script:AuditSettings.EnableCentral = ConvertTo-BoolValue $cfg.EnableCentral $false
      $script:AuditSettings.CentralMode = [string]$cfg.CentralMode
      if (($script:AuditSettings.CentralMode -ne 'FileShare') -and ($script:AuditSettings.CentralMode -ne 'SqlServer')) {
        $script:AuditSettings.CentralMode = 'FileShare'
      }

      # Compatibilidad: aceptar nombres de clave legacy y no pisar con vacío.
      $loadedCentralPath = ''
      if ($cfg.PSObject.Properties['CentralFilePath']) { $loadedCentralPath = [string]$cfg.CentralFilePath }
      if ([string]::IsNullOrWhiteSpace($loadedCentralPath) -and $cfg.PSObject.Properties['AuditCentralFilePath']) { $loadedCentralPath = [string]$cfg.AuditCentralFilePath }
      if ([string]::IsNullOrWhiteSpace($loadedCentralPath) -and $cfg.PSObject.Properties['FileSharePath']) { $loadedCentralPath = [string]$cfg.FileSharePath }
      if ([string]::IsNullOrWhiteSpace($loadedCentralPath) -and $cfg.PSObject.Properties['CentralPath']) { $loadedCentralPath = [string]$cfg.CentralPath }
      if (-not [string]::IsNullOrWhiteSpace($loadedCentralPath)) {
        $script:AuditSettings.CentralFilePath = Resolve-AuditCentralFilePath -inputPath $loadedCentralPath
      }

      $script:AuditSettings.SqlConnectionString = [string]$cfg.SqlConnectionString
      $script:AuditSettings.SqlTable = [string]$cfg.SqlTable
      if ([string]::IsNullOrWhiteSpace($script:AuditSettings.SqlTable)) {
        $script:AuditSettings.SqlTable = 'dbo.ADAuditLog'
      }

      $script:AuditConfigPath = $path
      return $true
    }
    catch {
      $lastErrorMessage = $_.Exception.Message
    }
  }

  if (-not [string]::IsNullOrWhiteSpace($lastErrorMessage)) {
    throw "No se pudo cargar la configuración de auditoría desde ninguna ruta disponible. Último error: $lastErrorMessage"
  }
  return $false
}

function Show-AuditDiagnostics([string[]]$lines) {
  if (-not $txtAuditDiagnostics) { return }
  if ($null -eq $lines -or $lines.Count -eq 0) {
    $txtAuditDiagnostics.Text = ''
    return
  }
  $txtAuditDiagnostics.Text = ($lines -join [Environment]::NewLine)
  $txtAuditDiagnostics.ScrollToHome()
}

if ($btnAuditDiagScrollDown) {
  $btnAuditDiagScrollDown.Add_Click({
      if ($txtAuditDiagnostics) { $txtAuditDiagnostics.ScrollToEnd() }
    })
}

if ($btnAuditBrowseCentralFile) {
  $btnAuditBrowseCentralFile.Add_Click({
      try {
        $sfd = New-Object Microsoft.Win32.SaveFileDialog
        $sfd.Filter = "CSV (*.csv)|*.csv|Todos (*.*)|*.*"
        $sfd.AddExtension = $true
        $sfd.DefaultExt = "csv"
        $sfd.FileName = "AD_Audit_Central.csv"

        $current = [string]$txtAuditCentralFilePath.Text.Trim()
        if (-not [string]::IsNullOrWhiteSpace($current)) {
          try {
            $currentName = Split-Path -Path $current -Leaf
            $currentDir = Split-Path -Path $current -Parent
            if (-not [string]::IsNullOrWhiteSpace($currentName)) { $sfd.FileName = $currentName }
            if ((-not [string]::IsNullOrWhiteSpace($currentDir)) -and (Test-Path -Path $currentDir -PathType Container)) {
              $sfd.InitialDirectory = $currentDir
            }
          }
          catch {}
        }

        if ($sfd.ShowDialog() -eq $true) {
          $txtAuditCentralFilePath.Text = (Resolve-AuditCentralFilePath -inputPath $sfd.FileName)
          Set-Status "✅ Ruta central seleccionada." '#a6e3a1'
        }
      }
      catch { Show-Exception "Error seleccionando ruta central de auditoría:" $_ }
    })
}

function Get-AuditValidationResult([switch]$DeepTest) {
  $lines = @()
  $errors = @()
  $warnings = @()

  $enabled = ConvertTo-BoolValue $script:AuditSettings.EnableCentral $false
  $mode = [string]$script:AuditSettings.CentralMode
  if ([string]::IsNullOrWhiteSpace($mode)) { $mode = 'FileShare' }
  if (($mode -ne 'FileShare') -and ($mode -ne 'SqlServer')) {
    $errors += "Modo inválido: '$mode'. Debe ser FileShare o SqlServer."
  }

  $lines += "Estado general:"
  $lines += " - Auditoria central habilitada: $enabled"
  $lines += " - Modo: $mode"
  $lines += " - Config audit cargada desde: $($script:AuditConfigPath)"
  $lines += " - Rutas de config candidatas: $(Get-AuditConfigCandidatesText)"

  if (-not $enabled) {
    $warnings += "La auditoría central está deshabilitada. Solo se guardará log local."
  }
  elseif ($mode -eq 'FileShare') {
    $path = [string]$script:AuditSettings.CentralFilePath
    $lines += " - Destino FileShare: $path"
    if ([string]::IsNullOrWhiteSpace($path)) {
      $errors += "Ruta central vacía."
    }
    else {
      if ($path -notmatch '^\\\\') {
        $warnings += "La ruta no parece UNC (\\\\servidor\\recurso\\archivo.csv)."
      }
      if ($path -notmatch '\.csv$') {
        $warnings += "La ruta no termina en .csv."
      }

      $parent = Split-Path -Path $path -Parent
      if ([string]::IsNullOrWhiteSpace($parent)) {
        $errors += "No se pudo determinar carpeta padre de la ruta central."
      }
      else {
        try {
          if (Test-Path -Path $parent -PathType Container) {
            $lines += " - Carpeta detectada: OK ($parent)"
          }
          else {
            $warnings += "La carpeta no existe o no es accesible: $parent"
          }
        }
        catch {
          $warnings += "No se pudo validar acceso a carpeta: $($_.Exception.Message)"
        }
      }

      if ($DeepTest -and ($errors.Count -eq 0)) {
        try {
          Ensure-CentralFileLog -path $path
          $probe = [PSCustomObject]@{
            FechaHora = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
            Operador  = 'Diag'
            Dominio   = 'Diag'
            Accion    = 'DiagWrite'
            Resultado = 'TEST'
            Objeto    = 'FileShare'
            Detalle   = 'Diagnostico'
            Equipo    = $env:COMPUTERNAME
          }
          $line = $probe | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1
          Add-Content -Path $path -Value $line -Encoding UTF8
          $lines += " - Escritura de prueba: OK"
        }
        catch {
          $errors += "Error de escritura en FileShare: $($_.Exception.Message)"
        }
      }
    }
  }
  elseif ($mode -eq 'SqlServer') {
    $connStr = [string]$script:AuditSettings.SqlConnectionString
    $table = [string]$script:AuditSettings.SqlTable
    $lines += " - Tabla SQL: $table"

    if ([string]::IsNullOrWhiteSpace($connStr)) {
      $errors += "Connection string vacío."
    }
    else {
      if ($connStr -notmatch '(?i)(^|;)server=') { $warnings += "Connection string sin 'Server='." }
      if ($connStr -notmatch '(?i)(^|;)database=') { $warnings += "Connection string sin 'Database='." }
    }
    if ([string]::IsNullOrWhiteSpace($table)) {
      $errors += "Nombre de tabla SQL vacío."
    }
    elseif ($table -notmatch '^[A-Za-z0-9_\.\[\]]+$') {
      $errors += "Nombre de tabla SQL con caracteres no permitidos."
    }

    if ($DeepTest -and ($errors.Count -eq 0)) {
      try {
        $cn = New-Object System.Data.SqlClient.SqlConnection($connStr)
        try {
          $cn.Open()
          $cmd = $cn.CreateCommand()
          $cmd.CommandText = "SELECT 1"
          [void]$cmd.ExecuteScalar()

          $cmd2 = $cn.CreateCommand()
          $cmd2.CommandText = "SELECT OBJECT_ID(@t)"
          [void]$cmd2.Parameters.Add('@t', [System.Data.SqlDbType]::NVarChar, 512)
          $cmd2.Parameters['@t'].Value = $table
          $objId = $cmd2.ExecuteScalar()
          if ($null -eq $objId -or $objId -eq [DBNull]::Value) {
            $warnings += "La tabla no existe o no es visible para la conexión: $table"
          }
          else {
            $lines += " - Conexión SQL y tabla: OK"
          }
        }
        finally {
          if ($cn) { $cn.Dispose() }
        }
      }
      catch {
        $errors += "Error de conexión SQL: $($_.Exception.Message)"
      }
    }
  }

  if ($script:AuditLastCentralOk) {
    $lines += " - Ultimo envio central OK: $($script:AuditLastCentralOk)"
  }
  if ($script:AuditLastCentralError) {
    $warnings += "Ultimo error central registrado: $($script:AuditLastCentralError)"
  }

  if ($errors.Count -gt 0) {
    $lines += ""
    $lines += "Errores:"
    foreach ($e in $errors) { $lines += " - $e" }
  }
  if ($warnings.Count -gt 0) {
    $lines += ""
    $lines += "Advertencias:"
    foreach ($w in $warnings) { $lines += " - $w" }
  }
  if (($errors.Count -eq 0) -and ($warnings.Count -eq 0)) {
    $lines += ""
    $lines += "Diagnostico: configuracion valida."
  }

  return [PSCustomObject]@{
    IsValid   = ($errors.Count -eq 0)
    HasWarn   = ($warnings.Count -gt 0)
    Lines     = @($lines)
    ErrorText = ($errors -join ' | ')
  }
}

function Get-AuditOperator {
  if ($global:activeDomain -and $global:activeDomain -ne $script:LocalDomainLabel) {
    $conn = $global:domainConnections[$global:activeDomain]
    if ($conn -and $conn.Credential -and $conn.Credential.UserName) {
      return [string]$conn.Credential.UserName
    }
  }
  try { return [System.Security.Principal.WindowsIdentity]::GetCurrent().Name } catch { return 'Unknown' }
}

function Get-AuditDomain {
  if ($global:activeDomain) { return [string]$global:activeDomain }
  return $script:LocalDomainLabel
}

function Get-AuditLocalLogPath([datetime]$Date = (Get-Date)) {
  $fileName = "{0}{1}.csv" -f $script:AuditLogFilePrefix, $Date.ToString('yyyy-MM-dd')
  return (Join-Path $script:AuditLogDir $fileName)
}

function Remove-AuditLocalExpiredFiles {
  if (-not (Test-Path -Path $script:AuditLogDir -PathType Container)) { return }

  $retentionMonths = [Math]::Max(1, [int]$script:AuditLocalRetentionMonths)
  $oldestToKeep = (Get-Date).Date.AddMonths(-$retentionMonths)
  $files = Get-ChildItem -Path $script:AuditLogDir -Filter ($script:AuditLogFilePrefix + '*.csv') -File -ErrorAction SilentlyContinue

  foreach ($file in @($files)) {
    if ($file.BaseName -match '^AD_Audit_(\d{4}-\d{2}-\d{2})$') {
      try {
        $fileDate = [datetime]::ParseExact($matches[1], 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
        if ($fileDate.Date -lt $oldestToKeep) {
          Remove-Item -Path $file.FullName -Force -ErrorAction SilentlyContinue
        }
      }
      catch {
        # Ignorar archivos con nombre inesperado.
      }
    }
  }
}

function Ensure-AuditLogFile([string]$path) {
  if ([string]::IsNullOrWhiteSpace($path)) { return }
  if (-not (Test-Path -Path $script:AuditLogDir -PathType Container)) {
    New-Item -Path $script:AuditLogDir -ItemType Directory -Force | Out-Null
  }
  if (-not (Test-Path -Path $path -PathType Leaf)) {
    [PSCustomObject]@{
      FechaHora = ''
      Operador  = ''
      Dominio   = ''
      Accion    = ''
      Resultado = ''
      Objeto    = ''
      Detalle   = ''
    } | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
    $existing = Get-Content -Path $path
    if ($existing.Count -gt 1) {
      Set-Content -Path $path -Value $existing[0] -Encoding UTF8
    }
  }
}

function New-AuditEntry(
  [string]$Action,
  [string]$Result,
  [string]$Object,
  [string]$Detail = ''
) {
  return [PSCustomObject]@{
    FechaHora = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Operador  = Get-AuditOperator
    Dominio   = Get-AuditDomain
    Accion    = $Action
    Resultado = $Result
    Objeto    = $Object
    Detalle   = $Detail
    Equipo    = $env:COMPUTERNAME
  }
}

function Ensure-CentralFileLog([string]$path) {
  if ([string]::IsNullOrWhiteSpace($path)) { return }
  $parent = Split-Path -Path $path -Parent
  if (-not [string]::IsNullOrWhiteSpace($parent) -and (-not (Test-Path -Path $parent -PathType Container))) {
    New-Item -Path $parent -ItemType Directory -Force | Out-Null
  }
  if (-not (Test-Path -Path $path -PathType Leaf)) {
    [PSCustomObject]@{
      FechaHora = ''
      Operador  = ''
      Dominio   = ''
      Accion    = ''
      Resultado = ''
      Objeto    = ''
      Detalle   = ''
      Equipo    = ''
    } | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
    $existing = Get-Content -Path $path
    if ($existing.Count -gt 1) {
      Set-Content -Path $path -Value $existing[0] -Encoding UTF8
    }
  }
}

function Write-AuditCentral([object]$entry) {
  if (-not $script:AuditSettings.EnableCentral) { return }

  switch ($script:AuditSettings.CentralMode) {
    'FileShare' {
      $centralPath = [string]$script:AuditSettings.CentralFilePath
      if ([string]::IsNullOrWhiteSpace($centralPath)) { return }
      Ensure-CentralFileLog -path $centralPath
      $line = $entry | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1
      Add-Content -Path $centralPath -Value $line -Encoding UTF8
      $script:AuditLastCentralError = ''
      $script:AuditLastCentralOk = ("{0} | FileShare | {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $centralPath)
    }
    'SqlServer' {
      $connStr = [string]$script:AuditSettings.SqlConnectionString
      $table = [string]$script:AuditSettings.SqlTable
      if ([string]::IsNullOrWhiteSpace($connStr) -or [string]::IsNullOrWhiteSpace($table)) { return }
      if ($table -notmatch '^[A-Za-z0-9_\.\[\]]+$') { throw "SqlTable contiene caracteres no permitidos: $table" }

      $cn = New-Object System.Data.SqlClient.SqlConnection($connStr)
      try {
        $cn.Open()
        $cmd = $cn.CreateCommand()
        $cmd.CommandText = "INSERT INTO $table (FechaHora, Operador, Dominio, Accion, Resultado, Objeto, Detalle, Equipo) VALUES (@FechaHora, @Operador, @Dominio, @Accion, @Resultado, @Objeto, @Detalle, @Equipo)"
        [void]$cmd.Parameters.Add('@FechaHora', [System.Data.SqlDbType]::DateTime2)
        [void]$cmd.Parameters.Add('@Operador', [System.Data.SqlDbType]::NVarChar, 255)
        [void]$cmd.Parameters.Add('@Dominio', [System.Data.SqlDbType]::NVarChar, 255)
        [void]$cmd.Parameters.Add('@Accion', [System.Data.SqlDbType]::NVarChar, 255)
        [void]$cmd.Parameters.Add('@Resultado', [System.Data.SqlDbType]::NVarChar, 64)
        [void]$cmd.Parameters.Add('@Objeto', [System.Data.SqlDbType]::NVarChar, 1024)
        [void]$cmd.Parameters.Add('@Detalle', [System.Data.SqlDbType]::NVarChar, -1)
        [void]$cmd.Parameters.Add('@Equipo', [System.Data.SqlDbType]::NVarChar, 255)

        $cmd.Parameters['@FechaHora'].Value = [datetime]::ParseExact($entry.FechaHora, 'yyyy-MM-dd HH:mm:ss', [System.Globalization.CultureInfo]::InvariantCulture)
        $cmd.Parameters['@Operador'].Value = [string]$entry.Operador
        $cmd.Parameters['@Dominio'].Value = [string]$entry.Dominio
        $cmd.Parameters['@Accion'].Value = [string]$entry.Accion
        $cmd.Parameters['@Resultado'].Value = [string]$entry.Resultado
        $cmd.Parameters['@Objeto'].Value = [string]$entry.Objeto
        $cmd.Parameters['@Detalle'].Value = [string]$entry.Detalle
        $cmd.Parameters['@Equipo'].Value = [string]$entry.Equipo
        [void]$cmd.ExecuteNonQuery()
        $script:AuditLastCentralError = ''
        $script:AuditLastCentralOk = ("{0} | SqlServer | {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $table)
      }
      finally {
        if ($cn) { $cn.Dispose() }
      }
    }
    default {
      throw "Modo central no soportado: $($script:AuditSettings.CentralMode)"
    }
  }
}

function Write-AuditLog(
  [string]$Action,
  [string]$Result,
  [string]$Object,
  [string]$Detail = ''
) {
  $entry = New-AuditEntry -Action $Action -Result $Result -Object $Object -Detail $Detail

  try {
    $localLogPath = Get-AuditLocalLogPath
    Ensure-AuditLogFile -path $localLogPath
    $localEntry = $entry | Select-Object FechaHora, Operador, Dominio, Accion, Resultado, Objeto, Detalle
    $line = $localEntry | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1
    Add-Content -Path $localLogPath -Value $line -Encoding UTF8
    Remove-AuditLocalExpiredFiles
  }
  catch {
    # No interrumpir la operación principal por un fallo de auditoría.
  }

  try {
    Write-AuditCentral -entry $entry
  }
  catch {
    $script:AuditLastCentralError = $_.Exception.Message
    # No interrumpir la operación principal por un fallo de auditoría central.
  }
}

function Update-AuditModeUiState {
  if (-not $cbAuditMode) { return }
  $mode = [string]$cbAuditMode.SelectedItem
  if ([string]::IsNullOrWhiteSpace($mode)) { $mode = 'FileShare' }

  $isFileShare = ($mode -eq 'FileShare')
  $txtAuditCentralFilePath.IsEnabled = $isFileShare
  $txtAuditSqlConnection.IsEnabled = (-not $isFileShare)
  $txtAuditSqlTable.IsEnabled = (-not $isFileShare)
}

if ($cbAuditMode) {
  $cbAuditMode.Add_SelectionChanged({
      Update-AuditModeUiState
      $diag = Get-AuditValidationResult
      Show-AuditDiagnostics -lines $diag.Lines
    })
}

if ($chkAuditEnableCentral) {
  $saveAuditToggle = {
    if ($script:AuditUiSyncInProgress) { return }
    try {
      Set-AuditSettingsFromGui
      Save-AuditSettingsToFile
      $diag = Get-AuditValidationResult
      Show-AuditDiagnostics -lines $diag.Lines
    }
    catch {
      # No interrumpir el flujo por fallos de persistencia del tilde.
    }
  }
  $chkAuditEnableCentral.Add_Checked($saveAuditToggle)
  $chkAuditEnableCentral.Add_Unchecked($saveAuditToggle)
}

if ($btnAuditApplyConfig) {
  $btnAuditApplyConfig.Add_Click({
      try {
        Set-AuditSettingsFromGui
        Update-AuditModeUiState
        $diag = Get-AuditValidationResult
        Show-AuditDiagnostics -lines $diag.Lines
        if (-not $diag.IsValid) {
          Set-Status "❌ Configuración inválida. Revisá Diagnóstico." '#f38ba8'
          return
        }
        Set-Status "✅ Configuración de auditoría aplicada." '#a6e3a1'
        Write-AuditLog -Action 'Aplicar Config Auditoria' -Result 'OK' -Object ([string]$script:AuditSettings.CentralMode)
      }
      catch { Show-Exception "Error aplicando configuración de auditoría:" $_ }
    })
}

if ($btnAuditSaveConfig) {
  $btnAuditSaveConfig.Add_Click({
      try {
        Set-AuditSettingsFromGui
        $diag = Get-AuditValidationResult
        Show-AuditDiagnostics -lines $diag.Lines
        if (-not $diag.IsValid) {
          Set-Status "❌ No se guardó: configuración inválida." '#f38ba8'
          return
        }
        Save-AuditSettingsToFile
        Set-Status "✅ Configuración guardada en: $($script:AuditConfigPath)" '#a6e3a1'
        Write-AuditLog -Action 'Guardar Config Auditoria' -Result 'OK' -Object $script:AuditConfigPath
      }
      catch { Show-Exception "Error guardando configuración de auditoría:" $_ }
    })
}

if ($btnAuditLoadConfig) {
  $btnAuditLoadConfig.Add_Click({
      try {
        if (Load-AuditSettingsFromFile) {
          Update-AuditGuiFromSettings
          Update-AuditModeUiState
          $diag = Get-AuditValidationResult
          Show-AuditDiagnostics -lines $diag.Lines
          if ($diag.IsValid) {
            Set-Status "✅ Configuración de auditoría cargada desde: $($script:AuditConfigPath)" '#a6e3a1'
          }
          else {
            Set-Status "⚠️ Configuración cargada con errores." '#fab387'
          }
          Write-AuditLog -Action 'Cargar Config Auditoria' -Result 'OK' -Object $script:AuditConfigPath
        }
        else {
          Show-AuditDiagnostics -lines @(
            "No existe archivo de configuración en ninguna ruta candidata.",
            "Rutas evaluadas: $(Get-AuditConfigCandidatesText)"
          )
          Set-Status "⚠️ No hay archivo de configuración de auditoría." '#fab387'
        }
      }
      catch { Show-Exception "Error cargando configuración de auditoría:" $_ }
    })
}

if ($btnAuditDiagnoseConfig) {
  $btnAuditDiagnoseConfig.Add_Click({
      try {
        Set-AuditSettingsFromGui
        $diag = Get-AuditValidationResult -DeepTest
        Show-AuditDiagnostics -lines $diag.Lines
        if ($diag.IsValid) {
          if ($diag.HasWarn) {
            Set-Status "⚠️ Diagnóstico OK con advertencias." '#fab387'
          }
          else {
            Set-Status "✅ Diagnóstico OK." '#a6e3a1'
          }
        }
        else {
          Set-Status "❌ Diagnóstico con errores." '#f38ba8'
        }
      }
      catch { Show-Exception "Error ejecutando diagnóstico de auditoría:" $_ }
    })
}

if ($btnAuditTestConfig) {
  $btnAuditTestConfig.Add_Click({
      $prevEnabled = [bool]$script:AuditSettings.EnableCentral
      try {
        Set-AuditSettingsFromGui
        $diag = Get-AuditValidationResult -DeepTest
        Show-AuditDiagnostics -lines $diag.Lines
        if (-not $diag.IsValid) {
          Set-Status "❌ No se ejecutó prueba: configuración inválida." '#f38ba8'
          return
        }

        $script:AuditSettings.EnableCentral = $true
        $testEntry = New-AuditEntry -Action 'Test Destino Auditoria' -Result 'TEST' -Object 'GUI Config'
        Write-AuditCentral -entry $testEntry
        $script:AuditSettings.EnableCentral = $prevEnabled
        $diagAfter = Get-AuditValidationResult
        Show-AuditDiagnostics -lines $diagAfter.Lines
        Set-Status "✅ Prueba de auditoría central OK." '#a6e3a1'
      }
      catch {
        $script:AuditSettings.EnableCentral = $prevEnabled
        Show-Exception "Error probando destino central de auditoría:" $_
      }
    })
}

# Persistir configuración de auditoría al cerrar la ventana, incluso si no se presiona "Guardar Configuración".
$window.Add_Closing({
    try {
      Set-AuditSettingsFromGui
      Save-AuditSettingsToFile
      Save-DomainConnectionsToFile
      Save-ThemePreference
    }
    catch {
      # No bloquear el cierre de la app por un error de guardado.
    }
  })

function Show-Error([string]$msg) {
  Set-Status "❌ $msg" '#f38ba8'
  [System.Windows.MessageBox]::Show($msg, "Error", "OK", "Error") | Out-Null
}
function Show-Confirm([string]$msg) {
  return ([System.Windows.MessageBox]::Show($msg, "Confirmar", "YesNo", "Warning") -eq 'Yes')
}
function Get-Checked([System.Windows.Controls.CheckBox]$cb) { return ($cb -and $cb.IsChecked -eq $true) }
function Test-Guard([bool]$condition, [string]$message) {
  if ($condition) { return $true }
  Show-Error $message
  return $false
}
function Get-RequiredTrimmedText([string]$text, [string]$message) {
  $value = $text.Trim()
  if ([string]::IsNullOrWhiteSpace($value)) {
    Show-Error $message
    return $null
  }
  return $value
}
function Merge-ADParams([hashtable]$params, [hashtable]$adParams = $null) {
  if ($null -eq $params) { return @{} }
  $merged = @{}
  foreach ($key in $params.Keys) { $merged[$key] = $params[$key] }
  if ($null -eq $adParams) { $adParams = Get-ADParams }
  foreach ($key in $adParams.Keys) { $merged[$key] = $adParams[$key] }
  return $merged
}
function Get-NormalizedText([object]$value) {
  if ($null -eq $value) { return '' }
  return ([string]$value).Trim()
}
function Escape-ADFilterLiteral([string]$value) {
  if ($null -eq $value) { return '' }
  return $value.Replace("'", "''")
}
function Get-PolicyValue([object]$obj, [string]$name, $defaultValue = $null) {
  if ($null -eq $obj) { return $defaultValue }
  if ($obj -is [System.Collections.IDictionary]) {
    $hasKey = $false
    try {
      if ($obj.PSObject -and $obj.PSObject.Methods['ContainsKey']) {
        $hasKey = [bool]($obj.ContainsKey($name))
      }
      else {
        $hasKey = [bool]($obj.Contains($name))
      }
    }
    catch {
      $hasKey = [bool]($obj.Contains($name))
    }
    if ($hasKey) { return $obj[$name] }
  }
  if ($obj.PSObject -and $obj.PSObject.Properties[$name]) { return $obj.PSObject.Properties[$name].Value }
  return $defaultValue
}
function Test-PolicyPropertyExists([object]$obj, [string]$name) {
  if ($null -eq $obj) { return $false }
  if ($obj -is [System.Collections.IDictionary]) {
    try {
      if ($obj.PSObject -and $obj.PSObject.Methods['ContainsKey']) { return [bool]($obj.ContainsKey($name)) }
      return [bool]($obj.Contains($name))
    }
    catch {
      return [bool]($obj.Contains($name))
    }
  }
  return [bool]($obj.PSObject -and $obj.PSObject.Properties[$name])
}
function Set-PolicyValue([object]$obj, [string]$name, $value) {
  if ($null -eq $obj) { return }
  if ($obj -is [System.Collections.IDictionary]) {
    $obj[$name] = $value
    return
  }
  if ($obj.PSObject -and $obj.PSObject.Properties[$name]) {
    $obj.PSObject.Properties[$name].Value = $value
    return
  }
  if ($obj.PSObject) {
    $obj | Add-Member -MemberType NoteProperty -Name $name -Value $value -Force
  }
}
function Get-UserAdminKeyHash([object]$policy = $null) {
  $p = $policy
  if ($null -eq $p) { $p = $script:UserPolicy }
  if ($null -eq $p) { return '' }

  $hash = [string](Get-PolicyValue $p 'AdminKeyHash' '')
  if (-not [string]::IsNullOrWhiteSpace($hash)) { return $hash.Trim() }

  if ($p -is [System.Collections.IDictionary]) {
    foreach ($k in @($p.Keys)) {
      if ([string]$k -ieq 'AdminKeyHash') {
        return ([string]$p[$k]).Trim()
      }
    }
  }

  return ''
}
function Set-UserAdminKeyHash([string]$hashValue) {
  if ($null -eq $script:UserPolicy) {
    $script:UserPolicy = Normalize-UserPolicy -rawPolicy $null
  }

  Set-PolicyValue -obj $script:UserPolicy -name 'AdminKeyHash' -value ([string]$hashValue)
  if ($script:UserPolicy -is [System.Collections.IDictionary]) {
    $script:UserPolicy['AdminKeyHash'] = [string]$hashValue
  }

  # Canonicalizar para persistencia estable y volver a afirmar el hash.
  $script:UserPolicy = Normalize-UserPolicy -rawPolicy $script:UserPolicy
  Set-PolicyValue -obj $script:UserPolicy -name 'AdminKeyHash' -value ([string]$hashValue)
}
function ConvertTo-Sha256Hex([string]$text) {
  if ([string]::IsNullOrEmpty($text)) { return '' }
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($text)
    $hash = $sha.ComputeHash($bytes)
    return ([System.BitConverter]::ToString($hash)).Replace('-', '').ToLowerInvariant()
  }
  finally {
    if ($sha) { $sha.Dispose() }
  }
}
function Get-DefaultUserPolicy {
  $baseFields = @(
    'FirstName', 'Initials', 'LastName', 'FullName', 'DisplayName', 'Description',
    'Office', 'OfficePhone', 'Email', 'WebPage',
    'StreetAddress', 'POBox', 'City', 'State', 'PostalCode', 'Country',
    'UpnUser', 'SamAccountName', 'Password', 'OU',
    'Enabled', 'MustChangePassword', 'CannotChangePassword', 'PasswordNeverExpires'
  )
  return [ordered]@{
    RequireKeyForCreate = $false
    RequireKeyForModify = $false
    RequireKeyForPolicyEdit = $true
    RequireKeyForKeyChange  = $true
    AdminKeyHash        = ''
    Create              = [ordered]@{
      Visible  = @($baseFields)
      Editable = @($baseFields)
      Required = @('FirstName', 'LastName', 'FullName', 'UpnUser', 'SamAccountName', 'Password', 'OU')
    }
    Modify              = [ordered]@{
      Visible  = @($baseFields)
      Editable = @($baseFields)
      Required = @('FirstName', 'LastName', 'FullName', 'UpnUser', 'SamAccountName', 'OU')
    }
  }
}
function Get-UserPolicyFieldCatalog {
  return @(
    [PSCustomObject]@{ Name = 'FirstName'; Label = 'Nombre' },
    [PSCustomObject]@{ Name = 'Initials'; Label = 'Iniciales' },
    [PSCustomObject]@{ Name = 'LastName'; Label = 'Apellido' },
    [PSCustomObject]@{ Name = 'FullName'; Label = 'Nombre completo (CN)' },
    [PSCustomObject]@{ Name = 'DisplayName'; Label = 'Nombre para mostrar' },
    [PSCustomObject]@{ Name = 'Description'; Label = 'Descripción' },
    [PSCustomObject]@{ Name = 'Office'; Label = 'Oficina' },
    [PSCustomObject]@{ Name = 'OfficePhone'; Label = 'Teléfono' },
    [PSCustomObject]@{ Name = 'Email'; Label = 'Email' },
    [PSCustomObject]@{ Name = 'WebPage'; Label = 'Página Web' },
    [PSCustomObject]@{ Name = 'StreetAddress'; Label = 'Calle' },
    [PSCustomObject]@{ Name = 'POBox'; Label = 'Casilla Postal' },
    [PSCustomObject]@{ Name = 'City'; Label = 'Ciudad' },
    [PSCustomObject]@{ Name = 'State'; Label = 'Provincia/Estado' },
    [PSCustomObject]@{ Name = 'PostalCode'; Label = 'Código Postal' },
    [PSCustomObject]@{ Name = 'Country'; Label = 'País/Región' },
    [PSCustomObject]@{ Name = 'UpnUser'; Label = 'UPN (usuario)' },
    [PSCustomObject]@{ Name = 'SamAccountName'; Label = 'SAM' },
    [PSCustomObject]@{ Name = 'Password'; Label = 'Contraseña' },
    [PSCustomObject]@{ Name = 'OU'; Label = 'OU destino' },
    [PSCustomObject]@{ Name = 'Enabled'; Label = 'Cuenta habilitada' },
    [PSCustomObject]@{ Name = 'MustChangePassword'; Label = 'Debe cambiar contraseña' },
    [PSCustomObject]@{ Name = 'CannotChangePassword'; Label = 'No puede cambiar contraseña' },
    [PSCustomObject]@{ Name = 'PasswordNeverExpires'; Label = 'Contraseña no expira' }
  )
}
function Normalize-UserPolicy([object]$rawPolicy) {
  $base = Get-DefaultUserPolicy

  if ($null -eq $rawPolicy) { return $base }

  $base.RequireKeyForCreate = ConvertTo-BoolValue (Get-PolicyValue $rawPolicy 'RequireKeyForCreate' $base.RequireKeyForCreate) $true
  $base.RequireKeyForModify = ConvertTo-BoolValue (Get-PolicyValue $rawPolicy 'RequireKeyForModify' $base.RequireKeyForModify) $true
  $base.RequireKeyForPolicyEdit = ConvertTo-BoolValue (Get-PolicyValue $rawPolicy 'RequireKeyForPolicyEdit' $base.RequireKeyForPolicyEdit) $true
  $base.RequireKeyForKeyChange = ConvertTo-BoolValue (Get-PolicyValue $rawPolicy 'RequireKeyForKeyChange' $base.RequireKeyForKeyChange) $true
  $base.AdminKeyHash = Get-UserAdminKeyHash -policy $rawPolicy

  foreach ($mode in @('Create', 'Modify')) {
    $modeRaw = Get-PolicyValue $rawPolicy $mode $null
    $modeBase = $base[$mode]
    if ($null -eq $modeRaw) { continue }

    $hasVisible = Test-PolicyPropertyExists $modeRaw 'Visible'
    $hasEditable = Test-PolicyPropertyExists $modeRaw 'Editable'
    $hasRequired = Test-PolicyPropertyExists $modeRaw 'Required'
    $visible = @((Get-PolicyValue $modeRaw 'Visible' @()))
    $editable = @((Get-PolicyValue $modeRaw 'Editable' @()))
    $required = @((Get-PolicyValue $modeRaw 'Required' @()))

    if ($hasVisible) { $modeBase.Visible = @($visible | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique) }
    if ($hasEditable) { $modeBase.Editable = @($editable | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique) }
    if ($hasRequired) { $modeBase.Required = @($required | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique) }
  }

  return $base
}
function Get-UserPolicyConfigReadPaths {
  # Ruta canónica: variable de entorno (si existe) o archivo local junto al script.
  # Las rutas secundarias quedan solo como compatibilidad de lectura/migración.
  $paths = @()
  $primary = Get-UserPolicyConfigWritePath
  if (-not [string]::IsNullOrWhiteSpace($primary)) { $paths += $primary }
  if ((-not [string]::IsNullOrWhiteSpace($script:UserPolicyConfigLocalPath)) -and ($script:UserPolicyConfigLocalPath -ne $primary)) { $paths += $script:UserPolicyConfigLocalPath }
  if ((-not [string]::IsNullOrWhiteSpace($script:UserPolicyConfigAppDataPath)) -and ($script:UserPolicyConfigAppDataPath -ne $primary)) { $paths += $script:UserPolicyConfigAppDataPath }
  if ((-not [string]::IsNullOrWhiteSpace($script:UserPolicyConfigProgramDataPath)) -and ($script:UserPolicyConfigProgramDataPath -ne $primary)) { $paths += $script:UserPolicyConfigProgramDataPath }
  foreach ($legacy in @($script:UserPolicyLegacyPaths)) {
    if (-not [string]::IsNullOrWhiteSpace([string]$legacy)) { $paths += [string]$legacy }
  }
  return @($paths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
}
function Get-UserPolicyConfigWritePath {
  if (-not [string]::IsNullOrWhiteSpace($script:UserPolicyConfigEnvPath)) { return $script:UserPolicyConfigEnvPath }
  if (-not [string]::IsNullOrWhiteSpace($script:UserPolicyConfigLocalPath)) { return $script:UserPolicyConfigLocalPath }
  if (-not [string]::IsNullOrWhiteSpace($script:UserPolicyConfigAppDataPath)) { return $script:UserPolicyConfigAppDataPath }
  if (-not [string]::IsNullOrWhiteSpace($script:UserPolicyConfigPath)) { return $script:UserPolicyConfigPath }
  return (Join-Path (Get-Location).Path 'user.form.policy.json')
}
function Read-UserPolicyFile([string]$path) {
  if ([string]::IsNullOrWhiteSpace($path)) { throw "Ruta de política inválida." }
  if (-not (Test-Path -Path $path -PathType Leaf)) { throw "No existe el archivo de política: $path" }
  $raw = Get-Content -Path $path -Raw -ErrorAction Stop
  if ([string]::IsNullOrWhiteSpace($raw)) { throw "El archivo de política está vacío: $path" }
  return ($raw | ConvertFrom-Json -ErrorAction Stop)
}
function Get-UserPolicyConfigCandidatesText {
  $paths = Get-UserPolicyConfigReadPaths
  if ($null -eq $paths -or $paths.Count -eq 0) { return '(sin rutas configuradas)' }
  return ($paths -join ' | ')
}
function Write-UserPolicyFile([string]$path, [string]$json) {
  if ([string]::IsNullOrWhiteSpace($path)) { throw "Ruta de política inválida." }
  $parent = Split-Path -Path $path -Parent
  if ((-not [string]::IsNullOrWhiteSpace($parent)) -and (-not (Test-Path -Path $parent -PathType Container))) {
    New-Item -Path $parent -ItemType Directory -Force | Out-Null
  }
  Set-Content -Path $path -Value $json -Encoding UTF8
}
function Ensure-UserPolicyLoaded([switch]$ForceReload) {
  if ((-not $ForceReload) -and ($null -ne $script:UserPolicy)) { return }

  $currentPolicy = $script:UserPolicy
  $existingPaths = @()
  foreach ($candidate in (Get-UserPolicyConfigReadPaths)) {
    if (Test-Path -Path $candidate -PathType Leaf) { $existingPaths += $candidate }
  }

  # Respetar orden de prioridad definido en Get-UserPolicyConfigReadPaths.

  $loaded = $null
  $loadedPath = ''
  $lastErrorMessage = ''
  foreach ($path in @($existingPaths)) {
    try {
      $loaded = Read-UserPolicyFile -path $path
      if ($loaded) {
        $loadedPath = $path
        break
      }
    }
    catch {
      $lastErrorMessage = $_.Exception.Message
    }
  }

  if ($loaded) {
    $script:UserPolicy = Normalize-UserPolicy -rawPolicy $loaded
    $script:UserPolicyConfigPath = $loadedPath

    # Migración automática: si vino de ruta legacy, persistir en ruta principal.
    $writePath = Get-UserPolicyConfigWritePath
    if ((-not [string]::IsNullOrWhiteSpace($writePath)) -and ($writePath -ne $loadedPath)) {
      try { [void](Save-UserPolicyToFile) } catch {}
    }
    return
  }

  if ((-not [string]::IsNullOrWhiteSpace($lastErrorMessage)) -and ($existingPaths.Count -gt 0)) {
    # Fail-safe: conservar política en memoria si falla la lectura/parseo.
    if ($null -ne $currentPolicy) {
      $script:UserPolicy = Normalize-UserPolicy -rawPolicy $currentPolicy
      return
    }
  }

  if ($null -ne $currentPolicy) {
    $script:UserPolicy = Normalize-UserPolicy -rawPolicy $currentPolicy
    return
  }

  $script:UserPolicy = Normalize-UserPolicy -rawPolicy $null
  $script:UserPolicyConfigPath = Get-UserPolicyConfigWritePath
}
function Save-UserPolicyToFile {
  if ($null -eq $script:UserPolicy) { Ensure-UserPolicyLoaded }
  if ($null -eq $script:UserPolicy) { return $false }
  $script:UserPolicy = Normalize-UserPolicy -rawPolicy $script:UserPolicy
  Set-PolicyValue -obj $script:UserPolicy -name 'AdminKeyHash' -value (Get-UserAdminKeyHash -policy $script:UserPolicy)
  $json = $script:UserPolicy | ConvertTo-Json -Depth 8

  $targetPath = Get-UserPolicyConfigWritePath
  if ([string]::IsNullOrWhiteSpace($targetPath)) {
    Set-Status "⚠️ No se pudo guardar la política de usuarios: ruta destino vacía." '#fab387'
    return $false
  }

  try {
    Write-UserPolicyFile -path $targetPath -json $json
    if (-not (Test-Path -Path $targetPath -PathType Leaf)) {
      throw "El archivo no quedó creado en disco."
    }
    $reloaded = Normalize-UserPolicy -rawPolicy (Read-UserPolicyFile -path $targetPath)
    try {
      $resolved = (Resolve-Path -Path $targetPath -ErrorAction Stop).Path
      $script:UserPolicyConfigPath = [string]$resolved
    }
    catch {
      $script:UserPolicyConfigPath = [string]$targetPath
    }
    $script:UserPolicy = $reloaded
    return $true
  }
  catch {
    $detail = if ($_.Exception -and $_.Exception.Message) { $_.Exception.Message } else { 'Error desconocido.' }
    Set-Status "⚠️ No se pudo guardar la política de usuarios en: $targetPath" '#fab387'
    Write-AuditLog -Action 'Guardar Politica Usuarios' -Result 'ERROR' -Object $targetPath -Detail $detail
    return $false
  }
}
function Get-UserPolicyList([ValidateSet('Create', 'Modify')] [string]$Mode, [ValidateSet('Visible', 'Editable', 'Required')] [string]$ListName) {
  Ensure-UserPolicyLoaded
  $modeObj = Get-PolicyValue $script:UserPolicy $Mode $null
  $list = @((Get-PolicyValue $modeObj $ListName @()))
  if ($list.Count -eq 0) { return @() }
  return @($list | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
}
function Test-UserFieldVisible([ValidateSet('Create', 'Modify')] [string]$Mode, [string]$Field) {
  return $true
}
function Test-UserFieldEditable([ValidateSet('Create', 'Modify')] [string]$Mode, [string]$Field) {
  return $true
}
function Test-UserFieldRequired([ValidateSet('Create', 'Modify')] [string]$Mode, [string]$Field) {
  return $false
}
function Test-UserFieldValue([ValidateSet('Create', 'Modify')] [string]$Mode, [string]$Field, [string]$Value, [string]$ErrorMessage) {
  if ((Test-UserFieldRequired -Mode $Mode -Field $Field) -and [string]::IsNullOrWhiteSpace($Value)) {
    Show-Error $ErrorMessage
    return $false
  }
  return $true
}
function Apply-UserFieldUiPolicy([ValidateSet('Create', 'Modify')] [string]$Mode, [string]$Field, $LabelControl, $InputControl) {
  $isVisible = Test-UserFieldVisible -Mode $Mode -Field $Field
  $isEditable = Test-UserFieldEditable -Mode $Mode -Field $Field
  $visibility = if ($isVisible) { [System.Windows.Visibility]::Visible } else { [System.Windows.Visibility]::Collapsed }
  if ($LabelControl) { $LabelControl.Visibility = $visibility }
  if ($InputControl) {
    $InputControl.Visibility = $visibility
    if ($InputControl.PSObject -and $InputControl.PSObject.Properties['IsEnabled']) {
      $InputControl.IsEnabled = $isEditable
    }
  }
}
function New-DefaultSam([string]$firstName, [string]$lastName, [string]$fallback = 'usuario') {
  $fn = Get-NormalizedText $firstName
  $ln = Get-NormalizedText $lastName
  $base = ''
  if ((-not [string]::IsNullOrWhiteSpace($fn)) -and (-not [string]::IsNullOrWhiteSpace($ln))) {
    $base = "$($fn.Substring(0, 1))$ln"
  }
  elseif (-not [string]::IsNullOrWhiteSpace($ln)) {
    $base = $ln
  }
  elseif (-not [string]::IsNullOrWhiteSpace($fn)) {
    $base = $fn
  }
  else {
    $base = $fallback
  }
  $norm = (($base.ToLowerInvariant()) -replace '[^a-z0-9._-]', '')
  if ([string]::IsNullOrWhiteSpace($norm)) { return 'usuario' }
  return $norm
}
function Request-UserAdminUnlock([switch]$ForcePrompt) {
  Ensure-UserPolicyLoaded
  $hash = Get-UserAdminKeyHash
  if ([string]::IsNullOrWhiteSpace($hash)) {
    return $false
  }
  if ((-not $ForcePrompt) -and $script:UserPolicyUnlocked) { return $true }

  $dlg = New-DialogWindow "Desbloquear administración de usuarios" 430 230
  $sp = New-Object System.Windows.Controls.StackPanel
  $sp.Margin = '16'
  $sp.Children.Add((New-DlgLabel "Ingresá la clave de administración:"))
  $tbKey = New-DlgPasswordBox
  $sp.Children.Add($tbKey)
  $btnOk = New-DlgButton "Desbloquear" 'Warn'
  $btnCancel = New-DlgButton "Cancelar" 'Primary'
  $btnCancel.Margin = '0,6,0,0'
  $sp.Children.Add($btnOk)
  $sp.Children.Add($btnCancel)
  $dlg.Content = $sp

  $approved = $false
  $tbKey.Add_KeyDown({
      if ($_.Key -eq 'Return') {
        $btnOk.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
      }
    }.GetNewClosure())
  $btnOk.Add_Click({
      $input = [string]$tbKey.Password
      $inputHash = ConvertTo-Sha256Hex $input
      if ($inputHash -eq $hash) {
        $approved = $true
        $dlg.Close()
      }
      else {
        Show-Error "Clave incorrecta."
      }
    }.GetNewClosure())
  $btnCancel.Add_Click({ $dlg.Close() })
  $dlg.ShowDialog() | Out-Null

  if ($approved) {
    $script:UserPolicyUnlocked = $true
    Set-Status "✅ Administración de usuarios desbloqueada para esta sesión." '#a6e3a1'
    return $true
  }
  return $false
}
function Assert-UserAdminPermission([ValidateSet('Create', 'Modify')] [string]$Operation) {
  # Uso diario sin clave: crear/modificar usuarios no requiere desbloqueo.
  # La clave admin se reserva para editar política de campos y cambiar la clave.
  return $true
}
function Assert-UserPolicyAdminPermission([ValidateSet('PolicyEdit', 'KeyChange')] [string]$Operation) {
  Ensure-UserPolicyLoaded
  $hash = Get-UserAdminKeyHash
  if ([string]::IsNullOrWhiteSpace($hash)) {
    Ensure-UserPolicyLoaded -ForceReload
    $hash = Get-UserAdminKeyHash
  }

  if ([string]::IsNullOrWhiteSpace($hash)) {
    if ($Operation -eq 'PolicyEdit') {
      Show-Error "Primero configurá una clave de administración en 'Configurar Clave Admin'.`n`nArchivo de política: $script:UserPolicyConfigPath"
      return $false
    }
    return $true
  }

  $requireKey = $true
  if ($Operation -eq 'PolicyEdit') {
    $requireKey = ConvertTo-BoolValue (Get-PolicyValue $script:UserPolicy 'RequireKeyForPolicyEdit' $true) $true
  }
  else {
    $requireKey = ConvertTo-BoolValue (Get-PolicyValue $script:UserPolicy 'RequireKeyForKeyChange' $true) $true
  }

  if (-not $requireKey) { return $true }
  if (Request-UserAdminUnlock -ForcePrompt) { return $true }
  Show-Error "No autorizado. Se requiere clave de administración."
  return $false
}
function Show-UserPolicyEditor {
  Ensure-UserPolicyLoaded
  if (-not (Assert-UserPolicyAdminPermission -Operation 'PolicyEdit')) { return }

  $dlg = New-DialogWindow "Política de campos de usuarios" 1120 680
  $root = New-Object System.Windows.Controls.Grid
  $root.Margin = '12'
  $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = 'Auto' }))
  $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = '*' }))
  $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = 'Auto' }))

  $hint = New-Object System.Windows.Controls.TextBlock
  $hint.Text = "Marcá qué campos se ven/editan/requieren en Crear y Modificar."
  $hint.Margin = '0,0,0,8'
  $hint.Foreground = ConvertTo-Brush (Get-ActiveTheme).TextSecondary
  [System.Windows.Controls.Grid]::SetRow($hint, 0)
  $root.Children.Add($hint) | Out-Null

  $createVisible = Get-UserPolicyList -Mode 'Create' -ListName 'Visible'
  $createEditable = Get-UserPolicyList -Mode 'Create' -ListName 'Editable'
  $createRequired = Get-UserPolicyList -Mode 'Create' -ListName 'Required'
  $modifyVisible = Get-UserPolicyList -Mode 'Modify' -ListName 'Visible'
  $modifyEditable = Get-UserPolicyList -Mode 'Modify' -ListName 'Editable'
  $modifyRequired = Get-UserPolicyList -Mode 'Modify' -ListName 'Required'

  $rows = @()
  foreach ($f in (Get-UserPolicyFieldCatalog)) {
    $rows += [PSCustomObject]@{
      FieldName       = [string]$f.Name
      FieldLabel      = [string]$f.Label
      C_Visible       = ($createVisible -contains [string]$f.Name)
      C_Editable      = ($createEditable -contains [string]$f.Name)
      C_Required      = ($createRequired -contains [string]$f.Name)
      M_Visible       = ($modifyVisible -contains [string]$f.Name)
      M_Editable      = ($modifyEditable -contains [string]$f.Name)
      M_Required      = ($modifyRequired -contains [string]$f.Name)
    }
  }

  $dg = New-Object System.Windows.Controls.DataGrid
  $dg.AutoGenerateColumns = $false
  $dg.CanUserAddRows = $false
  $dg.IsReadOnly = $false
  $dg.EnableRowVirtualization = $false
  $dg.EnableColumnVirtualization = $false
  $dg.ItemsSource = @($rows)
  $dg.SelectionMode = 'Single'
  $dg.Margin = '0,0,0,4'
  [void]$dg.Columns.Add((New-Object System.Windows.Controls.DataGridTextColumn -Property @{ Header = 'Campo'; Binding = (New-Object System.Windows.Data.Binding('FieldLabel')); IsReadOnly = $true; Width = 220 }))
  function New-PolicyCheckColumn([string]$header, [string]$path, [double]$width = 95) {
    $template = New-Object System.Windows.DataTemplate
    $factory = New-Object System.Windows.FrameworkElementFactory([System.Windows.Controls.CheckBox])
    $factory.SetValue([System.Windows.Controls.CheckBox]::HorizontalAlignmentProperty, [System.Windows.HorizontalAlignment]::Center)
    $factory.SetValue([System.Windows.Controls.CheckBox]::VerticalAlignmentProperty, [System.Windows.VerticalAlignment]::Center)
    $factory.SetValue([System.Windows.Controls.CheckBox]::IsThreeStateProperty, $false)
    # Single-click real en DataGrid: evita el primer click solo para enfocar celda.
    $factory.SetValue([System.Windows.Controls.CheckBox]::FocusableProperty, $false)
    $factory.SetValue([System.Windows.Controls.CheckBox]::IsTabStopProperty, $false)
    $binding = New-Object System.Windows.Data.Binding($path)
    $binding.Mode = [System.Windows.Data.BindingMode]::TwoWay
    $binding.UpdateSourceTrigger = [System.Windows.Data.UpdateSourceTrigger]::PropertyChanged
    $factory.SetBinding([System.Windows.Controls.CheckBox]::IsCheckedProperty, $binding)
    $template.VisualTree = $factory

    $col = New-Object System.Windows.Controls.DataGridTemplateColumn
    $col.Header = $header
    $col.Width = $width
    $col.CellTemplate = $template
    $col.CellEditingTemplate = $template
    return $col
  }

  [void]$dg.Columns.Add((New-PolicyCheckColumn -header 'Crear Ver' -path 'C_Visible'))
  [void]$dg.Columns.Add((New-PolicyCheckColumn -header 'Crear Edit' -path 'C_Editable'))
  [void]$dg.Columns.Add((New-PolicyCheckColumn -header 'Crear Req' -path 'C_Required'))
  [void]$dg.Columns.Add((New-PolicyCheckColumn -header 'Mod Ver' -path 'M_Visible'))
  [void]$dg.Columns.Add((New-PolicyCheckColumn -header 'Mod Edit' -path 'M_Editable'))
  [void]$dg.Columns.Add((New-PolicyCheckColumn -header 'Mod Req' -path 'M_Required'))
  # UX: un solo clic en la celda de permiso alterna el valor (sin doble clic).
  $dg.Add_PreviewMouseLeftButtonDown({
      param($sender, $e)
      try {
        if ($null -eq $e) { return }
        $dep = $e.OriginalSource -as [System.Windows.DependencyObject]
        while ($dep -and (-not ($dep -is [System.Windows.Controls.DataGridCell]))) {
          $dep = [System.Windows.Media.VisualTreeHelper]::GetParent($dep)
        }
        if (-not $dep) { return }

        $cell = [System.Windows.Controls.DataGridCell]$dep
        $colHeader = [string]$cell.Column.Header
        $prop = switch ($colHeader) {
          'Crear Ver' { 'C_Visible' }
          'Crear Edit' { 'C_Editable' }
          'Crear Req' { 'C_Required' }
          'Mod Ver' { 'M_Visible' }
          'Mod Edit' { 'M_Editable' }
          'Mod Req' { 'M_Required' }
          default { '' }
        }
        if ([string]::IsNullOrWhiteSpace($prop)) { return }

        $row = $cell.DataContext
        if ($null -eq $row) { return }

        $current = ConvertTo-BoolValue (Get-PolicyValue $row $prop $false) $false
        Set-PolicyValue -obj $row -name $prop -value (-not $current)
        # El origen es PSCustomObject (sin INotifyPropertyChanged), refrescar para reflejar el tilde.
        $dg.Items.Refresh()
        $e.Handled = $true
      }
      catch {
        # Mantener comportamiento estándar si falla el toggle asistido.
      }
    }.GetNewClosure())
  [System.Windows.Controls.Grid]::SetRow($dg, 1)
  $root.Children.Add($dg) | Out-Null

  $actions = New-Object System.Windows.Controls.WrapPanel
  $actions.HorizontalAlignment = 'Right'
  [System.Windows.Controls.Grid]::SetRow($actions, 2)
  $root.Children.Add($actions) | Out-Null

  $btnSave = New-DlgButton "Guardar y aplicar" 'Success'
  $btnSave.Margin = '0,8,8,0'
  $btnJson = New-DlgButton "Editar JSON" 'Warn'
  $btnJson.Margin = '0,8,8,0'
  $btnCancel = New-DlgButton "Cancelar" 'Primary'
  $btnCancel.Margin = '0,8,0,0'
  $actions.Children.Add($btnSave) | Out-Null
  $actions.Children.Add($btnJson) | Out-Null
  $actions.Children.Add($btnCancel) | Out-Null

  $btnSave.Add_Click({
      try {
        # Mover foco para cerrar edición activa en checkbox/texto.
        $btnSave.Focus()
        # Si hay una celda en edición, forzar commit antes de leer ItemsSource.
        [void]$dg.CommitEdit([System.Windows.Controls.DataGridEditingUnit]::Cell, $true)
        [void]$dg.CommitEdit([System.Windows.Controls.DataGridEditingUnit]::Row, $true)
        $dg.UpdateLayout()

        $gridRows = @()
        foreach ($item in @($dg.Items)) {
          if ($null -eq $item) { continue }
          if ($item -is [System.Windows.Data.CollectionViewGroup]) { continue }
          if ($item -is [System.Windows.Controls.ItemCollection]) { continue }
          if ([string]$item -eq '{NewItemPlaceholder}') { continue }

          $fieldName = [string](Get-PolicyValue $item 'FieldName' '')
          if ([string]::IsNullOrWhiteSpace($fieldName)) { continue }

          $gridRows += $item
        }
        if ($gridRows.Count -eq 0) { $gridRows = @($rows) }

        $createVisibleOut = @()
        $createEditableOut = @()
        $createRequiredOut = @()
        $modifyVisibleOut = @()
        $modifyEditableOut = @()
        $modifyRequiredOut = @()
        foreach ($r in @($gridRows)) {
          if ($null -eq $r) { continue }
          $name = [string]$r.FieldName
          if ([string]::IsNullOrWhiteSpace($name)) { continue }
          $cv = ConvertTo-BoolValue $r.C_Visible $false
          $ce = ConvertTo-BoolValue $r.C_Editable $false
          $cr = ConvertTo-BoolValue $r.C_Required $false
          $mv = ConvertTo-BoolValue $r.M_Visible $false
          $me = ConvertTo-BoolValue $r.M_Editable $false
          $mr = ConvertTo-BoolValue $r.M_Required $false

          if ($cv) { $createVisibleOut += $name }
          if ($ce) { $createEditableOut += $name }
          if ($cr) { $createRequiredOut += $name }
          if ($mv) { $modifyVisibleOut += $name }
          if ($me) { $modifyEditableOut += $name }
          if ($mr) { $modifyRequiredOut += $name }
        }

        $script:UserPolicy = Normalize-UserPolicy -rawPolicy $script:UserPolicy
        Set-PolicyValue -obj (Get-PolicyValue $script:UserPolicy 'Create' $null) -name 'Visible' -value @($createVisibleOut | Select-Object -Unique)
        Set-PolicyValue -obj (Get-PolicyValue $script:UserPolicy 'Create' $null) -name 'Editable' -value @($createEditableOut | Select-Object -Unique)
        Set-PolicyValue -obj (Get-PolicyValue $script:UserPolicy 'Create' $null) -name 'Required' -value @($createRequiredOut | Select-Object -Unique)
        Set-PolicyValue -obj (Get-PolicyValue $script:UserPolicy 'Modify' $null) -name 'Visible' -value @($modifyVisibleOut | Select-Object -Unique)
        Set-PolicyValue -obj (Get-PolicyValue $script:UserPolicy 'Modify' $null) -name 'Editable' -value @($modifyEditableOut | Select-Object -Unique)
        Set-PolicyValue -obj (Get-PolicyValue $script:UserPolicy 'Modify' $null) -name 'Required' -value @($modifyRequiredOut | Select-Object -Unique)

        $script:UserPolicy = Normalize-UserPolicy -rawPolicy $script:UserPolicy
        if (-not (Save-UserPolicyToFile)) {
          throw "No se pudo persistir la política en archivo."
        }
        # Verificar persistencia real: recargar desde disco y aplicar.
        Ensure-UserPolicyLoaded -ForceReload
        $script:UserPolicy = Normalize-UserPolicy -rawPolicy $script:UserPolicy
        $savedPath = [string]$script:UserPolicyConfigPath
        if ([string]::IsNullOrWhiteSpace($savedPath)) { $savedPath = [string](Get-UserPolicyConfigWritePath) }
        if ([string]::IsNullOrWhiteSpace($savedPath)) { $savedPath = '(sin ruta resuelta)' }
        Set-Status "✅ Política guardada y aplicada. Ruta: $savedPath" '#a6e3a1'
        Write-AuditLog -Action 'Guardar Politica Usuarios' -Result 'OK' -Object $script:UserPolicyConfigPath
        $dlg.Close()
      }
      catch {
        $detail = if ($_.Exception -and $_.Exception.Message) { $_.Exception.Message } else { 'Error desconocido.' }
        Show-Error "No se pudo guardar la política de campos. Verificá que la clave de administración esté autenticada.`n`nDetalle: $detail"
      }
    }.GetNewClosure())
  $btnJson.Add_Click({
      $jsonDlg = New-DialogWindow "Política JSON (avanzado)" 780 620
      $jsonRoot = New-Object System.Windows.Controls.Grid
      $jsonRoot.Margin = '12'
      $jsonRoot.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = '*' }))
      $jsonRoot.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = 'Auto' }))
      $tbJson = New-Object System.Windows.Controls.TextBox
      $tbJson.AcceptsReturn = $true
      $tbJson.AcceptsTab = $true
      $tbJson.TextWrapping = 'NoWrap'
      $tbJson.VerticalScrollBarVisibility = 'Auto'
      $tbJson.HorizontalScrollBarVisibility = 'Auto'
      $tbJson.FontFamily = 'Consolas'
      $tbJson.FontSize = 12
      $tbJson.Text = ($script:UserPolicy | ConvertTo-Json -Depth 8)
      [System.Windows.Controls.Grid]::SetRow($tbJson, 0)
      $jsonRoot.Children.Add($tbJson) | Out-Null
      $jsonActions = New-Object System.Windows.Controls.WrapPanel
      $jsonActions.HorizontalAlignment = 'Right'
      [System.Windows.Controls.Grid]::SetRow($jsonActions, 1)
      $jsonRoot.Children.Add($jsonActions) | Out-Null
      $btnJsonSave = New-DlgButton "Guardar JSON" 'Success'
      $btnJsonCancel = New-DlgButton "Cerrar" 'Primary'
      $btnJsonSave.Margin = '0,8,8,0'
      $btnJsonCancel.Margin = '0,8,0,0'
      $jsonActions.Children.Add($btnJsonSave) | Out-Null
      $jsonActions.Children.Add($btnJsonCancel) | Out-Null
      $btnJsonSave.Add_Click({
          try {
            $parsed = $tbJson.Text | ConvertFrom-Json -ErrorAction Stop
            $script:UserPolicy = Normalize-UserPolicy -rawPolicy $parsed
            Save-UserPolicyToFile
            Set-Status "✅ Política guardada desde JSON." '#a6e3a1'
            $jsonDlg.Close()
            $dlg.Close()
          }
          catch { Show-Error "JSON inválido." }
        }.GetNewClosure())
      $btnJsonCancel.Add_Click({ $jsonDlg.Close() })
      $jsonDlg.Content = $jsonRoot
      $jsonDlg.ShowDialog() | Out-Null
    }.GetNewClosure())
  $btnCancel.Add_Click({ $dlg.Close() })

  $dlg.Content = $root
  $dlg.ShowDialog() | Out-Null
}
function Set-UserAdminKey {
  Ensure-UserPolicyLoaded
  $script:UserPolicy = Normalize-UserPolicy -rawPolicy $script:UserPolicy
  $currentHash = Get-UserAdminKeyHash
  if (-not [string]::IsNullOrWhiteSpace($currentHash)) {
    if (-not (Assert-UserPolicyAdminPermission -Operation 'KeyChange')) { return }
  }

  $dlg = New-DialogWindow "Configurar clave de administración" 460 300
  $sp = New-Object System.Windows.Controls.StackPanel
  $sp.Margin = '16'
  $sp.Children.Add((New-DlgLabel "Nueva clave:"))
  $tbNew = New-DlgPasswordBox
  $sp.Children.Add($tbNew)
  $sp.Children.Add((New-DlgLabel "Repetir clave:"))
  $tbConfirm = New-DlgPasswordBox
  $sp.Children.Add($tbConfirm)
  $btnSave = New-DlgButton "Guardar clave" 'Success'
  $btnClear = New-DlgButton "Quitar clave" 'Danger'
  $btnClear.Margin = '0,6,0,0'
  $sp.Children.Add($btnSave)
  $sp.Children.Add($btnClear)
  $dlg.Content = $sp

  $btnSave.Add_Click({
      if (-not [string]::IsNullOrWhiteSpace($currentHash)) {
        if (-not (Request-UserAdminUnlock -ForcePrompt)) { return }
      }
      $newKey = [string]$tbNew.Password
      $confirmKey = [string]$tbConfirm.Password
      if ([string]::IsNullOrWhiteSpace($newKey)) {
        Show-Error "Ingresá una clave."
        return
      }
      if ($newKey -ne $confirmKey) {
        Show-Error "La confirmación no coincide."
        return
      }
      $newHash = ConvertTo-Sha256Hex $newKey
      if ([string]::IsNullOrWhiteSpace($newHash)) {
        Show-Error "No se pudo generar el hash de la clave."
        return
      }
      Set-UserAdminKeyHash -hashValue $newHash
      $hashInMemory = Get-UserAdminKeyHash
      if ([string]::IsNullOrWhiteSpace($hashInMemory)) {
        Show-Error "No se pudo aplicar la clave en memoria. Revisá permisos/estado de la política."
        return
      }
      $script:UserPolicyUnlocked = $true
      if (-not (Save-UserPolicyToFile)) {
        Show-Error "No se pudo guardar la clave en archivo.`nRuta: $script:UserPolicyConfigPath"
        return
      }
      Ensure-UserPolicyLoaded -ForceReload
      $hashReloaded = Get-UserAdminKeyHash
      if ([string]::IsNullOrWhiteSpace($hashReloaded)) {
        Show-Error "La clave no quedó persistida luego de recargar la política.`nRuta: $script:UserPolicyConfigPath"
        return
      }
      Set-Status "✅ Clave de administración actualizada." '#a6e3a1'
      Write-AuditLog -Action 'Configurar Clave Admin Usuarios' -Result 'OK' -Object 'UserPolicy'
      $dlg.Close()
    }.GetNewClosure())

  $btnClear.Add_Click({
      if ([string]::IsNullOrWhiteSpace($currentHash)) {
        Show-Error "No hay clave configurada para quitar."
        return
      }
      if (-not (Request-UserAdminUnlock -ForcePrompt)) { return }
      if (-not (Show-Confirm "¿Quitar la clave de administración de usuarios?")) { return }
      Set-UserAdminKeyHash -hashValue ''
      $script:UserPolicyUnlocked = $false
      if (-not (Save-UserPolicyToFile)) {
        Show-Error "No se pudo guardar la eliminación de clave.`nRuta: $script:UserPolicyConfigPath"
        return
      }
      Set-Status "✅ Clave de administración eliminada." '#a6e3a1'
      Write-AuditLog -Action 'Eliminar Clave Admin Usuarios' -Result 'OK' -Object 'UserPolicy'
      $dlg.Close()
    }.GetNewClosure())

  $dlg.ShowDialog() | Out-Null
}
function Get-TreeSelectionDN(
  [System.Windows.Controls.TreeView]$treeView,
  [string]$selectionMessage,
  [string]$invalidDnMessage,
  [switch]$DenyProtected,
  [string]$protectedMessage = "Por seguridad no se permite operar sobre 'Domain Controllers'."
) {
  $item = $treeView.SelectedItem
  if (-not (Test-Guard ($null -ne $item) $selectionMessage)) { return $null }

  $dn = [string]$item.Tag
  if (-not (Test-Guard (-not [string]::IsNullOrWhiteSpace($dn)) $invalidDnMessage)) { return $null }

  if ($DenyProtected -and (Is-ProtectedContainerDN $dn)) {
    Show-Error $protectedMessage
    return $null
  }
  return $dn
}

function Show-Exception([string]$context, $err) {
  $msgText = ''
  if ($err -and $err.Exception -and $err.Exception.Message) { $msgText = [string]$err.Exception.Message }
  Write-AuditLog -Action $context -Result 'ERROR' -Object '' -Detail $msgText

  $msg = @(
    "$context",
    "",
    "Mensaje: $($err.Exception.Message)",
    "",
    "Tipo: $($err.Exception.GetType().FullName)",
    "",
    "Stack:",
    ($err.ScriptStackTrace | Out-String)
  ) -join "`n"
  Show-Error $msg
}

function Test-DCConnectivityAtStartup([int]$TimeoutSeconds = 5, [object]$SplashUi = $null, [switch]$IncludeRemoteTargets) {
  $script:StartupDcError = ''
  $script:StartupDomainChecks = @()
  $script:StartupDomainFailures = @()
  $timeout = [Math]::Max(2, $TimeoutSeconds)

  $targets = @()
  $targets += [PSCustomObject]@{
    Label      = $script:LocalDomainLabel
    Server     = ''
    Credential = $null
    IsLocal    = $true
  }

  if ($IncludeRemoteTargets) {
    foreach ($label in @($global:domainConnections.Keys | Sort-Object)) {
      $conn = $global:domainConnections[$label]
      if (-not $conn) { continue }
      $targets += [PSCustomObject]@{
        Label      = [string]$label
        Server     = [string]$conn.Server
        Credential = $conn.Credential
        IsLocal    = $false
      }
    }
  }

  if ($targets.Count -eq 0) { return $false }

  $checkSingleTarget = {
    param(
      [string]$Label,
      [string]$Server,
      $Credential,
      [bool]$IsLocalTarget,
      [int]$ProgressStart,
      [int]$ProgressEnd
    )

    $job = $null
    try {
      $job = Start-Job -ScriptBlock {
        param($serverArg, $credArg)

        Import-Module ActiveDirectory -ErrorAction Stop
        $params = @{}
        if (-not [string]::IsNullOrWhiteSpace([string]$serverArg)) { $params.Server = [string]$serverArg }
        if ($null -ne $credArg) { $params.Credential = $credArg }

        $domain = Get-ADDomain @params -ErrorAction Stop
        Get-ADRootDSE @params -ErrorAction Stop | Out-Null

        [PSCustomObject]@{
          Ok                 = $true
          DistinguishedName  = [string]$domain.DistinguishedName
          DNSRoot            = [string]$domain.DNSRoot
          UsersContainer     = [string]$domain.UsersContainer
          Server             = [string]$serverArg
          CredUser           = if ($credArg) { [string]$credArg.UserName } else { '' }
        }
      } -ArgumentList $Server, $Credential

      $waitTickSeconds = 1
      $elapsedSeconds = 0.0
      while ($true) {
        if (Wait-Job -Job $job -Timeout $waitTickSeconds) { break }
        $elapsedSeconds += $waitTickSeconds

        if ($SplashUi) {
          $ratio = [Math]::Min(1.0, ($elapsedSeconds / [double]$timeout))
          $currentProgress = $ProgressStart + [int]([Math]::Round(($ProgressEnd - $ProgressStart) * $ratio))
          Set-StartupSplashProgress -splashUi $SplashUi -percent $currentProgress -message "Validando dominio: $Label"
        }

        if ($elapsedSeconds -ge $timeout) {
          Stop-Job -Job $job -ErrorAction SilentlyContinue
          return [PSCustomObject]@{
            Ok      = $false
            Label   = $Label
            IsLocal = $IsLocalTarget
            Error   = "Tiempo de espera agotado (${timeout}s)."
          }
        }
      }

      $result = Receive-Job -Job $job -ErrorAction Stop
      if (-not $result -or (-not $result.Ok)) {
        return [PSCustomObject]@{
          Ok      = $false
          Label   = $Label
          IsLocal = $IsLocalTarget
          Error   = "No se obtuvo respuesta válida del controlador de dominio."
        }
      }

      $cacheServer = '(local)'
      if (-not [string]::IsNullOrWhiteSpace([string]$result.Server)) { $cacheServer = [string]$result.Server }
      $cacheCred = [string]$result.CredUser
      $cacheKey = "$cacheServer|$cacheCred"
      $script:ADDomainCache[$cacheKey] = [PSCustomObject]@{
        DistinguishedName = [string]$result.DistinguishedName
        DNSRoot           = [string]$result.DNSRoot
        UsersContainer    = [string]$result.UsersContainer
      }

      if ($IsLocalTarget -and (-not [string]::IsNullOrWhiteSpace([string]$result.DNSRoot))) {
        Set-LocalDomainIdentity -dnsRoot ([string]$result.DNSRoot)
      }

      return [PSCustomObject]@{
        Ok      = $true
        Label   = $Label
        IsLocal = $IsLocalTarget
        Error   = ''
      }
    }
    catch {
      $errMsg = if ($_.Exception -and $_.Exception.Message) { [string]$_.Exception.Message } else { "No se pudo contactar un controlador de dominio." }
      return [PSCustomObject]@{
        Ok      = $false
        Label   = $Label
        IsLocal = $IsLocalTarget
        Error   = $errMsg
      }
    }
    finally {
      if ($job) {
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
      }
    }
  }

  $count = [Math]::Max(1, $targets.Count)
  $rangeStart = 50
  $rangeEnd = 88
  $span = [Math]::Max(1, ($rangeEnd - $rangeStart))
  $localOk = $false

  for ($idx = 0; $idx -lt $targets.Count; $idx++) {
    $target = $targets[$idx]
    $currentIndex = $idx + 1
    $segmentStart = $rangeStart + [int]([Math]::Floor(($idx * $span) / $count))
    $segmentEnd = $rangeStart + [int]([Math]::Floor((($currentIndex) * $span) / $count))

    if ($SplashUi) {
      Set-StartupSplashProgress -splashUi $SplashUi -percent $segmentStart -message "Chequeando dominio [$currentIndex/$count]: $($target.Label)"
    }

    $check = & $checkSingleTarget `
      -Label ([string]$target.Label) `
      -Server ([string]$target.Server) `
      -Credential $target.Credential `
      -IsLocalTarget ([bool]$target.IsLocal) `
      -ProgressStart $segmentStart `
      -ProgressEnd $segmentEnd

    $finalCheck = $check
    if ((-not $check.Ok) -and $target.IsLocal) {
      if ($SplashUi) {
        Set-StartupSplashProgress -splashUi $SplashUi -percent $segmentEnd -message "Reintentando dominio local..."
      }
      Start-Sleep -Seconds 2
      $retryCheck = & $checkSingleTarget `
        -Label ([string]$target.Label) `
        -Server ([string]$target.Server) `
        -Credential $target.Credential `
        -IsLocalTarget ([bool]$target.IsLocal) `
        -ProgressStart $segmentStart `
        -ProgressEnd $segmentEnd
      if ($retryCheck.Ok) {
        $finalCheck = $retryCheck
      }
      else {
        $retryError = [string]$retryCheck.Error
        if (-not [string]::IsNullOrWhiteSpace($retryError)) {
          $finalCheck = [PSCustomObject]@{
            Ok      = $false
            Label   = [string]$retryCheck.Label
            IsLocal = [bool]$retryCheck.IsLocal
            Error   = "$($check.Error) Reintento: $retryError"
          }
        }
      }
    }

    $script:StartupDomainChecks += $finalCheck

    if ($finalCheck.Ok) {
      if ($target.IsLocal) { $localOk = $true }
    }
    else {
      $script:StartupDomainFailures += $finalCheck
      if ($target.IsLocal) {
        $script:StartupDcError = [string]$finalCheck.Error
      }
    }
  }

  if (-not $localOk -and [string]::IsNullOrWhiteSpace($script:StartupDcError)) {
    $script:StartupDcError = "No se pudo validar el dominio local."
  }

  return $localOk
}

function Get-DeferredRemoteDomainCount {
  if ($null -eq $global:domainConnections) { return 0 }
  return @($global:domainConnections.Keys).Count
}

function Show-StartupDomainFailuresSummary {
  if ($null -eq $script:StartupDomainFailures -or $script:StartupDomainFailures.Count -eq 0) { return }

  $lines = @()
  foreach ($f in @($script:StartupDomainFailures)) {
    $lines += " - $($f.Label): $($f.Error)"
  }

  $msg = @(
    "Se detectaron dominios con falla de conectividad al iniciar:",
    "",
    ($lines -join "`n"),
    "",
    "Podés seguir usando la app con los dominios que sí respondieron."
  ) -join "`n"

  $failedLabels = @($script:StartupDomainFailures | Select-Object -ExpandProperty Label)
  Set-Status ("⚠️ Falló conectividad en: " + ($failedLabels -join ', ')) '#fab387'
  [System.Windows.MessageBox]::Show($msg, "Conectividad de dominios", "OK", "Warning") | Out-Null
}

function Show-FriendlyDcUnavailableMessage {
  $detail = if ([string]::IsNullOrWhiteSpace($script:StartupDcError)) {
    "No se pudo contactar un controlador de dominio."
  }
  else {
    $script:StartupDcError
  }

  $msg = @(
    "No se pudo conectar al controlador de dominio al iniciar.",
    "",
    "Qué podés revisar:",
    " - Conectividad de red/VPN",
    " - DNS del equipo",
    " - Nombre del dominio o servidor configurado",
    "",
    "Detalle técnico:",
    $detail
  ) -join "`n"

  Set-Status "⚠️ Sin conexión al DC. La app abrió en modo limitado." '#fab387'
  [System.Windows.MessageBox]::Show($msg, "Conexión a DC no disponible", "OK", "Warning") | Out-Null
}

function Get-OUFromDN([string]$dn) {
  $parts = $dn -split ',', 2
  if ($parts.Count -gt 1) { return $parts[1] } else { return $dn }
}

function Get-ContainerLabelFromDN([string]$dn) {
  if ([string]::IsNullOrWhiteSpace($dn)) { return '' }
  $segments = @()
  foreach ($part in ($dn -split ',')) {
    if ($part -match '^(OU|CN)=(.+)$') {
      $segments += $matches[2]
    }
  }
  if (-not $segments -or $segments.Count -eq 0) { return $dn }
  [array]::Reverse($segments)
  return ($segments -join ' / ')
}

function Is-ProtectedContainerDN([string]$dn) {
  if ([string]::IsNullOrWhiteSpace($dn)) { return $false }
  return ($dn -match '^(?i)(OU|CN)=Domain Controllers,')
}

function Get-SelectedUser {
  $sel = $dgUsers.SelectedItem
  if (-not $sel) { Show-Error "Seleccioná un usuario de la lista."; return $null }
  return $sel
}
function Get-SelectedGroup {
  $sel = $dgGroups.SelectedItem
  if (-not $sel) { Show-Error "Seleccioná un grupo de la lista."; return $null }
  return $sel
}
function Get-SelectedComputer {
  $sel = $dgComputers.SelectedItem
  if (-not $sel) { Show-Error "Seleccioná una computadora de la lista."; return $null }
  return $sel
}

function Raise-ButtonClick([System.Windows.Controls.Button]$button) {
  if ($button) {
    $button.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
  }
}

function Bind-EnterKeyToButton([System.Windows.Controls.TextBox]$textBox, [System.Windows.Controls.Button]$button) {
  $textBox.Add_KeyDown({
      if ($_.Key -eq 'Return') {
        Raise-ButtonClick $button
      }
    }.GetNewClosure())
}

function Invoke-AdWriteOperation(
  [scriptblock]$Action,
  [string]$AuditAction,
  [string]$AuditObject,
  [string]$SuccessStatus,
  [string]$SimulatedStatus = '',
  [scriptblock]$OnSuccess = $null
) {
  $isSimulation = [bool]$script:SimulationMode
  $statusText = $SuccessStatus
  $auditResult = 'OK'

  if ($isSimulation) {
    if ([string]::IsNullOrWhiteSpace($SimulatedStatus)) {
      $statusText = "[SIMULATION] $SuccessStatus"
    }
    else {
      $statusText = $SimulatedStatus
    }
    $auditResult = 'SIMULATED'
  }
  else {
    & $Action
  }

  if (-not [string]::IsNullOrWhiteSpace($statusText)) {
    $statusColor = if ($isSimulation) { '#fab387' } else { '#a6e3a1' }
    Set-Status $statusText $statusColor
  }

  Write-AuditLog -Action $AuditAction -Result $auditResult -Object ([string]$AuditObject)

  if ($OnSuccess) {
    & $OnSuccess
  }

  return (-not $isSimulation)
}

function Invoke-SelectedUserAction(
  [scriptblock]$Action,
  [string]$SuccessMessage,
  [string]$ErrorContext,
  [string]$ConfirmMessage = '',
  [string]$AuditAction = 'Acción Usuario'
) {
  if (-not (Assert-ADModule)) { return }
  $sel = Get-SelectedUser
  if (-not $sel) { return }

  if (-not [string]::IsNullOrWhiteSpace($ConfirmMessage)) {
    if (-not (Show-Confirm ($ConfirmMessage -f $sel.SamAccountName))) { return }
  }

  try {
    $successText = $SuccessMessage -f $sel.SamAccountName
    $simulatedText = "[SIMULATION] $successText"
    Invoke-AdWriteOperation `
      -Action { & $Action $sel } `
      -AuditAction $AuditAction `
      -AuditObject ([string]$sel.SamAccountName) `
      -SuccessStatus $successText `
      -SimulatedStatus $simulatedText `
      -OnSuccess { Raise-ButtonClick $btnUserSearch } | Out-Null
  }
  catch {
    Write-AuditLog -Action $AuditAction -Result 'ERROR' -Object ([string]$sel.SamAccountName) -Detail $_.Exception.Message
    Show-Exception $ErrorContext $_
  }
}

function Invoke-SelectedGroupAction(
  [scriptblock]$Action,
  [string]$SuccessMessage,
  [string]$ErrorContext,
  [string]$ConfirmMessage = '',
  [string]$AuditAction = 'Acción Grupo'
) {
  if (-not (Assert-ADModule)) { return }
  $sel = Get-SelectedGroup
  if (-not $sel) { return }

  if (-not [string]::IsNullOrWhiteSpace($ConfirmMessage)) {
    if (-not (Show-Confirm ($ConfirmMessage -f $sel.Name))) { return }
  }

  try {
    $successText = $SuccessMessage -f $sel.Name
    $simulatedText = "[SIMULATION] $successText"
    Invoke-AdWriteOperation `
      -Action { & $Action $sel } `
      -AuditAction $AuditAction `
      -AuditObject ([string]$sel.Name) `
      -SuccessStatus $successText `
      -SimulatedStatus $simulatedText `
      -OnSuccess { Raise-ButtonClick $btnGroupSearch } | Out-Null
  }
  catch {
    Write-AuditLog -Action $AuditAction -Result 'ERROR' -Object ([string]$sel.Name) -Detail $_.Exception.Message
    Show-Exception $ErrorContext $_
  }
}

function Get-DialogResponsiveContent($content) {
  if ($null -eq $content) { return $null }

  if ($content -is [System.Windows.Controls.Grid]) {
    return $content
  }

  if ($content -is [System.Windows.Controls.ScrollViewer]) {
    $content.VerticalScrollBarVisibility = 'Auto'
    $content.HorizontalScrollBarVisibility = 'Disabled'
    $content.CanContentScroll = $true
    return $content
  }

  if ($content -is [System.Windows.Controls.StackPanel]) {
    $children = @($content.Children)
    $footerStartIndex = $children.Count

    for ($idx = $children.Count - 1; $idx -ge 0; $idx--) {
      $child = $children[$idx]
      $isFooterElement = $false

      if ($child -is [System.Windows.Controls.Button]) {
        $isFooterElement = $true
      }
      elseif ($child -is [System.Windows.Controls.WrapPanel]) {
        $panelChildren = @($child.Children)
        if (($panelChildren.Count -gt 0) -and (@($panelChildren | Where-Object { $_ -isnot [System.Windows.Controls.Button] }).Count -eq 0)) {
          $isFooterElement = $true
        }
      }

      if ($isFooterElement) {
        $footerStartIndex = $idx
      }
      else {
        break
      }
    }

    $root = New-Object System.Windows.Controls.Grid
    $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = '*' })) | Out-Null
    $hasFooter = $footerStartIndex -lt $children.Count
    if ($hasFooter) {
      $root.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{ Height = 'Auto' })) | Out-Null
    }

    $bodyPanel = New-Object System.Windows.Controls.StackPanel
    $bodyPanel.Margin = $content.Margin
    foreach ($child in @($children | Select-Object -First $footerStartIndex)) {
      [void]$content.Children.Remove($child)
      [void]$bodyPanel.Children.Add($child)
    }

    $bodyScroll = New-Object System.Windows.Controls.ScrollViewer
    $bodyScroll.VerticalScrollBarVisibility = 'Auto'
    $bodyScroll.HorizontalScrollBarVisibility = 'Disabled'
    $bodyScroll.CanContentScroll = $true
    $bodyScroll.Content = $bodyPanel
    [System.Windows.Controls.Grid]::SetRow($bodyScroll, 0)
    $root.Children.Add($bodyScroll) | Out-Null

    if ($hasFooter) {
      $footerWrap = New-Object System.Windows.Controls.WrapPanel
      $footerWrap.HorizontalAlignment = 'Right'
      $footerWrap.Margin = '0,12,0,0'

      foreach ($child in @($children | Select-Object -Skip $footerStartIndex)) {
        [void]$content.Children.Remove($child)
        if ($child -is [System.Windows.Controls.WrapPanel]) {
          foreach ($nested in @($child.Children)) {
            [void]$child.Children.Remove($nested)
            [void]$footerWrap.Children.Add($nested)
          }
        }
        else {
          [void]$footerWrap.Children.Add($child)
        }
      }

      $footerBorder = New-Object System.Windows.Controls.Border
      $footerBorder.Padding = '0,8,0,0'
      $footerBorder.BorderThickness = '0,1,0,0'
      $footerBorder.BorderBrush = ConvertTo-Brush (Get-ActiveTheme).PanelBorder
      $footerBorder.Child = $footerWrap
      [System.Windows.Controls.Grid]::SetRow($footerBorder, 1)
      $root.Children.Add($footerBorder) | Out-Null
    }

    return $root
  }

  if (
    ($content -is [System.Windows.Controls.WrapPanel]) -or
    ($content -is [System.Windows.Controls.DockPanel])
  ) {
    $scroll = New-Object System.Windows.Controls.ScrollViewer
    $scroll.VerticalScrollBarVisibility = 'Auto'
    $scroll.HorizontalScrollBarVisibility = 'Disabled'
    $scroll.CanContentScroll = $true
    $scroll.Content = $content
    return $scroll
  }

  return $content
}

function New-DialogWindow([string]$title, [int]$w = 450, [int]$h = 500) {
  $t = Get-ActiveTheme
  $dlg = New-Object System.Windows.Window
  $dlg.Title = "$title | Develop by Matias Vaccari"
  $dlg.Width = $w; $dlg.Height = $h
  $dlg.MinWidth = [Math]::Min($w, 420)
  $dlg.MinHeight = [Math]::Min($h, 260)
  $dlg.WindowStartupLocation = 'CenterOwner'
  $dlg.Owner = $window
  $dlg.Background = ConvertTo-Brush $t.WindowBg
  $dlg.Foreground = ConvertTo-Brush $t.TextPrimary
  $dlg.FontFamily = 'Segoe UI'
  $dlg.SizeToContent = 'Manual'
  $dlg.ResizeMode = 'CanResizeWithGrip'
  $dlg.UseLayoutRounding = $true
  $dlg.SnapsToDevicePixels = $true

  $dlg.Add_ContentRendered({
      $workArea = [System.Windows.SystemParameters]::WorkArea
      $maxWidth = [Math]::Max(380, [int]$workArea.Width - 36)
      $maxHeight = [Math]::Max(300, [int]$workArea.Height - 36)

      $dlg.MaxWidth = $maxWidth
      $dlg.MaxHeight = $maxHeight

      if ($dlg.Width -gt $maxWidth) { $dlg.Width = $maxWidth }
      if ($dlg.Height -gt $maxHeight) { $dlg.Height = $maxHeight }

      $content = $dlg.Content
      if ($null -eq $content) { return }
      $responsiveContent = Get-DialogResponsiveContent $content
      if ($responsiveContent -ne $content) {
        $dlg.Content = $responsiveContent
      }

      $dlg.UpdateLayout()

      if ($dlg.Top -lt $workArea.Top) { $dlg.Top = $workArea.Top }
      if ($dlg.Left -lt $workArea.Left) { $dlg.Left = $workArea.Left }
      if (($dlg.Top + $dlg.ActualHeight) -gt $workArea.Bottom) {
        $dlg.Top = [Math]::Max($workArea.Top, $workArea.Bottom - $dlg.ActualHeight)
      }
      if (($dlg.Left + $dlg.ActualWidth) -gt $workArea.Right) {
        $dlg.Left = [Math]::Max($workArea.Left, $workArea.Right - $dlg.ActualWidth)
      }
    })
  return $dlg
}
function New-DlgLabel([string]$text) {
  $t = Get-ActiveTheme
  $l = New-Object System.Windows.Controls.Label
  $l.Content = $text
  $l.Foreground = ConvertTo-Brush $t.TextSecondary
  $l.FontSize = 13; $l.Padding = '0,6,0,2'
  return $l
}
function New-DlgTextBox([string]$text = '') {
  $theme = Get-ActiveTheme
  $tb = New-Object System.Windows.Controls.TextBox
  $tb.Text = $text; $tb.FontSize = 13; $tb.Padding = '6,4'
  $tb.Background = ConvertTo-Brush $theme.InputBg
  $tb.Foreground = ConvertTo-Brush $theme.InputFg
  $tb.BorderBrush = ConvertTo-Brush $theme.Border
  return $tb
}
function New-DlgPasswordBox {
  $t = Get-ActiveTheme
  $p = New-Object System.Windows.Controls.PasswordBox
  $p.FontSize = 13; $p.Padding = '6,4'
  $p.Background = ConvertTo-Brush $t.InputBg
  $p.Foreground = ConvertTo-Brush $t.InputFg
  $p.BorderBrush = ConvertTo-Brush $t.Border
  return $p
}
function New-DlgButton([string]$text, [string]$style = 'Primary') {
  $b = New-Object System.Windows.Controls.Button
  $b.Content = $text; $b.FontSize = 13; $b.FontWeight = 'SemiBold'; $b.Padding = '16,8'
  $b.BorderThickness = '0'; $b.Cursor = 'Hand'; $b.Margin = '0,10,0,0'
  $styleKey = "Btn$style"
  if ($window -and $window.Resources.Contains($styleKey)) {
    $b.Style = $window.Resources[$styleKey]
  }
  else {
    $colors = @{ Primary = '#89b4fa'; Success = '#a6e3a1'; Danger = '#f38ba8'; Warn = '#fab387' }
    $b.Background = ConvertTo-Brush $colors[$style]
    $b.Foreground = ConvertTo-Brush '#1e1e2e'
  }
  return $b
}
function New-DlgComboBox([string[]]$items, [int]$selected = 0) {
  $t = Get-ActiveTheme
  $c = New-Object System.Windows.Controls.ComboBox
  $items | ForEach-Object { $c.Items.Add($_) | Out-Null }
  $c.SelectedIndex = $selected; $c.FontSize = 13; $c.Padding = '6,4'
  $c.Background = ConvertTo-Brush $t.InputBg
  $c.Foreground = ConvertTo-Brush $t.InputFg
  $c.BorderBrush = ConvertTo-Brush $t.Border
  $itemStyle = New-Object System.Windows.Style([System.Windows.Controls.ComboBoxItem])
  $itemStyle.Setters.Add((New-Object System.Windows.Setter([System.Windows.Controls.Control]::BackgroundProperty, (ConvertTo-Brush $t.SurfaceElevated))))
  $itemStyle.Setters.Add((New-Object System.Windows.Setter([System.Windows.Controls.Control]::ForegroundProperty, (ConvertTo-Brush $t.TextPrimary))))
  $itemStyle.Setters.Add((New-Object System.Windows.Setter([System.Windows.Controls.Control]::PaddingProperty, '10,6')))
  $itemTriggerHover = New-Object System.Windows.Trigger
  $itemTriggerHover.Property = [System.Windows.Controls.ComboBoxItem]::IsHighlightedProperty
  $itemTriggerHover.Value = $true
  $itemTriggerHover.Setters.Add((New-Object System.Windows.Setter([System.Windows.Controls.Control]::BackgroundProperty, (ConvertTo-Brush $t.SelectionBg))))
  $itemTriggerHover.Setters.Add((New-Object System.Windows.Setter([System.Windows.Controls.Control]::ForegroundProperty, (ConvertTo-Brush $t.SelectionFg))))
  $itemStyle.Triggers.Add($itemTriggerHover)
  $itemTriggerSelected = New-Object System.Windows.Trigger
  $itemTriggerSelected.Property = [System.Windows.Controls.ComboBoxItem]::IsSelectedProperty
  $itemTriggerSelected.Value = $true
  $itemTriggerSelected.Setters.Add((New-Object System.Windows.Setter([System.Windows.Controls.Control]::BackgroundProperty, (ConvertTo-Brush $t.SelectionBg))))
  $itemTriggerSelected.Setters.Add((New-Object System.Windows.Setter([System.Windows.Controls.Control]::ForegroundProperty, (ConvertTo-Brush $t.SelectionFg))))
  $itemStyle.Triggers.Add($itemTriggerSelected)
  $c.ItemContainerStyle = $itemStyle
  return $c
}
function New-ConfigActionButton([string]$content, [string]$styleKey) {
  $b = New-Object System.Windows.Controls.Button
  $b.Content = $content
  $b.Margin = '0,0,6,4'
  $b.Padding = '12,6'
  if ($window.Resources.Contains($styleKey)) {
    $b.Style = $window.Resources[$styleKey]
  }
  return $b
}
function Add-UserPolicyConfigButtons {
  if (-not $borderConfigActionsPanel) { return }
  $actionsHost = $borderConfigActionsPanel.Child
  if (-not ($actionsHost -is [System.Windows.Controls.WrapPanel])) { return }

  if (($actionsHost.Children | Where-Object { $_ -is [System.Windows.Controls.Button] -and $_.Name -eq 'btnUserAdminUnlock' }).Count -gt 0) {
    return
  }

  $btnUnlock = New-ConfigActionButton -content "🔐 Desbloquear Admin Usuarios" -styleKey "BtnWarn"
  $btnUnlock.Name = 'btnUserAdminUnlock'
  $btnPolicy = New-ConfigActionButton -content "🛠️ Política Campos Usuarios" -styleKey "BtnPrimary"
  $btnPolicy.Name = 'btnUserPolicyEditor'
  $btnKey = New-ConfigActionButton -content "🔑 Configurar Clave Admin" -styleKey "BtnDanger"
  $btnKey.Name = 'btnUserAdminKey'

  $btnUnlock.Add_Click({ [void](Request-UserAdminUnlock) })
  $btnPolicy.Add_Click({ Show-UserPolicyEditor })
  $btnKey.Add_Click({ Set-UserAdminKey })

  $actionsHost.Children.Add($btnUnlock) | Out-Null
  $actionsHost.Children.Add($btnPolicy) | Out-Null
  $actionsHost.Children.Add($btnKey) | Out-Null
}
# Administracion de campos deshabilitada. Se mantienen todos visibles/editables.

