﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 40.Theme.ps1

# ── TEMAS ────────────────────────────────────────────────────────────────────
$script:isDarkMode = $true
$script:ThemeConfigPath = Get-AdManagerLocalDataPath 'ui.theme.json'
$script:LegacyThemeConfigPath = Join-Path $PSScriptRoot 'ui.theme.json'
$script:StatusColor = '#a6adc8'
$script:BrushCache = @{}
$script:themes = @{
  Dark  = @{
    WindowBg = '#111827'; SurfaceBg = '#161f30'; CardBg = '#202b3f'; PanelBg = '#182235'; SurfaceElevated = '#24324b'
    TextPrimary = '#e6edf9'; TextSecondary = '#93a4c3'; TextMuted = '#b5c0d5'
    CheckFg = '#aab8cf'
    Accent = '#7cc7ff'; Border = '#31425e'; PanelBorder = '#405473'
    RowBg = '#182235'; RowAltBg = '#1d2940'; GridLine = '#2e415f'
    GridHeaderBg = '#24324b'; GridHeaderFg = '#8fd2ff'
    TreeItemFg = '#8fd2ff'
    BtnPrimaryBg = '#6aa9d8'; BtnPrimaryFg = '#0f1c2e'; BtnPrimaryHoverBg = '#7bb5e0'; BtnPrimaryPressedBg = '#5a9bc9'; BtnPrimaryBorder = '#81bddf'
    BtnSuccessBg = '#5fa67f'; BtnSuccessFg = '#f8fbff'; BtnSuccessHoverBg = '#6ab08a'; BtnSuccessPressedBg = '#518f6d'; BtnSuccessBorder = '#7cbc99'
    BtnDangerBg = '#c67889'; BtnDangerFg = '#fff8fa'; BtnDangerHoverBg = '#cf8695'; BtnDangerPressedBg = '#b56a7a'; BtnDangerBorder = '#d89daa'
    BtnWarnBg = '#c79c66'; BtnWarnFg = '#fffaf4'; BtnWarnHoverBg = '#d1a978'; BtnWarnPressedBg = '#b48b58'; BtnWarnBorder = '#d9b284'
    InputBg = '#202b3f'; InputFg = '#e6edf9'; ChipBg = '#21314a'; ChipFg = '#dce9ff'
    HeaderBg = '#0f1726'; StatusBg = '#0f1726'; SelectionBg = '#315783'; SelectionFg = '#f8fbff'
  }
  Light = @{
    WindowBg = '#f4f7fb'; SurfaceBg = '#edf2f8'; CardBg = '#ffffff'; PanelBg = '#ffffff'; SurfaceElevated = '#e7eef8'
    TextPrimary = '#1f2a3d'; TextSecondary = '#5a6f8f'; TextMuted = '#667892'
    CheckFg = '#415875'
    Accent = '#1f6fe5'; Border = '#c6d3e5'; PanelBorder = '#d5dfed'
    RowBg = '#ffffff'; RowAltBg = '#f4f8fd'; GridLine = '#d8e1ee'
    GridHeaderBg = '#e7eef8'; GridHeaderFg = '#2654a8'
    TreeItemFg = '#2654a8'
    BtnPrimaryBg = '#3c78d1'; BtnPrimaryFg = '#f8fbff'; BtnPrimaryHoverBg = '#316fc8'; BtnPrimaryPressedBg = '#285eb0'; BtnPrimaryBorder = '#5a90df'
    BtnSuccessBg = '#4e9370'; BtnSuccessFg = '#f8fbff'; BtnSuccessHoverBg = '#458968'; BtnSuccessPressedBg = '#3a7458'; BtnSuccessBorder = '#6ba98a'
    BtnDangerBg = '#c66d7f'; BtnDangerFg = '#fff8fa'; BtnDangerHoverBg = '#bb6275'; BtnDangerPressedBg = '#a85165'; BtnDangerBorder = '#d792a0'
    BtnWarnBg = '#c39356'; BtnWarnFg = '#fffaf4'; BtnWarnHoverBg = '#b7864d'; BtnWarnPressedBg = '#9f7341'; BtnWarnBorder = '#d3ab78'
    InputBg = '#fdfefe'; InputFg = '#243248'; ChipBg = '#edf4ff'; ChipFg = '#23478f'
    HeaderBg = '#ffffff'; StatusBg = '#ffffff'; SelectionBg = '#d7e8ff'; SelectionFg = '#17325f'
  }
}

function ConvertTo-Brush([string]$hex) {
  if ([string]::IsNullOrWhiteSpace($hex)) { return $null }
  $key = $hex.Trim().ToLowerInvariant()
  if ($script:BrushCache.ContainsKey($key)) { return $script:BrushCache[$key] }

  $brush = [System.Windows.Media.BrushConverter]::new().ConvertFromString($hex)
  if (($brush -is [System.Windows.Freezable]) -and $brush.CanFreeze) {
    $brush.Freeze()
  }
  $script:BrushCache[$key] = $brush
  return $brush
}
function Get-ActiveTheme { if ($script:isDarkMode) { return $script:themes.Dark } return $script:themes.Light }

function Save-ThemePreference {
  try {
    $payload = [PSCustomObject]@{
      IsDarkMode = [bool]$script:isDarkMode
    }
    $json = $payload | ConvertTo-Json -Depth 4
    Ensure-ParentDirectory -path $script:ThemeConfigPath
    Set-Content -Path $script:ThemeConfigPath -Value $json -Encoding UTF8
  }
  catch {
    # No bloquear la UI por fallas al guardar tema.
  }
}

function Get-ThemeConfigReadPaths {
  $paths = @()
  if (-not [string]::IsNullOrWhiteSpace($script:ThemeConfigPath)) { $paths += $script:ThemeConfigPath }
  if ((-not [string]::IsNullOrWhiteSpace($script:LegacyThemeConfigPath)) -and ($script:LegacyThemeConfigPath -ne $script:ThemeConfigPath)) {
    $paths += $script:LegacyThemeConfigPath
  }
  return @($paths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
}

function Load-ThemePreference {
  $sourcePath = ''
  foreach ($candidate in (Get-ThemeConfigReadPaths)) {
    if (Test-Path -Path $candidate -PathType Leaf) {
      $sourcePath = $candidate
      break
    }
  }
  if ([string]::IsNullOrWhiteSpace($sourcePath)) { return }
  try {
    $raw = Get-Content -Path $sourcePath -Raw -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace($raw)) { return }
    $cfg = $raw | ConvertFrom-Json -ErrorAction Stop
    if ($cfg -and $cfg.PSObject.Properties['IsDarkMode']) {
      if ($cfg.IsDarkMode -is [bool]) { $script:isDarkMode = [bool]$cfg.IsDarkMode }
    }
  }
  catch {
    # Si está corrupto, mantener valor por defecto.
  }

  if ($sourcePath -ne $script:ThemeConfigPath) {
    Save-ThemePreference
  }
}

function Get-VisualDescendants([System.Windows.DependencyObject]$root, [Type]$type) {
  if (-not $root) { return @() }

  $found = New-Object 'System.Collections.Generic.List[object]'
  $stack = New-Object 'System.Collections.Generic.Stack[System.Windows.DependencyObject]'
  $stack.Push($root)

  while ($stack.Count -gt 0) {
    $current = $stack.Pop()

    # VisualTreeHelper solo acepta Visual/Visual3D.
    if ((-not ($current -is [System.Windows.Media.Visual])) -and (-not ($current -is [System.Windows.Media.Media3D.Visual3D]))) { continue }

    $childCount = [System.Windows.Media.VisualTreeHelper]::GetChildrenCount($current)
    for ($i = 0; $i -lt $childCount; $i++) {
      $child = [System.Windows.Media.VisualTreeHelper]::GetChild($current, $i)
      if ($null -eq $child) { continue }

      if ($type.IsAssignableFrom($child.GetType())) {
        [void]$found.Add($child)
      }

      if (($child -is [System.Windows.Media.Visual]) -or ($child -is [System.Windows.Media.Media3D.Visual3D])) {
        $stack.Push($child)
      }
    }
  }

  return @($found.ToArray())
}

function Set-ThemeTabResources($t) {
  $window.Resources['ThemeWindowBg'] = ConvertTo-Brush $t.WindowBg
  $window.Resources['ThemeTabBg'] = ConvertTo-Brush $t.WindowBg
  $window.Resources['ThemeTabHoverBg'] = ConvertTo-Brush $t.SurfaceElevated
  $window.Resources['ThemeTabSelectedBg'] = ConvertTo-Brush $t.PanelBg
  $window.Resources['ThemeTabFg'] = ConvertTo-Brush $t.TextSecondary
  $window.Resources['ThemeTabSelectedFg'] = ConvertTo-Brush $t.Accent
  $window.Resources['ThemeAccent'] = ConvertTo-Brush $t.Accent
  $window.Resources['ThemeBorder'] = ConvertTo-Brush $t.Border
  $window.Resources['ThemePanelBg'] = ConvertTo-Brush $t.PanelBg
  $window.Resources['ThemePanelBorder'] = ConvertTo-Brush $t.PanelBorder
  $window.Resources['ThemeSurfaceElevated'] = ConvertTo-Brush $t.SurfaceElevated
  $window.Resources['ThemeInputBg'] = ConvertTo-Brush $t.InputBg
  $window.Resources['ThemeInputFg'] = ConvertTo-Brush $t.InputFg
  $window.Resources['ThemeComboPopupBg'] = ConvertTo-Brush $t.SurfaceElevated
  $window.Resources['ThemeComboPopupFg'] = ConvertTo-Brush $t.TextPrimary
  $window.Resources['ThemeComboHoverBg'] = ConvertTo-Brush $t.SurfaceElevated
  $window.Resources['ThemeComboArrowBg'] = ConvertTo-Brush $t.SurfaceBg
  $window.Resources['ThemeComboArrowFg'] = ConvertTo-Brush $t.Accent
  $window.Resources['ThemeComboItemHoverBg'] = ConvertTo-Brush $t.SelectionBg
  $window.Resources['ThemeComboItemHoverFg'] = ConvertTo-Brush $t.SelectionFg
  $window.Resources['ThemeSurfaceBg'] = ConvertTo-Brush $t.SurfaceBg
  $window.Resources['ThemeTextPrimary'] = ConvertTo-Brush $t.TextPrimary
  $window.Resources['ThemeCheckFg'] = ConvertTo-Brush $t.CheckFg
  $window.Resources['ThemeLabelFg'] = ConvertTo-Brush $t.TextSecondary
  $window.Resources['ThemeGroupBoxFg'] = ConvertTo-Brush $t.Accent
  $window.Resources['ThemeTreeBg'] = ConvertTo-Brush $t.SurfaceBg
  $window.Resources['ThemeTreeFg'] = ConvertTo-Brush $t.TextPrimary
  $window.Resources['ThemeTreeBorder'] = ConvertTo-Brush $t.Border
  $window.Resources['ThemeTreeItemFg'] = ConvertTo-Brush $t.TreeItemFg
  $window.Resources['ThemeChipBg'] = ConvertTo-Brush $t.ChipBg
  $window.Resources['ThemeChipFg'] = ConvertTo-Brush $t.ChipFg
  $window.Resources['ThemeSelectionBg'] = ConvertTo-Brush $t.SelectionBg
  $window.Resources['ThemeSelectionFg'] = ConvertTo-Brush $t.SelectionFg
}

function Set-ThemeButtonResources($t) {
  $window.Resources['ThemeBtnPrimaryBg'] = ConvertTo-Brush $t.BtnPrimaryBg
  $window.Resources['ThemeBtnPrimaryFg'] = ConvertTo-Brush $t.BtnPrimaryFg
  $window.Resources['ThemeBtnPrimaryHoverBg'] = ConvertTo-Brush $t.BtnPrimaryHoverBg
  $window.Resources['ThemeBtnPrimaryPressedBg'] = ConvertTo-Brush $t.BtnPrimaryPressedBg
  $window.Resources['ThemeBtnPrimaryBorder'] = ConvertTo-Brush $t.BtnPrimaryBorder

  $window.Resources['ThemeBtnSuccessBg'] = ConvertTo-Brush $t.BtnSuccessBg
  $window.Resources['ThemeBtnSuccessFg'] = ConvertTo-Brush $t.BtnSuccessFg
  $window.Resources['ThemeBtnSuccessHoverBg'] = ConvertTo-Brush $t.BtnSuccessHoverBg
  $window.Resources['ThemeBtnSuccessPressedBg'] = ConvertTo-Brush $t.BtnSuccessPressedBg
  $window.Resources['ThemeBtnSuccessBorder'] = ConvertTo-Brush $t.BtnSuccessBorder

  $window.Resources['ThemeBtnDangerBg'] = ConvertTo-Brush $t.BtnDangerBg
  $window.Resources['ThemeBtnDangerFg'] = ConvertTo-Brush $t.BtnDangerFg
  $window.Resources['ThemeBtnDangerHoverBg'] = ConvertTo-Brush $t.BtnDangerHoverBg
  $window.Resources['ThemeBtnDangerPressedBg'] = ConvertTo-Brush $t.BtnDangerPressedBg
  $window.Resources['ThemeBtnDangerBorder'] = ConvertTo-Brush $t.BtnDangerBorder

  $window.Resources['ThemeBtnWarnBg'] = ConvertTo-Brush $t.BtnWarnBg
  $window.Resources['ThemeBtnWarnFg'] = ConvertTo-Brush $t.BtnWarnFg
  $window.Resources['ThemeBtnWarnHoverBg'] = ConvertTo-Brush $t.BtnWarnHoverBg
  $window.Resources['ThemeBtnWarnPressedBg'] = ConvertTo-Brush $t.BtnWarnPressedBg
  $window.Resources['ThemeBtnWarnBorder'] = ConvertTo-Brush $t.BtnWarnBorder
}

function Set-ThemeGridResources($t) {
  $window.Resources['ThemeGridBg'] = ConvertTo-Brush $t.SurfaceBg
  $window.Resources['ThemeGridFg'] = ConvertTo-Brush $t.TextPrimary
  $window.Resources['ThemeGridBorder'] = ConvertTo-Brush $t.Border
  $window.Resources['ThemeGridRowBg'] = ConvertTo-Brush $t.RowBg
  $window.Resources['ThemeGridRowAltBg'] = ConvertTo-Brush $t.RowAltBg
  $window.Resources['ThemeGridLine'] = ConvertTo-Brush $t.GridLine
  $window.Resources['ThemeGridHeaderBg'] = ConvertTo-Brush $t.GridHeaderBg
  $window.Resources['ThemeGridHeaderFg'] = ConvertTo-Brush $t.GridHeaderFg
}

function Apply-ThemeToInputs($t) {
  foreach ($tb in @($txtUserSearch, $txtGroupSearch, $txtComputerSearch, $txtAttrSearch, $txtBatchCsvPath)) {
    $tb.Background = ConvertTo-Brush $t.InputBg
    $tb.Foreground = ConvertTo-Brush $t.InputFg
    $tb.BorderBrush = ConvertTo-Brush $t.Border
  }

  if ($cbDomainSelect) {
    $cbDomainSelect.Background = ConvertTo-Brush $t.InputBg
    $cbDomainSelect.Foreground = ConvertTo-Brush $t.InputFg
    $cbDomainSelect.BorderBrush = ConvertTo-Brush $t.Border
  }

  if ($cbAuditMode) {
    $cbAuditMode.Background = ConvertTo-Brush $t.InputBg
    $cbAuditMode.Foreground = ConvertTo-Brush $t.InputFg
    $cbAuditMode.BorderBrush = ConvertTo-Brush $t.Border
  }

  foreach ($cbx in (Get-VisualDescendants -root $window -type ([System.Windows.Controls.ComboBox]))) {
    $cbx.Background = ConvertTo-Brush $t.InputBg
    $cbx.Foreground = ConvertTo-Brush $t.InputFg
    $cbx.BorderBrush = ConvertTo-Brush $t.Border
  }

  foreach ($item in (Get-VisualDescendants -root $window -type ([System.Windows.Controls.ComboBoxItem]))) {
    $item.Background = ConvertTo-Brush $t.SurfaceElevated
    $item.Foreground = ConvertTo-Brush $t.TextPrimary
  }
}

function Apply-ThemeToGrids($t) {
  foreach ($dg in @($dgUsers, $dgGroups, $dgComputers, $dgMoveObjects, $dgMoveTargetObjects, $dgBatchResults, $dgAttributes)) {
    $dg.Background = ConvertTo-Brush $t.SurfaceBg
    $dg.Foreground = ConvertTo-Brush $t.TextPrimary
    $dg.BorderBrush = ConvertTo-Brush $t.Border
    $dg.RowBackground = ConvertTo-Brush $t.RowBg
    $dg.AlternatingRowBackground = ConvertTo-Brush $t.RowAltBg
    $dg.HorizontalGridLinesBrush = ConvertTo-Brush $t.GridLine
  }
}

function Apply-ThemeToTrees($t) {
  foreach ($tv in @($tvMoveSourceOUs, $tvMoveTargetOUs)) {
    $tv.Background = ConvertTo-Brush $t.SurfaceBg
    $tv.Foreground = ConvertTo-Brush $t.TextPrimary
    $tv.BorderBrush = ConvertTo-Brush $t.Border
  }
  foreach ($item in (Get-VisualDescendants -root $window -type ([System.Windows.Controls.TreeViewItem]))) {
    $item.Foreground = ConvertTo-Brush $t.TreeItemFg
  }
}

function Apply-ThemeToGridHeaders($t) {
  foreach ($hdr in (Get-VisualDescendants -root $window -type ([System.Windows.Controls.Primitives.DataGridColumnHeader]))) {
    $hdr.Background = ConvertTo-Brush $t.GridHeaderBg
    $hdr.Foreground = ConvertTo-Brush $t.GridHeaderFg
    $hdr.BorderBrush = ConvertTo-Brush $t.Border
  }
}

function Apply-ThemeToDataGridVisuals($t) {
  $bg = ConvertTo-Brush $t.SurfaceBg
  $rowBg = ConvertTo-Brush $t.RowBg
  $rowAltBg = ConvertTo-Brush $t.RowAltBg
  $fg = ConvertTo-Brush $t.TextPrimary

  foreach ($dg in @($dgUsers, $dgGroups, $dgComputers, $dgMoveObjects, $dgMoveTargetObjects, $dgBatchResults, $dgAttributes)) {
    foreach ($sv in (Get-VisualDescendants -root $dg -type ([System.Windows.Controls.ScrollViewer]))) {
      $sv.Background = $bg
    }
    foreach ($row in (Get-VisualDescendants -root $dg -type ([System.Windows.Controls.DataGridRow]))) {
      if (-not $row.IsSelected) {
        if (($row.GetIndex() % 2) -eq 0) { $row.Background = $rowBg } else { $row.Background = $rowAltBg }
      }
      $row.Foreground = $fg
    }
    foreach ($cell in (Get-VisualDescendants -root $dg -type ([System.Windows.Controls.DataGridCell]))) {
      if (-not $cell.IsSelected) {
        $cell.Foreground = $fg
        $cell.BorderBrush = ConvertTo-Brush $t.Border
      }
    }
  }
}

function Apply-ThemeToLabelsAndChecks($t) {
  foreach ($lbl in (Get-VisualDescendants -root $window -type ([System.Windows.Controls.Label]))) {
    $lbl.Foreground = ConvertTo-Brush $t.TextSecondary
  }
  foreach ($cb in (Get-VisualDescendants -root $window -type ([System.Windows.Controls.CheckBox]))) {
    $cb.Foreground = ConvertTo-Brush $t.CheckFg
  }
}

function Apply-ThemeToLegacyBorders($t) {
  # Mapeo bidireccional: evita estados aleatorios al alternar varias veces claro/oscuro.
  $legacyRoleByHex = @{
    '#ff181825' = 'SurfaceBg'
    '#ffe6e9ef' = 'SurfaceBg'
    '#ff232336' = 'SurfaceBg'
    '#ff1e1e2e' = 'WindowBg'
    '#ffeff1f5' = 'WindowBg'
    '#ff313244' = 'CardBg'
    '#ffdce0e8' = 'CardBg'
    '#ff292940' = 'CardBg'
  }
  foreach ($bd in (Get-VisualDescendants -root $window -type ([System.Windows.Controls.Border]))) {
    if ($bd -eq $borderHeader -or $bd -eq $borderDomainBar -or $bd -eq $borderStatus) { continue }
    if ($bd.Background -is [System.Windows.Media.SolidColorBrush]) {
      $hex = $bd.Background.Color.ToString().ToLowerInvariant()
      if ($legacyRoleByHex.ContainsKey($hex)) {
        $role = $legacyRoleByHex[$hex]
        $bd.Background = ConvertTo-Brush $t[$role]
      }
    }
    if ($bd.BorderBrush -is [System.Windows.Media.SolidColorBrush]) {
      $bd.BorderBrush = ConvertTo-Brush $t.Border
    }
  }
}

function Apply-ThemeToGroupBoxes($t) {
  foreach ($gb in (Get-VisualDescendants -root $window -type ([System.Windows.Controls.GroupBox]))) {
    $gb.BorderBrush = ConvertTo-Brush $t.PanelBorder
    $gb.Foreground = ConvertTo-Brush $t.Accent
  }
}

function Apply-ThemeToPanels($t) {
  foreach ($bd in @(
      $borderUserSearchPanel, $borderUserActionsPanel,
      $borderGroupSearchPanel, $borderGroupActionsPanel,
      $borderComputerSearchPanel, $borderComputerActionsPanel,
      $borderAttrSearchPanel, $borderAttrActionsPanel,
      $borderConfigHeaderPanel, $borderConfigBodyPanel, $borderConfigActionsPanel
    )) {
    if ($bd) {
      $bd.Background = ConvertTo-Brush $t.PanelBg
      $bd.BorderBrush = ConvertTo-Brush $t.PanelBorder
      $bd.BorderThickness = '1'
    }
  }
}

function Apply-Theme {
  $t = if ($script:isDarkMode) { $script:themes.Dark } else { $script:themes.Light }
  $window.Background = ConvertTo-Brush $t.WindowBg
  $window.Foreground = ConvertTo-Brush $t.TextPrimary
  $borderHeader.Background = ConvertTo-Brush $t.HeaderBg
  $borderHeader.BorderBrush = ConvertTo-Brush $t.PanelBorder
  $borderDomainBar.Background = ConvertTo-Brush $t.PanelBg
  $borderDomainBar.BorderBrush = ConvertTo-Brush $t.PanelBorder
  $borderStatus.Background = ConvertTo-Brush $t.StatusBg
  $borderStatus.BorderBrush = ConvertTo-Brush $t.PanelBorder
  $tabControl.Background = ConvertTo-Brush $t.WindowBg
  $tabControl.BorderBrush = ConvertTo-Brush $t.PanelBorder
  $txtTitle.Foreground = ConvertTo-Brush $t.Accent
  $txtSubtitle.Foreground = ConvertTo-Brush $t.TextSecondary
  $txtDomainLabel.Foreground = ConvertTo-Brush $t.TextSecondary
  $txtDomainInfo.Foreground = ConvertTo-Brush $t.TextSecondary
  if ($btnMaximizeApp) {
    if ($window.WindowState -eq [System.Windows.WindowState]::Maximized) {
      $btnMaximizeApp.Content = 'Restaurar'
      $btnMaximizeApp.ToolTip = 'Restaurar ventana'
    }
    else {
      $btnMaximizeApp.Content = 'Maximizar'
      $btnMaximizeApp.ToolTip = 'Maximizar ventana'
    }
  }
  if ($btnMinimizeApp) {
    $btnMinimizeApp.ToolTip = 'Minimizar ventana'
  }

  Set-ThemeTabResources $t
  Set-ThemeButtonResources $t
  Set-ThemeGridResources $t
  Apply-ThemeToInputs $t
  Apply-ThemeToGrids $t
  Apply-ThemeToGridHeaders $t
  Apply-ThemeToDataGridVisuals $t
  Apply-ThemeToTrees $t
  Apply-ThemeToLabelsAndChecks $t
  Apply-ThemeToLegacyBorders $t
  Apply-ThemeToGroupBoxes $t
  Apply-ThemeToPanels $t

  if ([string]::IsNullOrWhiteSpace([string]$script:StatusColor)) {
    $script:StatusColor = $t.TextMuted
  }
  $txtStatus.Foreground = ConvertTo-Brush $script:StatusColor
  $txtAttrDN.Foreground = ConvertTo-Brush $t.TextSecondary

  if ($script:isDarkMode) { $btnThemeToggle.Content = "Modo claro" } else { $btnThemeToggle.Content = "Modo oscuro" }
}

Load-ThemePreference
$btnThemeToggle.Add_Click({
    $script:isDarkMode = -not $script:isDarkMode
    Apply-Theme
    Save-ThemePreference
  })
$window.Add_ContentRendered({ Apply-Theme })
$tabControl.Add_SelectionChanged({
    if ($_.Source -eq $tabControl) { Apply-Theme }
  })
$window.Add_StateChanged({ Apply-Theme })
