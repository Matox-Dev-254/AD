﻿# AD Manager Modules

Esta carpeta concentra la fase 1 de modularizacion de `Uchatgpt.ps1`.

Orden de carga actual:

- `00.Bootstrap.ps1`: arranque, STA, assemblies y validacion de RSAT.
- `10.Xaml.ps1`: definicion completa de la ventana principal.
- `20.Window.ps1`: carga de XAML y referencias a controles.
- `30.Domain.ps1`: estado y helpers de multidiominio/simulacion.
- `40.Theme.ps1`: temas, recursos visuales y aplicacion del look and feel.
- `50.Core.ps1`: helpers comunes, auditoria, policies, dialogos y utilitarios base.
- `60.UsersGroups.ps1`: handlers y flujos de usuarios, grupos y conexion de dominio.
- `70.Operations.ps1`: OUs, movimientos y procesamiento CSV.
- `80.AttributesStartup.ps1`: atributos editables y splash de inicio.
- `90.Launch.ps1`: inicializacion final y apertura de la ventana.

Regla de esta fase:

- No cambiar comportamiento funcional.
- Mover bloques completos y preservar el orden.
- Centralizar primero; refinar dependencias despues.
