[CmdletBinding()]
param(
  [string]$OutputRoot,
  [switch]$Zip
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Ensure-Directory([string]$Path) {
  if (-not (Test-Path -Path $Path -PathType Container)) {
    New-Item -Path $Path -ItemType Directory -Force | Out-Null
  }
}

function Remove-PathIfExists([string]$Path) {
  if (Test-Path -Path $Path) {
    Remove-Item -Path $Path -Recurse -Force
  }
}

function Copy-ReleaseTree([string]$SourceRoot, [string]$TargetRoot) {
  Ensure-Directory -Path $TargetRoot

  $files = Get-ChildItem -Path $SourceRoot -Recurse -File -Force | Where-Object {
    $_.FullName -notmatch '\\dist(\\|$)' -and
    $_.FullName -notmatch '\\modules\\AuditLogs(\\|$)' -and
    $_.Name -ne '.gitignore'
  }

  foreach ($file in $files) {
    $relativePath = $file.FullName.Substring($SourceRoot.Length).TrimStart('\')
    $targetPath = Join-Path $TargetRoot $relativePath
    $parent = Split-Path -Path $targetPath -Parent
    Ensure-Directory -Path $parent
    Copy-Item -Path $file.FullName -Destination $targetPath -Force
  }
}

function Set-ReleaseFileContent([string]$Path, [string]$Content) {
  $parent = Split-Path -Path $Path -Parent
  Ensure-Directory -Path $parent
  Set-Content -Path $Path -Value $Content -Encoding UTF8
}

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptRoot
$config = Import-PowerShellDataFile -Path (Join-Path $scriptRoot 'Product.Config.psd1')

if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
  $OutputRoot = Join-Path $projectRoot 'dist'
}

$releaseName = '{0} {1}' -f $config.ProductName, $config.Version
$releaseRoot = Join-Path $OutputRoot $releaseName
$zipPath = Join-Path $OutputRoot ($releaseName + '.zip')

Ensure-Directory -Path $OutputRoot
Remove-PathIfExists -Path $releaseRoot
Copy-ReleaseTree -SourceRoot $projectRoot -TargetRoot $releaseRoot

Set-ReleaseFileContent -Path (Join-Path $releaseRoot 'modules\domain.connections.json') -Content @'
{
  "LastActive": "",
  "Items": []
}
'@

Set-ReleaseFileContent -Path (Join-Path $releaseRoot 'modules\audit.settings.json') -Content @'
{
  "EnableCentral": false,
  "CentralMode": "FileShare",
  "CentralFilePath": "\\\\SERVIDOR\\AD-Audit\\AD_Audit_Central.csv",
  "SqlConnectionString": "",
  "SqlTable": "dbo.ADAuditLog"
}
'@

Set-ReleaseFileContent -Path (Join-Path $releaseRoot 'AD Manager.cmd') -Content @'
@echo off
setlocal
set SCRIPT_DIR=%~dp0
start "" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden -File "%SCRIPT_DIR%Uchatgpt.ps1"
endlocal
'@

Set-ReleaseFileContent -Path (Join-Path $releaseRoot 'Instalar AD Manager.cmd') -Content @'
@echo off
setlocal
set SCRIPT_DIR=%~dp0
powershell.exe -ExecutionPolicy Bypass -File "%SCRIPT_DIR%installer\install.ps1"
endlocal
'@

Set-ReleaseFileContent -Path (Join-Path $releaseRoot 'Desinstalar AD Manager.cmd') -Content @'
@echo off
setlocal
set SCRIPT_DIR=%~dp0
powershell.exe -ExecutionPolicy Bypass -File "%SCRIPT_DIR%installer\uninstall.ps1"
endlocal
'@

Set-ReleaseFileContent -Path (Join-Path $releaseRoot 'README-Distribucion.txt') -Content @'
AD Manager - Paquete de distribucion

Este directorio es una copia preparada para uso o entrega.
No es la carpeta de desarrollo.

Opciones:
1. Ejecutar "AD Manager.cmd" para abrir la aplicacion.
2. Ejecutar "Instalar AD Manager.cmd" como administrador para instalarla en el equipo.
3. Ejecutar "Desinstalar AD Manager.cmd" como administrador para desinstalarla del equipo.
'@

if ($Zip) {
  Remove-PathIfExists -Path $zipPath
  Compress-Archive -Path (Join-Path $releaseRoot '*') -DestinationPath $zipPath -Force
}

Write-Host ''
Write-Host 'Release generada correctamente.' -ForegroundColor Green
Write-Host "Carpeta: $releaseRoot"
if ($Zip) {
  Write-Host "Zip: $zipPath"
}
