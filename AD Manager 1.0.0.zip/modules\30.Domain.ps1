﻿# Auto-generated module extracted from Uchatgpt.ps1
# Section: 30.Domain.ps1

# ── SISTEMA DE DOMINIOS ──────────────────────────────────────────────────────
$global:domainConnections = @{}
$global:activeDomain = $null
$script:ADDomainCache = @{}
$script:LocalDomainDns = ''
$script:LocalDomainLabel = '(Local)'
$script:DomainConnectionsConfigPath = Get-AdManagerLocalDataPath 'domain.connections.json'
$script:LegacyDomainConnectionsConfigPath = Join-Path $PSScriptRoot 'domain.connections.json'
$script:StartupDomainChecks = @()
$script:StartupDomainFailures = @()

function Resolve-LocalDomainDns {
  if (-not [string]::IsNullOrWhiteSpace([string]$env:USERDNSDOMAIN)) { return [string]$env:USERDNSDOMAIN }
  if (-not [string]::IsNullOrWhiteSpace([string]$env:USERDOMAIN)) { return [string]$env:USERDOMAIN }
  try {
    $d = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    if ($d -and $d.Name) { return [string]$d.Name }
  }
  catch {}
  return ''
}

function Set-LocalDomainIdentity([string]$dnsRoot) {
  if ([string]::IsNullOrWhiteSpace($dnsRoot)) { $dnsRoot = 'Local sin dominio detectado' }
  $script:LocalDomainDns = $dnsRoot
  $script:LocalDomainLabel = "(Local: $dnsRoot)"
}

Set-LocalDomainIdentity -dnsRoot (Resolve-LocalDomainDns)

$cbDomainSelect.Items.Add($script:LocalDomainLabel) | Out-Null
$cbDomainSelect.SelectedIndex = 0

function Get-ADParams {
  if (-not $global:activeDomain -or $global:activeDomain -eq $script:LocalDomainLabel) { return @{} }
  $conn = $global:domainConnections[$global:activeDomain]
  if (-not $conn) { return @{} }
  $p = @{ Server = $conn.Server }
  if ($conn.Credential) { $p.Credential = $conn.Credential }
  return $p
}

function Clear-ADDomainCache {
  $script:ADDomainCache = @{}
}

function Get-ADDomainCached([hashtable]$adParams = $null, [switch]$ForceRefresh) {
  if ($null -eq $adParams) { $adParams = Get-ADParams }

  $serverKey = '(local)'
  if ($adParams.ContainsKey('Server') -and (-not [string]::IsNullOrWhiteSpace([string]$adParams.Server))) {
    $serverKey = [string]$adParams.Server
  }

  $credKey = ''
  if ($adParams.ContainsKey('Credential') -and $adParams.Credential -and $adParams.Credential.UserName) {
    $credKey = [string]$adParams.Credential.UserName
  }

  $cacheKey = "$serverKey|$credKey"
  if ($ForceRefresh -or (-not $script:ADDomainCache.ContainsKey($cacheKey))) {
    $script:ADDomainCache[$cacheKey] = Get-ADDomain @adParams
  }

  return $script:ADDomainCache[$cacheKey]
}

function Get-DomainConnectionsForStorage {
  $items = @()
  foreach ($label in @($global:domainConnections.Keys | Sort-Object)) {
    if ([string]::IsNullOrWhiteSpace([string]$label)) { continue }
    $conn = $global:domainConnections[$label]
    if (-not $conn) { continue }
    $hasCredential = $false
    $userName = ''
    if ($conn.Credential) {
      $hasCredential = $true
      if ($conn.Credential.UserName) { $userName = [string]$conn.Credential.UserName }
    }
    elseif ($conn.UserName) {
      $userName = [string]$conn.UserName
    }

    $items += [PSCustomObject]@{
      Label             = [string]$label
      Server            = [string]$conn.Server
      Domain            = [string]$conn.Domain
      AuthMode          = if ($hasCredential) { 'PromptCredentials' } else { 'CurrentCredentials' }
      UserName          = $userName
      RequiresReconnect = $hasCredential
      Persistable       = $true
    }
  }
  return @($items)
}

function Save-DomainConnectionsToFile {
  try {
    $payload = [PSCustomObject]@{
      LastActive = if (($global:activeDomain) -and ($global:activeDomain -ne $script:LocalDomainLabel)) { [string]$global:activeDomain } else { '' }
      Items      = @(Get-DomainConnectionsForStorage)
    }
    $json = $payload | ConvertTo-Json -Depth 6
    Ensure-ParentDirectory -path $script:DomainConnectionsConfigPath
    Set-Content -Path $script:DomainConnectionsConfigPath -Value $json -Encoding UTF8
  }
  catch {
    # No interrumpir la app por errores de persistencia.
  }
}

function Get-DomainConnectionsReadPaths {
  $paths = @()
  if (-not [string]::IsNullOrWhiteSpace($script:DomainConnectionsConfigPath)) { $paths += $script:DomainConnectionsConfigPath }
  if ((-not [string]::IsNullOrWhiteSpace($script:LegacyDomainConnectionsConfigPath)) -and ($script:LegacyDomainConnectionsConfigPath -ne $script:DomainConnectionsConfigPath)) {
    $paths += $script:LegacyDomainConnectionsConfigPath
  }
  return @($paths | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
}

function Load-DomainConnectionsFromFile {
  $sourcePath = ''
  foreach ($candidate in (Get-DomainConnectionsReadPaths)) {
    if (Test-Path -Path $candidate -PathType Leaf) {
      $sourcePath = $candidate
      break
    }
  }
  if ([string]::IsNullOrWhiteSpace($sourcePath)) { return }

  try {
    $raw = Get-Content -Path $sourcePath -Raw -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace($raw)) { return }

    $cfg = $raw | ConvertFrom-Json -ErrorAction Stop
    $items = @()
    if ($cfg -and $cfg.PSObject.Properties['Items']) {
      $items = @($cfg.Items)
    }

    $global:domainConnections = @{}
    foreach ($item in @($items)) {
      $label = [string]$item.Label
      $server = [string]$item.Server
      if ([string]::IsNullOrWhiteSpace($label) -or [string]::IsNullOrWhiteSpace($server)) { continue }
      $authMode = 'CurrentCredentials'
      if ($item.PSObject.Properties['AuthMode']) {
        $authMode = [string]$item.AuthMode
      }
      elseif ($item.PSObject.Properties['UserName'] -and (-not [string]::IsNullOrWhiteSpace([string]$item.UserName))) {
        $authMode = 'PromptCredentials'
      }
      $userName = ''
      if ($item.PSObject.Properties['UserName']) { $userName = [string]$item.UserName }
      $requiresReconnect = ($authMode -eq 'PromptCredentials')
      if ($item.PSObject.Properties['RequiresReconnect']) {
        $requiresReconnect = [bool]$item.RequiresReconnect
      }

      $global:domainConnections[$label] = @{
        Server            = $server
        Credential        = $null
        Domain            = [string]$item.Domain
        Persistable       = $true
        AuthMode          = $authMode
        UserName          = $userName
        RequiresReconnect = $requiresReconnect
      }
    }

    Refresh-DomainCombo
    $lastActive = ''
    if ($cfg -and $cfg.PSObject.Properties['LastActive']) { $lastActive = [string]$cfg.LastActive }
    if ((-not [string]::IsNullOrWhiteSpace($lastActive)) -and $cbDomainSelect.Items.Contains($lastActive)) {
      $cbDomainSelect.SelectedItem = $lastActive
    }
  }
  catch {
    # Si el archivo está corrupto, se ignora y se inicia sin conexiones persistidas.
  }

  # Normalizar al formato nuevo fuera del repo.
  Save-DomainConnectionsToFile
}

function Refresh-DomainCombo {
  $cbDomainSelect.Dispatcher.Invoke([Action] {
      $current = $cbDomainSelect.SelectedItem
      $cbDomainSelect.Items.Clear() | Out-Null
      $cbDomainSelect.Items.Add($script:LocalDomainLabel) | Out-Null

      foreach ($key in @($global:domainConnections.Keys)) {
        if (-not [string]::IsNullOrWhiteSpace($key)) {
          $cbDomainSelect.Items.Add($key) | Out-Null
        }
      }

      if ($null -ne $current) {
        $idx = $cbDomainSelect.Items.IndexOf($current)
        if ($idx -ge 0) { $cbDomainSelect.SelectedIndex = $idx; return }
      }
      $cbDomainSelect.SelectedIndex = 0
    })
}

function Set-SimulationMode([bool]$enabled) {
  $script:SimulationMode = $enabled
  $script:WhatIfPreference = $enabled

  if ($enabled) {
    Set-Status "⚠️ Modo simulación activo (WhatIf): no se aplican cambios reales." '#fab387'
  }
  else {
    Set-Status "✅ Modo simulación desactivado. Cambios reales habilitados." '#a6e3a1'
  }
}

$cbDomainSelect.Add_SelectionChanged({
    $selected = $cbDomainSelect.SelectedItem
    if ($null -eq $selected) { return }

    $global:activeDomain = $selected
    Clear-ADDomainCache
    if ($selected -eq $script:LocalDomainLabel) {
      $txtDomainInfo.Text = "Dominio activo: $($script:LocalDomainDns)"
    }
    else {
      $conn = $global:domainConnections[$selected]
      if ($conn) {
        $domainText = if (-not [string]::IsNullOrWhiteSpace([string]$conn.Domain)) { [string]$conn.Domain } else { [string]$selected }
        $infoText = "Dominio activo: $domainText | Servidor: $($conn.Server)"
        if (($conn.RequiresReconnect) -and (-not $conn.Credential)) {
          $userText = if (-not [string]::IsNullOrWhiteSpace([string]$conn.UserName)) { " como $($conn.UserName)" } else { '' }
          $infoText += " | Requiere reconexion$userText"
        }
        $txtDomainInfo.Text = $infoText
      }
    }
  })

$txtDomainInfo.Text = "Dominio activo: $($script:LocalDomainDns)"
Load-DomainConnectionsFromFile

if ($chkSimulationMode) {
  $chkSimulationMode.IsChecked = $false
  $chkSimulationMode.ToolTip = "Si está activo, las acciones manuales y el lote CSV se auditan como simulación y no aplican cambios reales."
  $chkSimulationMode.Add_Checked({ Set-SimulationMode $true })
  $chkSimulationMode.Add_Unchecked({ Set-SimulationMode $false })
}
